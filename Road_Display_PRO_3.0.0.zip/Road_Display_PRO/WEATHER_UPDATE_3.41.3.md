# ROAD DISPLAY PRO 3.41.3 — Meteo per fasce orarie

- Il popup METEO ora presenta quattro fasce: notte (00:00–07:00), mattina (08:00–15:00), pomeriggio (16:00–19:00), sera (20:00–23:00).
- Ogni fascia mostra un'icona derivata dal codice meteo reale, temperatura media, vento medio e probabilità media di precipitazione quando disponibili.
- Toccando una fascia si espandono le previsioni ora per ora della stessa fascia; un secondo tocco la richiude.
- Le medie usano solo campioni disponibili della previsione oraria Open-Meteo. Se i dati mancano, l'interfaccia lo segnala invece di inventarli.
- Le previsioni per la posizione continuano a richiedere una posizione GPS reale e recente, secondo i controlli già presenti nell'app.

## Verifiche

- Tutti i test Python `roadtools/*_test.py` passano, incluso il nuovo test meteo (9 controlli).
- Controllo statico di bilanciamento parentesi Java superato.
- Non è stato possibile eseguire `gradle assembleDebug` in questo ambiente: Gradle non è installato. Il pacchetto ZIP contiene il sorgente aggiornato, non un APK verificato.
