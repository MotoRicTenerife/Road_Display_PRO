package com.riccardo.roaddisplay;

import android.content.Context;
import com.valhalla.valhalla.Valhalla;
import com.valhalla.valhalla.config.ValhallaConfigFactory;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Local Valhalla engine + regional routing-tile downloader.
 * Routing is executed entirely on-device once a pre-built Valhalla tileset is present.
 */
public final class OfflineValhallaEngine implements Closeable {
    public interface Listener {
        void onProgress(int percent, long done, long total, String status);
        void onReady(String regionName);
        void onError(String message);
    }

    private static final String CATALOG_URL =
            "https://github.com/ivlop/acre-valhalla-tiles/releases/latest/download/catalog.json";
    private final Context context;
    private volatile Valhalla engine;
    private volatile String regionName = "";
    private final File rootDir;

    public OfflineValhallaEngine(Context context) {
        this.context = context.getApplicationContext();
        rootDir = new File(this.context.getExternalFilesDir(null), "offline_valhalla");
        if (!rootDir.exists()) rootDir.mkdirs();
    }

    public boolean isReady() { return engine != null; }
    public String getRegionName() { return regionName; }

    /** Re-opens a previously downloaded routing package without network access. */
    public synchronized boolean initializeIfPresent() throws Exception {
        File tar = new File(rootDir, "canarias.tar");
        if (!tar.isFile() || tar.length() < 1024) return false;
        initialize(tar.getAbsolutePath());
        return true;
    }

    /** Starts/continues downloading the Spain regional routing package containing Canarias. */
    public void downloadCanarias(final Listener listener) {
        new Thread(() -> {
            try {
                JSONObject catalog = new JSONObject(readUrl(CATALOG_URL));
                JSONObject region = findCanarias(catalog);
                if (region == null) throw new IOException("Nel catalogo routing offline non è disponibile una regione Canarias.");
                String name = region.optString("name", "Canarie");
                String url = region.optString("url", "");
                if (url.isEmpty()) throw new IOException("URL routing Canarias assente nel catalogo.");
                long expected = region.optLong("size_bytes", -1L);
                String sha = region.optString("sha256", "").trim().toLowerCase(Locale.ROOT);
                File tar = new File(rootDir, "canarias.tar");
                download(url, tar, expected, sha, listener, name);
                initialize(tar.getAbsolutePath());
                if (listener != null) listener.onReady(name);
            } catch (Throwable t) {
                if (listener != null) listener.onError(message(t));
            }
        }, "rdp-valhalla-download").start();
    }

    private JSONObject findCanarias(JSONObject catalog) {
        JSONArray regions = catalog.optJSONArray("regions");
        if (regions == null) return null;
        JSONObject fallback = null;
        for (int i=0;i<regions.length();i++) {
            JSONObject r = regions.optJSONObject(i); if (r == null) continue;
            String id = r.optString("id", "").toLowerCase(Locale.ROOT);
            String name = r.optString("name", "").toLowerCase(Locale.ROOT);
            if (id.contains("canaria") || name.contains("canaria")) return r;
            if (id.contains("tenerife") || name.contains("tenerife")) fallback = r;
        }
        return fallback;
    }

    public synchronized void initialize(String tarPath) throws Exception {
        if (engine != null) return;
        File f = new File(tarPath);
        if (!f.isFile() || f.length() < 1024) throw new IOException("Routing tiles non validi: " + f);
        com.valhalla.valhalla.config.ValhallaConfig config =
                ValhallaConfigFactory.INSTANCE.usingTileExtract(f.getAbsolutePath(), null);
        engine = new Valhalla(context, config);
        regionName = "Canarie";
    }

    public synchronized String routeRaw(String requestJson) throws Exception {
        Valhalla v = engine;
        if (v == null) throw new IllegalStateException("Routing offline non pronto");
        return v.routeRaw(requestJson);
    }

    public synchronized String traceRouteRaw(String requestJson) throws Exception {
        Valhalla v = engine;
        if (v == null) throw new IllegalStateException("Map matching offline non pronto");
        return v.traceRouteRaw(requestJson);
    }

    private static void download(String url, File out, long expected, String sha,
                                 Listener listener, String name) throws Exception {
        if (out.exists() && expected > 0 && out.length() == expected && !sha.isEmpty() && sha.equalsIgnoreCase(sha256(out))) {
            if (listener != null) listener.onProgress(100, out.length(), expected, name + ": routing già presente");
            return;
        }
        HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.39.0");
        int code = c.getResponseCode();
        if (code != HttpURLConnection.HTTP_OK) throw new IOException("HTTP " + code + " scaricando routing offline");
        long total = c.getContentLengthLong(); if (total <= 0) total = expected;
        File tmp = new File(out.getParentFile(), out.getName()+".part");
        long done = 0;
        try (InputStream in = new BufferedInputStream(c.getInputStream()); FileOutputStream fos = new FileOutputStream(tmp, false)) {
            byte[] buf = new byte[64*1024]; int n; int last=-1;
            while ((n=in.read(buf)) >= 0) {
                if (n == 0) continue;
                fos.write(buf,0,n); done += n;
                int pct = total > 0 ? (int)Math.max(0, Math.min(99, (done*100L)/total)) : 0;
                if (pct != last && listener != null) { last=pct; listener.onProgress(pct,done,total,name+": routing"); }
            }
        } finally { c.disconnect(); }
        if (expected > 0 && done != expected) throw new IOException("Download incompleto: " + done + "/" + expected + " byte");
        if (!sha.isEmpty()) {
            String got=sha256(tmp); if (!sha.equalsIgnoreCase(got)) throw new IOException("SHA-256 routing non corrispondente");
        }
        if (!tmp.renameTo(out)) throw new IOException("Impossibile finalizzare il pacchetto routing");
        if (listener != null) listener.onProgress(100,done,total,name+": routing verificato");
    }

    private static String readUrl(String u) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","ROAD-DISPLAY-PRO/3.39.0");
        try (InputStream in=c.getInputStream(); ByteArrayOutputStream b=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>=0) if(n>0)b.write(buf,0,n); return b.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)if(n>0)md.update(b,0,n);}
        StringBuilder s=new StringBuilder();for(byte x:md.digest())s.append(String.format(Locale.ROOT,"%02x",x));return s.toString();
    }

    private static String message(Throwable t) {
        Throwable x=t; while(x.getCause()!=null && (x.getMessage()==null || x.getMessage().isEmpty())) x=x.getCause();
        String m=x.getMessage(); return x.getClass().getSimpleName() + (m==null || m.isEmpty()?"":" · "+m);
    }

    @Override public synchronized void close() { if(engine!=null){try{engine.close();}catch(Throwable ignored){} engine=null;} }
}
