package com.riccardo.roaddisplay;
import android.content.*;import android.database.sqlite.*;import android.database.*;import java.util.*;
public class RoadDb extends SQLiteOpenHelper{
 public RoadDb(Context c){super(c,"roads.db",null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE ways(id TEXT PRIMARY KEY,name TEXT,bbox TEXT,pts TEXT,updated INTEGER)");d.execSQL("CREATE INDEX idx_updated ON ways(updated)");}
 public void onUpgrade(SQLiteDatabase d,int a,int b){}
 public synchronized void put(String id,String name,double minLat,double minLon,double maxLat,double maxLon,String pts){SQLiteDatabase d=getWritableDatabase();ContentValues v=new ContentValues();v.put("id",id);v.put("name",name);v.put("bbox",minLat+","+minLon+","+maxLat+","+maxLon);v.put("pts",pts);v.put("updated",System.currentTimeMillis());d.insertWithOnConflict("ways",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 public synchronized ArrayList<RoadWay> near(double lat,double lon,double deg){ArrayList<RoadWay> a=new ArrayList<>();SQLiteDatabase d=getReadableDatabase();Cursor c=d.rawQuery("SELECT id,name,bbox,pts FROM ways",null);while(c.moveToNext()){String[] b=c.getString(2).split(",");try{double minLa=Double.parseDouble(b[0]),minLo=Double.parseDouble(b[1]),maxLa=Double.parseDouble(b[2]),maxLo=Double.parseDouble(b[3]);if(maxLa>=lat-deg&&minLa<=lat+deg&&maxLo>=lon-deg&&minLo<=lon+deg)a.add(new RoadWay(c.getString(0),c.getString(1),decode(c.getString(3))));}catch(Exception e){}}c.close();return a;}
 static ArrayList<Geo> decode(String s){ArrayList<Geo>a=new ArrayList<>();for(String q:s.split(";")){String[]z=q.split(",");if(z.length==2)try{a.add(new Geo(Double.parseDouble(z[0]),Double.parseDouble(z[1])));}catch(Exception e){}}return a;}
}
class RoadWay{String id,name;ArrayList<Geo> pts;RoadWay(String i,String n,ArrayList<Geo>p){id=i;name=n;pts=p;}}
class Geo{double lat,lon;Geo(double a,double b){lat=a;lon=b;}}
