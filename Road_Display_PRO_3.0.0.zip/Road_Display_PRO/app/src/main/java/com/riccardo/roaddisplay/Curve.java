package com.riccardo.roaddisplay;
public class Curve{
 boolean valid=false; int type=1,dir=1; float distance=0,recommended=0,grade=0,confidence=0; double radius=0;
 String label="",roadId="",source="";
}
