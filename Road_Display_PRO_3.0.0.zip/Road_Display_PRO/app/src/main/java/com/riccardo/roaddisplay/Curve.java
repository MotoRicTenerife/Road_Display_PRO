package com.riccardo.roaddisplay;
public class Curve{boolean valid=false;int type=1,dir=1;float distance=0,recommended=0,grade=0;double radius=0;String label="";
 static Curve demo(int t,int d,float dist,float rec,float g){Curve c=new Curve();c.valid=true;c.type=t;c.dir=d;c.distance=dist;c.recommended=rec;c.grade=g;String[]a={"","LEGGERA","MEDIA","STRETTA","TORNANTE"};c.label=a[t];return c;}}
