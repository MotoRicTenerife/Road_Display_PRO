package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.location.GnssStatus;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.speech.tts.TextToSpeech;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.app.AlertDialog;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    static final int REQ_LOC = 42;
    RideView view;
    LocationManager lm;
    LocationListener listener;
    RoadDb db;
    RoadEngine engine;
    TripDb tripDb;
    TripRecorder tripRecorder;
    volatile boolean tripRecording = false;
    volatile long selectedTripId = -1L;
    volatile java.util.ArrayList<TripDb.Point> selectedTripPoints = new java.util.ArrayList<>();
    volatile TripDb.TripSummary selectedTripSummary;
    ToneGenerator tone;
    TextToSpeech navigationTts;
    volatile boolean navigationTtsReady = false;
    volatile int lastSpokenNavigationStep = -1;
    volatile int lastSpokenNavigationStage = -1; // 0<=600m, 1<=300m, 2<=150m, 3<=50m
    boolean audio = true;                 // Audio is enabled from launch; no activation overlay.
    boolean tripsScreen = false;
    boolean tripDayScreen = false;
    String selectedTripDayKey = "";
    boolean navigationActive = false;
    volatile boolean navigationLoading = false;
    volatile String navigationStatus = "";
    volatile String navigationInstruction = "";
    volatile String navigationDistance = "";
    volatile String navigationDestinationDistance = "";
    volatile double navigationDestLat = Double.NaN, navigationDestLon = Double.NaN;
    volatile String navigationDestinationLabel = "";
    volatile long navigationLastRouteAt = 0L;
    volatile boolean navigationRerouteInProgress = false;
    volatile long navigationLastRerouteAt = 0L;
    volatile long navigationOffRouteSince = 0L;
    volatile float navigationRouteDeviation = 0f;
    volatile boolean lastCurveWarningValid = false;
    volatile float lastCurveWarningDistance = Float.MAX_VALUE;
    volatile long lastCurveRouteFetchAt = 0L;
    volatile boolean curveRouteFetchInProgress = false;
    final ArrayList<RoutePoint> curvePreviewRoute = new ArrayList<>();
    static final class RoutePoint {
        final double lat, lon;
        RoutePoint(double lat, double lon) { this.lat = lat; this.lon = lon; }
    }
    static final class RouteStep {
        double lat, lon, distance;
        String instruction, roadName, maneuverType;
        int roundaboutExit;
        RouteStep(double lat, double lon, double distance, String instruction, String roadName, String maneuverType, int roundaboutExit) {
            this.lat = lat; this.lon = lon; this.distance = distance;
            this.instruction = instruction;
            this.roadName = roadName == null ? "" : roadName;
            this.maneuverType = maneuverType == null ? "" : maneuverType;
            this.roundaboutExit = roundaboutExit;
        }
    }
    final Object navigationLock = new Object();
    final ArrayList<RoutePoint> navigationRoute = new ArrayList<>();
    final ArrayList<RouteStep> navigationSteps = new ArrayList<>();
    int navigationStepIndex = 0;
    String installDate = "";
    volatile boolean downloadingRoads = false;
    volatile boolean roadDownloadAttempted = false;
    int satellitesVisible = 0;
    int satellitesUsed = 0;
    GnssStatus.Callback gnssCallback;
    long lastOnline = 0;
    Location previousMapLocation;
    long lastUiLocationRefreshAt = 0L;
    Location lastUiRefreshLocation;
    double lastRoadDownloadLat = Double.NaN, lastRoadDownloadLon = Double.NaN;
    boolean lastRoadDownloadGpsAccurate = false;
    float mapBearing = 0f;
    boolean hasMapBearing = false;
    volatile long lastWeatherAt = 0L;
    // Public Nominatim geocoding is used only for explicit user requests; enforce its 1 req/s limit.
    volatile long lastNominatimGeocodeAt = 0L;
    volatile double lastWeatherLat = Double.NaN, lastWeatherLon = Double.NaN;
    volatile boolean weatherLoading = false;
    volatile String weatherSummary = "METEO IN ATTESA";
    volatile String weatherPlaceName = "";
    volatile String weatherDetail = "";
    volatile boolean weatherAdverse = false;
    volatile String weatherHourlySummary = "";
    volatile String destinationWeatherSummary = "";
    volatile String destinationWeatherHourlySummary = "";
    volatile boolean destinationWeatherLoading = false;
    volatile boolean showWeatherDetails = false;
    volatile boolean approximateLocation = false;
    volatile boolean gpsSignalLost = true;
    volatile long lastAccurateGpsAt = 0L;
    final android.os.Handler gpsHealthHandler = new android.os.Handler(Looper.getMainLooper());
    final Runnable gpsHealthCheck = new Runnable() { @Override public void run() {
        long now = System.currentTimeMillis();
        if (lastAccurateGpsAt == 0L || now - lastAccurateGpsAt > 4000L) {
            if (!gpsSignalLost) {
                gpsSignalLost = true;
                currentSpeedLimitKmh = 0;
                if (engine != null) { engine.current = new Curve(); engine.noRoad = true; }
                if (view != null) view.invalidate();
            }
        }
        gpsHealthHandler.postDelayed(this, 1000L);
    }};
        volatile String roadDataStatus = "";
    volatile String airTemperature = "--°";
    volatile float deviceAmbientTemperature = Float.NaN;
    volatile boolean hasDeviceAmbientTemperature = false;
    SensorManager temperatureSensorManager;
    Sensor ambientTemperatureSensor;
    SensorEventListener ambientTemperatureListener;
    double dailyKm = 0.0;
    volatile int currentSpeedLimitKmh = 0;
    boolean speedLimitAlerted = false;
    boolean radarAlerted = false;
    volatile long radarAlertUntil = 0L;
    volatile int radarFlashToggles = 0;
    Location lastDistanceLocation;
    String dailyDistanceDate = "";
    SensorManager lightSensorManager;
    Sensor lightSensor;
    SensorEventListener lightSensorListener;
    float originalWindowBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
    boolean brightnessCaptured = false;
    static final String PREF_HOME_ADDRESS = "home_address";
    static final String PREF_HOME_LAT = "home_lat";
    static final String PREF_HOME_LON = "home_lon";
    static final String PREF_RECENT_DESTINATIONS = "recent_destinations";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Adjust only this Activity's window brightness using the ambient-light sensor;
        // restore the previous window setting when the app leaves the foreground.
        originalWindowBrightness = getWindow().getAttributes().screenBrightness;
        brightnessCaptured = true;
        lightSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (lightSensorManager != null) lightSensor = lightSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        temperatureSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (temperatureSensorManager != null) {
            ambientTemperatureSensor = temperatureSensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
            if (ambientTemperatureSensor != null) {
                ambientTemperatureListener = new SensorEventListener() {
                    @Override public void onSensorChanged(SensorEvent event) {
                        if (event == null || event.values == null || event.values.length == 0) return;
                        float t = event.values[0];
                        if (t > -40f && t < 80f) {
                            deviceAmbientTemperature = t;
                            hasDeviceAmbientTemperature = true;
                            if (view != null) view.postInvalidate();
                        }
                    }
                    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
                };
                temperatureSensorManager.registerListener(ambientTemperatureListener, ambientTemperatureSensor, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
        lightSensorListener = new SensorEventListener() {
            @Override public void onSensorChanged(SensorEvent event) {
                if (event == null || event.values == null || event.values.length == 0) return;
                float lux = Math.max(0f, event.values[0]);
                final float target = lux < 3f ? 0.25f : lux < 20f ? 0.40f : lux < 80f ? 0.65f : lux < 400f ? 0.88f : 1.0f;
                runOnUiThread(() -> setWindowBrightness(target));
            }
            @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
        };
        immersive();
        android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
        installDate = prefs.getString("install_date", "");
        if (installDate.isEmpty()) {
            long firstInstall = System.currentTimeMillis();
            try { firstInstall = getPackageManager().getPackageInfo(getPackageName(), 0).firstInstallTime; } catch (Exception ignored) { }
            installDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(firstInstall));
            prefs.edit().putString("install_date", installDate).apply();
        }
        db = new RoadDb(this);
        engine = new RoadEngine(db);
        tripDb = new TripDb(this);
        tripDb.recoverInterruptedTrips(System.currentTimeMillis());
        tripRecorder = new TripRecorder(tripDb, new TripRecorder.Listener() {
            @Override public void onTripStateChanged(boolean recording, long tripId) {
                tripRecording = recording;
                if (view != null) view.postInvalidate();
            }
        });
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        navigationTts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = navigationTts.setLanguage(new Locale("it", "IT"));
                navigationTtsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                navigationTts.setSpeechRate(0.95f);
                navigationTts.setPitch(1.0f);
            }
        });
        view = new RideView(this);
        setContentView(view);
        requestLocation();
        gpsHealthHandler.post(gpsHealthCheck);
    }

    void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        startGps();
    }

    void startGps() {
        if (lm != null) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) { processLocation(l); }
            @Override public void onProviderEnabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onProviderDisabled(String p) { gpsSignalLost = true; if (view != null) view.invalidate(); }
            @Override public void onStatusChanged(String p, int s, Bundle e) { if (view != null) view.invalidate(); }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = 0, used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) {
                        if (status.usedInFix(i)) used++;
                        visible++;
                    }
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (view != null) view.invalidate();
                }
            };
            try { lm.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper())); }
            catch (Exception ignored) { }
        }
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 250, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 15000, 500, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }

        // Use a recent system last-known position immediately, even before a fresh GPS fix arrives.
        Location best = null;
        String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String provider : providers) {
            try {
                Location candidate = lm.getLastKnownLocation(provider);
                if (candidate != null && (best == null ||
                        (candidate.hasAccuracy() && (!best.hasAccuracy() || candidate.getAccuracy() < best.getAccuracy())) ||
                        candidate.getTime() > best.getTime() + 120000L)) best = candidate;
            } catch (SecurityException ignored) { }
            catch (Exception ignored) { }
        }
        if (best != null) processLocation(best);
        else {
            Location saved = loadSavedLocation();
            if (saved != null) processLocation(saved);
        }
    }

    void processLocation(Location l) {
        if (l == null) return;
        boolean accurateGps = LocationManager.GPS_PROVIDER.equals(l.getProvider()) && l.hasAccuracy() && l.getAccuracy() <= 50f;
        if (accurateGps) { lastAccurateGpsAt = System.currentTimeMillis(); gpsSignalLost = false; }
        approximateLocation = !accurateGps;
        updateMapBearing(l);
        if (accurateGps) {
            updateDailyDistance(l);
            if (tripRecorder != null) tripRecorder.accept(l);
            boolean warn = engine.update(l);
            // During active navigation, evaluate curves directly on the actual routed
            // geometry. The old nearby-OSM-way detector is still used in free RIDE mode,
            // but navigation must use the same road geometry the rider is actually following.
            if (navigationActive) {
                synchronized (navigationLock) {
                    if (navigationRoute.size() >= 4) {
                        Curve routeCurve = engine.findCurveOnRoute(l, navigationRoute);
                        RouteStep roundabout = upcomingRoundaboutLocked(l);
                        if (roundabout != null) {
                            Curve rq = new Curve();
                            rq.valid = true;
                            rq.type = 5;
                            rq.dir = directionFromModifier(roundabout.maneuverType);
                            rq.distance = (float) distanceMeters(l.getLatitude(), l.getLongitude(), roundabout.lat, roundabout.lon);
                            rq.label = "ROTONDA";
                            rq.recommended = 0f;
                            engine.current = rq;
                            warn = rq.distance <= 100f && (!lastCurveWarningValid || lastCurveWarningDistance > 100f);
                            lastCurveWarningValid = true;
                            lastCurveWarningDistance = rq.distance;
                        } else if (routeCurve.valid) {
                            engine.current = routeCurve;
                            warn = routeCurve.distance <= 100f && (!lastCurveWarningValid || lastCurveWarningDistance > 100f);
                            lastCurveWarningValid = true;
                            lastCurveWarningDistance = routeCurve.distance;
                        } else {
                            engine.current = new Curve();
                            lastCurveWarningValid = false;
                            lastCurveWarningDistance = Float.MAX_VALUE;
                        }
                    }
                }
            } else {
                lastCurveWarningValid = engine.current != null && engine.current.valid;
                lastCurveWarningDistance = lastCurveWarningValid ? engine.current.distance : Float.MAX_VALUE;
                if (!lastCurveWarningValid && l.hasBearing() && l.getSpeed() >= 8f) requestCurvePreview(l);
            }
            if (warn && engine.current.valid) {
                if (engine.current.type == 4) beep(2, true);
                else if (engine.current.type == 5) beep(2, false);
                else beep(engine.current.type, false);
            }
            currentSpeedLimitKmh = engine.speedLimitKmh(l);
            if (engine.current != null && engine.current.valid) engine.current.recommended = engine.recommend(engine.current, currentSpeedLimitKmh, engine.highwayNear(l));
            double radarDistance = engine.nearestRadarMeters(l);
            if (radarDistance <= 300.0 && radarDistance >= 5.0) {
                if (!radarAlerted) { triggerRadarAlert(); radarAlerted = true; }
            } else if (radarDistance > 360.0 || Double.isInfinite(radarDistance)) {
                radarAlerted = false;
            }
            float actualKmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            if (currentSpeedLimitKmh > 0 && actualKmh > currentSpeedLimitKmh + 3f) {
                if (!speedLimitAlerted) { beepSpeedLimit(); speedLimitAlerted = true; }
            } else if (currentSpeedLimitKmh <= 0 || actualKmh <= currentSpeedLimitKmh - 3f) {
                speedLimitAlerted = false;
            }
        } else {
            // Approximate/network locations are for map loading only, never curve or speed advice.
            // Never keep an old speed limit alive after GPS quality is lost.
            currentSpeedLimitKmh = 0;
            speedLimitAlerted = false;
            engine.loc = new Location(l);
            engine.current = new Curve();
            engine.noRoad = true;
            engine.reloadRoads(l);
        }
        if (!"ip-approx".equals(l.getProvider())) saveLocation(l);
        // Coalesce GPS callbacks: avoid redrawing the entire dashboard/map for every tiny fix.
        long uiNow = System.currentTimeMillis();
        float uiMoved = lastUiRefreshLocation == null ? Float.MAX_VALUE : lastUiRefreshLocation.distanceTo(l);
        if (view != null && (lastUiLocationRefreshAt == 0L ||
                (uiNow - lastUiLocationRefreshAt >= 750L && uiMoved >= 2f) ||
                uiNow - lastUiLocationRefreshAt >= 1500L)) {
            lastUiLocationRefreshAt = uiNow;
            lastUiRefreshLocation = new Location(l);
            view.invalidate();
        }
        long now = System.currentTimeMillis();
        boolean firstRoadLoad = !roadDownloadAttempted;
        boolean movedFar = !Double.isNaN(lastRoadDownloadLat) &&
                distanceMeters(lastRoadDownloadLat, lastRoadDownloadLon, l.getLatitude(), l.getLongitude()) >= 8000.0;
        boolean gpsQualityChanged = accurateGps && !lastRoadDownloadGpsAccurate;
        boolean retryFailed = roadDownloadAttempted && (engine.mapWays == null || engine.mapWays.isEmpty()) && now - lastOnline >= 120000L;
        boolean cacheExpired = now - lastOnline >= 6L * 60L * 60L * 1000L;
        // A coarse or network-derived fix is still enough to fetch/display a regional map.
        if (!downloadingRoads && (firstRoadLoad || movedFar || gpsQualityChanged || retryFailed || cacheExpired)) {
            lastOnline = now;
            lastRoadDownloadLat = l.getLatitude(); lastRoadDownloadLon = l.getLongitude(); lastRoadDownloadGpsAccurate = accurateGps;
            downloadingRoads = true;
            roadDownloadAttempted = true;
            roadDataStatus = tr("SCARICO STRADE…");
            Location requestLocation = new Location(l);
            new Thread(() -> {
                boolean ok = false;
                try {
                    ok = engine.fetchOnline(requestLocation);
                    engine.reloadRoads(requestLocation);
                    roadDataStatus = ok || (engine.mapWays != null && !engine.mapWays.isEmpty())
                            ? "" : tr("DATI STRADALI NON DISPONIBILI");
                } finally {
                    downloadingRoads = false;
                    if (view != null) view.postInvalidate();
                }
            }, "road-data-download").start();
        }
        // Weather is strictly GPS-based: never use IP/network approximations for weather data.
        if (accurateGps) maybeUpdateWeather(l, false);
        if (accurateGps && view != null) view.updateNavigation(l);
    }

    void requestCurvePreview(Location l) {
        long now=System.currentTimeMillis();
        if(curveRouteFetchInProgress||now-lastCurveRouteFetchAt<20000L)return;
        curveRouteFetchInProgress=true; lastCurveRouteFetchAt=now;
        final Location start=new Location(l);
        double distanceAhead=1200.0;
        double lat2=start.getLatitude() + (distanceAhead/110540.0)*Math.cos(Math.toRadians(start.getBearing()));
        double lon2=start.getLongitude() + (distanceAhead/(111320.0*Math.max(0.2,Math.cos(Math.toRadians(start.getLatitude())))))*Math.sin(Math.toRadians(start.getBearing()));
        new Thread(() -> {
            HttpURLConnection c=null;
            try{
                String u="https://router.project-osrm.org/route/v1/driving/"+start.getLongitude()+","+start.getLatitude()+";"+lon2+","+lat2+
                        "?overview=full&geometries=geojson&steps=false&alternatives=false&continue_straight=true";
                c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(12000);c.setRequestMethod("GET");
                c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RoadDisplayPRO/3.22.17 (Android motorcycle dashboard)");
                if(c.getResponseCode()!=HttpURLConnection.HTTP_OK)throw new Exception("HTTP");
                JSONObject root=new JSONObject(readConnection(c));JSONArray rs=root.optJSONArray("routes");
                if(rs==null||rs.length()==0)throw new Exception("no route");
                JSONObject g=rs.getJSONObject(0).optJSONObject("geometry");JSONArray pts=g==null?null:g.optJSONArray("coordinates");
                if(pts==null||pts.length()<4)throw new Exception("no geometry");
                ArrayList<RoutePoint> preview=new ArrayList<>();
                for(int i=0;i<pts.length();i++){JSONArray p=pts.getJSONArray(i);if(p.length()>=2)preview.add(new RoutePoint(p.getDouble(1),p.getDouble(0)));}
                synchronized(curvePreviewRoute){curvePreviewRoute.clear();curvePreviewRoute.addAll(preview);}
                Curve q=engine.findCurveOnRoute(start,curvePreviewRoute);
                if(q.valid){engine.current=q;lastCurveWarningValid=true;lastCurveWarningDistance=q.distance;}
                if(view!=null)view.postInvalidate();
            }catch(Exception ignored){}finally{if(c!=null)try{c.disconnect();}catch(Exception ignored){}curveRouteFetchInProgress=false;}
        },"curve-preview-route").start();
    }

    void updateDailyDistance(Location l) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
        if (!today.equals(dailyDistanceDate)) {
            if (!dailyDistanceDate.isEmpty()) prefs.edit().putLong("trip_" + dailyDistanceDate, Double.doubleToLongBits(dailyKm)).apply();
            dailyDistanceDate = today;
            dailyKm = Double.longBitsToDouble(prefs.getLong("trip_" + today, Double.doubleToLongBits(0.0)));
            lastDistanceLocation = null;
        }
        if (lastDistanceLocation != null) {
            float delta = lastDistanceLocation.distanceTo(l);
            long age = Math.abs(l.getTime() - lastDistanceLocation.getTime());
            // Ignore GPS jumps and stale fixes; count only plausible movement between fresh fixes.
            if (delta >= 2f && delta <= 2000f && age <= 120000L) {
                dailyKm += delta / 1000.0;
                prefs.edit().putString("daily_date", today).putLong("daily_km_bits", Double.doubleToLongBits(dailyKm)).putLong("trip_" + today, Double.doubleToLongBits(dailyKm)).apply();
            }
        }
        lastDistanceLocation = new Location(l);
    }

    void saveLocation(Location l) {
        try {
            getSharedPreferences("road_display", MODE_PRIVATE).edit()
                    .putString("last_lat", Double.toString(l.getLatitude()))
                    .putString("last_lon", Double.toString(l.getLongitude()))
                    .putLong("last_time", System.currentTimeMillis()).apply();
        } catch (Exception ignored) { }
    }

    Location loadSavedLocation() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
            String lat = prefs.getString("last_lat", null), lon = prefs.getString("last_lon", null);
            if (lat == null || lon == null) return null;
            Location saved = new Location("saved-network");
            saved.setLatitude(Double.parseDouble(lat)); saved.setLongitude(Double.parseDouble(lon));
            saved.setAccuracy(5000f); saved.setTime(prefs.getLong("last_time", System.currentTimeMillis()));
            return saved;
        } catch (Exception ignored) { return null; }
    }

    String tr(String it) {
        String lang = Locale.getDefault().getLanguage();
        if ("it".equals(lang) || lang == null) return it;
        String es = "es".equals(lang) ? "es" : "en";
        String[][] rows = {
            {"GPS IN RICERCA","GPS BUSCANDO","GPS SEARCHING"}, {"GPS DEBOLE","GPS DÉBIL","WEAK GPS"},
            {"GPS OK","GPS OK","GPS OK"}, {"DATI STRADALI IN ATTESA","ESPERANDO DATOS DE CARRETERA","WAITING FOR ROAD DATA"},
            {"DATI STRADALI NON DISPONIBILI","DATOS DE CARRETERA NO DISPONIBLES","ROAD DATA UNAVAILABLE"},
            {"SCARICO STRADE…","DESCARGANDO CARRETERAS…","DOWNLOADING ROADS…"},
            {"DOWNLOAD DATI STRADALI…","DESCARGANDO DATOS…","DOWNLOADING ROAD DATA…"},
            {"STRADE IN ATTESA","ESPERANDO CARRETERAS","WAITING FOR ROADS"}, {"DIREZIONE IN ATTESA","ESPERANDO DIRECCIÓN","WAITING FOR HEADING"},
            {"NESSUNA CURVA RILEVATA","NO SE DETECTA CURVA","NO CURVE DETECTED"}, {"LEGGERA","SUAVE","MILD"},
            {"MEDIA","MEDIA","MEDIUM"}, {"STRETTA","CERRADA","SHARP"}, {"TORNANTE","HORQUILLA","HAIRPIN"},
            {"SINISTRA","IZQUIERDA","LEFT"}, {"DESTRA","DERECHA","RIGHT"}, {"CONSIGLIATA","RECOMENDADA","RECOMMENDED"},
            {"VELOCITÀ","VELOCIDAD","SPEED"}, {"DISTANZA","DISTANCIA","DISTANCE"}, {"PENDENZA","PENDIENTE","GRADE"},
            {"SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA","SIMULACIÓN: NO USAR COMO INDICACIÓN DE SEGURIDAD","SIMULATION: NOT A SAFETY RECOMMENDATION"},
            {"AUDIO ON","AUDIO ACTIVADO","AUDIO ON"}, {"METEO IN ATTESA","METEO PENDIENTE","WEATHER PENDING"},
            {"METEO NON DISPONIBILE","METEO NO DISPONIBLE","WEATHER UNAVAILABLE"}, {"SERENO","DESPEJADO","CLEAR"},
            {"NUVOLOSO","NUBLADO","CLOUDY"}, {"NEBBIA","NIEBLA","FOG"}, {"PIOVIGGINE","LLOVIZNA","DRIZZLE"},
            {"PIOVIGGINE GELATA","LLUVIA ENGELANTE","FREEZING DRIZZLE"}, {"PIOGGIA","LLUVIA","RAIN"},
            {"PIOGGIA GELATA","LLUVIA ENGELANTE","FREEZING RAIN"}, {"NEVE","NIEVE","SNOW"}, {"ROVESCI","CHUBASCOS","SHOWERS"},
            {"ROVESCI DI NEVE","CHUBASCOS DE NIEVE","SNOW SHOWERS"}, {"TEMPORALE","TORMENTA","THUNDERSTORM"},
            {"ATTENZIONE METEO","ALERTA METEOROLÓGICA","WEATHER ALERT"}, {"MAPPA · RAGGIO 1000 m","MAPA · RADIO 1000 m","MAP · 1000 m RADIUS"},
            {"MAPPA · RAGGIO 1000 m · TRASCINA PER SCORRERE","MAPA · RADIO 1000 m · ARRASTRA PARA MOVER","MAP · 1000 m RADIUS · DRAG TO PAN"},
            {"CHIUDI ✕","CERRAR ✕","CLOSE ✕"}, {"← RIDE","← CONDUCCIÓN","← RIDE"}, {"METEO ↻","METEO ↻","WEATHER ↻"},
            {"METEO…","METEO…","WEATHER…"}, {"ATTIVA AUDIO","ACTIVAR AUDIO","ENABLE AUDIO"},
            {"MAPPA IN ATTESA","MAPA PENDIENTE","MAP WAITING"},
            {"POSIZIONE APPROSSIMATIVA","POSICIÓN APROXIMADA","APPROXIMATE LOCATION"},
            {"POSIZIONE RETE","POSICIÓN DE RED","NETWORK LOCATION"},
            {"CARICAMENTO MAPPA…","CARGANDO MAPA…","LOADING MAP…"},
            {"MAPPA NON DISPONIBILE","MAPA NO DISPONIBLE","MAP UNAVAILABLE"},
            {"TEMPERATURA","TEMPERATURA","TEMPERATURE"}, {"TEMP","TEMP","TEMP"}
        };
        for (String[] row : rows) if (row[0].equals(it)) return row["es".equals(es) ? 1 : 2];
        return it;
    }

    void maybeUpdateWeather(Location location, boolean manual) {
        if (location == null || weatherLoading) return;
        // Weather must always correspond to a real GPS fix from this device.
        if (!LocationManager.GPS_PROVIDER.equals(location.getProvider())
                || !location.hasAccuracy() || location.getAccuracy() > 50f) return;
        long now = System.currentTimeMillis();
        boolean timeDue = lastWeatherAt == 0L || now - lastWeatherAt >= 15L * 60L * 1000L;
        boolean distanceDue = !Double.isNaN(lastWeatherLat) &&
                distanceMeters(lastWeatherLat, lastWeatherLon, location.getLatitude(), location.getLongitude()) >= 10000.0;
        if (!manual && !timeDue && !distanceDue) return;
        weatherLoading = true;
        Location at = new Location(location);
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String urlText = "https://api.open-meteo.com/v1/forecast?latitude=" + at.getLatitude()
                        + "&longitude=" + at.getLongitude()
                        + "&current=temperature_2m,apparent_temperature,precipitation,rain,showers,weather_code,wind_speed_10m,wind_gusts_10m"
                        + "&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m"
                        + "&forecast_days=2&timezone=auto&models=best_match";
                connection = (HttpURLConnection) new URL(urlText).openConnection();
                connection.setConnectTimeout(10000); connection.setReadTimeout(15000);
                connection.setRequestMethod("GET");
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) throw new IllegalStateException("HTTP " + connection.getResponseCode());
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject response = new JSONObject(body.toString());
                JSONObject root = response.getJSONObject("current");
                int code = root.optInt("weather_code", -1);
                double temp = root.optDouble("temperature_2m", Double.NaN);
                double rain = root.optDouble("precipitation", 0.0);
                double wind = root.optDouble("wind_speed_10m", 0.0);
                double gust = root.optDouble("wind_gusts_10m", wind);
                String condition = weatherCodeLabel(code);
                weatherSummary = condition + (Double.isNaN(temp) ? "" : " · " + Math.round(temp) + "°C");
                // Keep the meteorological 2 m air temperature as the displayed value.
                // If the handset exposes a real ambient-temperature sensor, its reading is
                // collected separately for future calibrated fusion, but is not mixed in with
                // an arbitrary weighting: a phone on a handlebar can be warmed by sunlight,
                // its own electronics and the vehicle.
                airTemperature = Double.isNaN(temp) ? "--°" : Math.round(temp) + "°";
                String windLabel = "es".equals(Locale.getDefault().getLanguage()) ? "viento" : "en".equals(Locale.getDefault().getLanguage()) ? "wind" : "vento";
                String gustLabel = "es".equals(Locale.getDefault().getLanguage()) ? "rachas" : "en".equals(Locale.getDefault().getLanguage()) ? "gusts" : "raffiche";
                String rainLabel = "es".equals(Locale.getDefault().getLanguage()) ? "lluvia" : "en".equals(Locale.getDefault().getLanguage()) ? "rain" : "pioggia";
                weatherDetail = windLabel + " " + Math.round(wind) + " km/h · " + gustLabel + " " + Math.round(gust) + " km/h · " + rainLabel + " " + String.format(Locale.getDefault(), "%.1f", rain) + " mm";
                weatherHourlySummary = formatHourlyWeather(response.optJSONObject("hourly"));
                weatherAdverse = code >= 95 || code == 65 || code == 67 || code == 82 || code == 86 || rain >= 2.0 || gust >= 60.0;
                lastWeatherAt = System.currentTimeMillis();
                lastWeatherLat = at.getLatitude(); lastWeatherLon = at.getLongitude();
                String place = reverseWeatherPlace(at.getLatitude(), at.getLongitude());
                if (place != null && !place.isEmpty()) weatherPlaceName = place;
            } catch (Exception ex) {
                if (lastWeatherAt == 0L) weatherSummary = tr("METEO NON DISPONIBILE");
                weatherDetail = tr("METEO NON DISPONIBILE") + " · " + ("es".equals(Locale.getDefault().getLanguage()) ? "comprueba la conexión" : "en".equals(Locale.getDefault().getLanguage()) ? "check connection" : "verifica connessione");
                lastWeatherAt = System.currentTimeMillis();
            } finally {
                if (connection != null) connection.disconnect();
                weatherLoading = false;
                if (view != null) view.postInvalidate();
            }
        }, "weather-update").start();
    }

    String reverseWeatherPlace(double lat, double lon) {
        HttpURLConnection c = null;
        try {
            String urlText = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=" + lat + "&lon=" + lon + "&zoom=18&addressdetails=1&accept-language=it";
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestMethod("GET");
            c.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.22.6 (Android motorcycle display)");
            if (c.getResponseCode() != HttpURLConnection.HTTP_OK) return "";
            JSONObject root = new JSONObject(readConnection(c));
            JSONObject a = root.optJSONObject("address");
            if (a == null) return root.optString("display_name", "");
            String locality = firstNonEmpty(a.optString("village", ""), a.optString("town", ""), a.optString("city", ""), a.optString("municipality", ""), a.optString("suburb", ""), a.optString("hamlet", ""));
            String municipality = firstNonEmpty(a.optString("municipality", ""), a.optString("city", ""), a.optString("town", ""));
            if (!locality.isEmpty() && !municipality.isEmpty() && !locality.equalsIgnoreCase(municipality)) return locality + ", " + municipality;
            if (!locality.isEmpty()) return locality;
            return root.optString("display_name", "");
        } catch (Exception ignored) {
            return "";
        } finally { if (c != null) c.disconnect(); }
    }

    String firstNonEmpty(String... values) {
        for (String v : values) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }


    String formatHourlyWeather(JSONObject hourly) {
        if (hourly == null) return "";
        JSONArray times = hourly.optJSONArray("time");
        JSONArray temps = hourly.optJSONArray("temperature_2m");
        JSONArray codes = hourly.optJSONArray("weather_code");
        JSONArray probs = hourly.optJSONArray("precipitation_probability");
        if (times == null || temps == null) return "";
        StringBuilder out = new StringBuilder();
        int count = Math.min(8, times.length());
        java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
        java.text.SimpleDateFormat hm = new java.text.SimpleDateFormat("HH:mm", Locale.getDefault());
        for (int i=0;i<count;i++) {
            try {
                String ts=times.optString(i,"");
                Date dt=in.parse(ts);
                String hour=dt==null?ts:hm.format(dt);
                int code=codes==null?-1:codes.optInt(i,-1);
                double temp=temps.optDouble(i,Double.NaN);
                int prob=probs==null?-1:probs.optInt(i,-1);
                if (i>0) out.append("\n");
                out.append(hour).append("  ").append(weatherCodeLabel(code));
                if (!Double.isNaN(temp)) out.append("  ").append(Math.round(temp)).append("°C");
                if (prob>=0) out.append("  ").append(prob).append("% pioggia");
            } catch(Exception ignored) {}
        }
        return out.toString();
    }

    void loadDestinationWeather() {
        if (!navigationActive || Double.isNaN(navigationDestLat) || Double.isNaN(navigationDestLon)) {
            destinationWeatherSummary=""; destinationWeatherHourlySummary=""; return;
        }
        destinationWeatherLoading=true;
        final double lat=navigationDestLat, lon=navigationDestLon;
        new Thread(() -> {
            HttpURLConnection connection=null;
            try {
                String urlText="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon
                        +"&current=temperature_2m,weather_code,wind_speed_10m,wind_gusts_10m,precipitation"
                        +"&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m"
                        +"&forecast_days=2&timezone=auto&models=best_match";
                connection=(HttpURLConnection)new URL(urlText).openConnection();
                connection.setConnectTimeout(10000); connection.setReadTimeout(15000); connection.setRequestMethod("GET");
                if(connection.getResponseCode()!=HttpURLConnection.HTTP_OK) throw new IllegalStateException("HTTP "+connection.getResponseCode());
                String body=readConnection(connection);
                JSONObject root=new JSONObject(body);
                JSONObject cur=root.getJSONObject("current");
                int code=cur.optInt("weather_code",-1);
                double temp=cur.optDouble("temperature_2m",Double.NaN);
                double wind=cur.optDouble("wind_speed_10m",0);
                double gust=cur.optDouble("wind_gusts_10m",wind);
                destinationWeatherSummary=weatherCodeLabel(code)+(Double.isNaN(temp)?"":" · "+Math.round(temp)+"°C")+" · vento "+Math.round(wind)+" km/h · raffiche "+Math.round(gust)+" km/h";
                destinationWeatherHourlySummary=formatHourlyWeather(root.optJSONObject("hourly"));
            } catch(Exception ex) {
                destinationWeatherSummary="METEO DESTINAZIONE NON DISPONIBILE";
                destinationWeatherHourlySummary="";
            } finally {
                if(connection!=null) connection.disconnect();
                destinationWeatherLoading=false;
                if(view!=null) view.postInvalidate();
            }
        },"destination-weather").start();
    }

    String readConnection(HttpURLConnection c) throws Exception {
        StringBuilder b=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){String line;while((line=r.readLine())!=null)b.append(line);}
        return b.toString();
    }

    String weatherIcon() {
        String s = weatherSummary.toLowerCase(Locale.ROOT);
        if (s.contains("tempor") || s.contains("tempest")) return "⚡";
        if (s.contains("piogg") || s.contains("rain") || s.contains("lluv")) return "☂";
        if (s.contains("nuvol") || s.contains("cloud") || s.contains("nube")) return "☁";
        if (s.contains("vento") || s.contains("wind")) return "≋";
        if (s.contains("neve") || s.contains("snow")) return "❄";
        return "☀";
    }

    String weatherCodeLabel(int code) {
        switch (code) {
            case 0: return tr("SERENO");
            case 1: case 2: case 3: return tr("NUVOLOSO");
            case 45: case 48: return tr("NEBBIA");
            case 51: case 53: case 55: return tr("PIOVIGGINE");
            case 56: case 57: return tr("PIOVIGGINE GELATA");
            case 61: case 63: case 65: return tr("PIOGGIA");
            case 66: case 67: return tr("PIOGGIA GELATA");
            case 71: case 73: case 75: case 77: return tr("NEVE");
            case 80: case 81: case 82: return tr("ROVESCI");
            case 85: case 86: return tr("ROVESCI DI NEVE");
            case 95: case 96: case 99: return tr("TEMPORALE");
            default: return "METEO";
        }
    }

    void updateMapBearing(Location location) {
        if (location == null) return;
        if (location.hasBearing() && (!location.hasSpeed() || location.getSpeed() > 0.8f)) {
            mapBearing = location.getBearing();
            hasMapBearing = true;
        } else if (previousMapLocation != null) {
            float moved = previousMapLocation.distanceTo(location);
            if (moved >= 3.0f) {
                mapBearing = previousMapLocation.bearingTo(location);
                hasMapBearing = true;
            }
        }
        previousMapLocation = new Location(location);
    }

    void beep(int n, boolean longFirst) {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                if (longFirst) { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 520); Thread.sleep(180); }
                for (int i = 0; i < n; i++) { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(160); }
            } catch (Exception ignored) { }
        }, "curve-audio").start();
    }

    void triggerRadarAlert() {
        radarAlertUntil = System.currentTimeMillis() + 5000L;
        radarFlashToggles = 0;
        new Thread(() -> {
            try {
                if (audio && tone != null) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 2000);
                    Thread.sleep(2350);
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 2000);
                }
            } catch (Exception ignored) { }
        }, "radar-audio").start();
        final long until = radarAlertUntil;
        new Thread(() -> {
            while (System.currentTimeMillis() < until) {
                if (view != null) view.postInvalidate();
                try { Thread.sleep(250); } catch (InterruptedException ignored) { break; }
            }
            if (view != null) view.postInvalidate();
        }, "radar-flash").start();
    }

    void beepSpeedLimit() {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                for (int i = 0; i < 3; i++) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP, 85);
                    Thread.sleep(115);
                }
            } catch (Exception ignored) { }
        }, "speed-limit-audio").start();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_LOC && g != null) {
            boolean granted = false;
            for (int grant : g) if (grant == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) startGps(); else { if (view != null) view.invalidate(); }
        } else if (view != null) view.invalidate();
    }

    @Override public void onBackPressed() {
        if (view != null && view.mapExpanded) { view.mapExpanded = false; view.mapUserPanned = false; view.selectedMapLat = Double.NaN; view.selectedMapLon = Double.NaN; view.selectedMapPlaceName = ""; view.invalidate(); }
        else if (selectedTripId > 0) { selectedTripId = -1L; selectedTripSummary = null; selectedTripPoints.clear(); if (view != null) view.invalidate(); }
        else if (tripDayScreen) { tripDayScreen = false; selectedTripDayKey = ""; if (view != null) { view.tripsScroll = 0f; view.invalidate(); } }
        else if (tripsScreen) { tripsScreen = false; if (view != null) view.invalidate(); }
        else super.onBackPressed();
    }

    void setWindowBrightness(float brightness) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = Math.max(0.15f, Math.min(1f, brightness));
        getWindow().setAttributes(lp);
    }

    void restoreWindowBrightness() {
        if (!brightnessCaptured) return;
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = originalWindowBrightness;
        getWindow().setAttributes(lp);
    }

    @Override protected void onResume() {
        super.onResume();
        if (lightSensorManager != null && lightSensor != null && lightSensorListener != null) {
            try { lightSensorManager.registerListener(lightSensorListener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL); }
            catch (Exception ignored) { }
        }
    }

    @Override protected void onPause() {
        if (lightSensorManager != null && lightSensorListener != null) lightSensorManager.unregisterListener(lightSensorListener);
        restoreWindowBrightness();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (lm != null) {
            if (listener != null) lm.removeUpdates(listener);
            if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
                try { lm.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
            }
        }
        if (view != null) view.releaseTiles();
        if (tone != null) tone.release();
        if (navigationTts != null) { try { navigationTts.stop(); navigationTts.shutdown(); } catch (Exception ignored) {} }
        if (tripRecorder != null) tripRecorder.shutdown();
        if (tripDb != null) tripDb.close();
        if (db != null) db.close();
        super.onDestroy();
    }

    // Navigation helpers used by the outer GPS/location processing code.
    // These deliberately live in MainActivity (not RideView), because processLocation()
    // runs in the Activity scope.
    RouteStep upcomingRoundaboutLocked(Location l) {
        if (l == null || navigationSteps.isEmpty()) return null;
        int start = Math.max(0, Math.min(navigationStepIndex, navigationSteps.size() - 1));
        RouteStep best = null;
        double bestD = Double.MAX_VALUE;
        for (int i = start; i < Math.min(navigationSteps.size(), start + 2); i++) {
            RouteStep st = navigationSteps.get(i);
            String type = st.maneuverType == null ? "" : st.maneuverType.toLowerCase(Locale.ROOT);
            if (!("roundabout".equals(type) || "rotary".equals(type))) continue;
            double d = distanceMeters(l.getLatitude(), l.getLongitude(), st.lat, st.lon);
            if (d <= 350.0 && d < bestD) { best = st; bestD = d; }
        }
        return best;
    }

    int directionFromModifier(String type) {
        if (type == null) return 1;
        String x = type.toLowerCase(Locale.ROOT);
        return x.contains("left") ? -1 : 1;
    }

    class RideView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Curve emptyCurve = new Curve();
        final RectF mapBounds = new RectF(), tripMapBounds = new RectF(), tripsButtonBounds = new RectF(), navButtonBounds = new RectF(), exitButtonBounds = new RectF(), weatherButtonBounds = new RectF(), mapCloseBounds = new RectF(), mapRecenterBounds = new RectF(), mapSetDestBounds = new RectF(), mapSetHomeBounds = new RectF(), mapClearPointBounds = new RectF(), tripsCloseBounds = new RectF(), tripDetailHomeBounds = new RectF(), tripDetailListBounds = new RectF(), tripDetailDeleteBounds = new RectF(), tripMapZoomInBounds = new RectF(), tripMapZoomOutBounds = new RectF();
        boolean mapExpanded = false, draggingMap = false, movedMap = false;
        boolean mapUserPanned = false;
        float mapFrozenBearing = 0f;
        long lastRouteTilePriorityAt = 0L;
        float mapZoom = 1.5f, pinchStartDistance = 0f, pinchStartZoom = 1.5f;
        float mapZoomCompact = 1.5f;
        final RectF speedBounds = new RectF();
        double mapAnchorLat = Double.NaN, mapAnchorLon = Double.NaN;
        Location mapAnchorLocation;
        // Full-screen map owns a geographic viewport center. No pixel-pan accumulator or fling.
        double mapViewLat = Double.NaN, mapViewLon = Double.NaN;
        double selectedMapLat = Double.NaN, selectedMapLon = Double.NaN;
        String selectedMapPlaceName = "";
        volatile int selectedMapGeocodeToken = 0;
        long lastTileAnchorUpdate = 0L;
        boolean pinching = false;
        float tripsScroll = 0f;
        float downX, downY;
        double downMapLat = Double.NaN, downMapLon = Double.NaN;
        final int yellow = 0xFFFFD400, green = 0xFF00F080, blue = 0xFF42A5FF;
        final float density;
        final LruCache<String, Bitmap> tileBitmaps = new LruCache<String, Bitmap>(128 * 1024 * 1024) {
            @Override protected int sizeOf(String key, Bitmap value) { return value == null ? 0 : value.getByteCount(); }
        };
        // Stable last-known tile images prevent a blank/placeholder flash while a fresh tile arrives.
        final LruCache<String, Bitmap> stableTileBitmaps = new LruCache<String, Bitmap>(128 * 1024 * 1024) {
            @Override protected int sizeOf(String key, Bitmap value) { return value == null ? 0 : value.getByteCount(); }
        };
        final Set<String> tilesLoading = ConcurrentHashMap.newKeySet();
        final ConcurrentHashMap<String, Long> tileRetryAfter = new ConcurrentHashMap<>();
        final ConcurrentHashMap<String, Long> tileExpiries = new ConcurrentHashMap<>();
        final ExecutorService tileExecutor = Executors.newFixedThreadPool(3);
        volatile int tileFailures = 0;
        boolean tripMapRendering = false;
        boolean tripMapUserPanned = false;
        double tripMapCenterLat = Double.NaN, tripMapCenterLon = Double.NaN;
        boolean draggingTripMap = false;
        float tripDownX, tripDownY; double tripDownLat=Double.NaN, tripDownLon=Double.NaN;
        int tripMapZoom = 15;
        int tripMapZoomOffset = 0;

        RideView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            p.setTypeface(TypefaceCompat.bold());
            p.setTextAlign(Paint.Align.LEFT);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        float dp(float v) { return v * density; }
        float minDp() { return Math.min(getWidth(), getHeight()) / density; }
        void txt(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align) {
            p.setTextSize(Math.max(10f, sizeDp) * density);
            p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            c.drawText(s, x, y, p);
        }
        void panel(Canvas c, RectF r, int color, float radius) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(r, radius, radius, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.BLACK);
            if (mapExpanded) drawExpandedMap(c);
            else if (selectedTripId > 0) drawTripDetail(c); else if (tripDayScreen) drawTripDay(c); else if (tripsScreen) drawTrips(c); else drawRide(c);
            postInvalidateDelayed(1000); // Keep the on-screen clock current.
        }

        String now() { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); }
        String gpsSummary() {
            Location l = engine.loc;
            if (l == null || gpsSignalLost) return tr("GPS INSUFFICIENTE");
            String acc = l.hasAccuracy() ? " ±" + Math.round(l.getAccuracy()) + "m" : "";
            if ("ip-approx".equals(l.getProvider()) || "saved-network".equals(l.getProvider())) return tr("POSIZIONE APPROSSIMATIVA") + acc;
            if (satellitesVisible > 0 && LocationManager.GPS_PROVIDER.equals(l.getProvider())) return "GPS " + satellitesUsed + "/" + satellitesVisible + " sat" + acc;
            if (!LocationManager.GPS_PROVIDER.equals(l.getProvider())) return tr("POSIZIONE RETE") + acc;
            return engine.gpsGood() ? tr("GPS OK") + acc : tr("GPS DEBOLE") + acc;
        }
        String roadSummary() {
            if (downloadingRoads) return tr("SCARICO STRADE…");
            if (engine.ways != null && !engine.ways.isEmpty()) return "STRADE " + engine.ways.size();
            if (!roadDownloadAttempted) return tr("DATI STRADALI IN ATTESA");
            return tr("DATI STRADALI NON DISPONIBILI");
        }
        int batteryPercent() {
            try {
                android.content.Intent i = registerReceiver(null, new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
                if (i == null) return -1;
                int level=i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL,-1);
                int scale=i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE,-1);
                return level>=0&&scale>0 ? Math.round(level*100f/scale) : -1;
            } catch(Exception e) { return -1; }
        }

        void drawTopStatus(Canvas c) {
            int w = getWidth(); boolean land = w > getHeight();
            float barH = dp(land ? 34 : 50);
            panel(c, new RectF(0, 0, w, barH), 0xFF111820, 0);
            float fs = Math.max(10f, Math.min(15f, minDp() * .034f));
            int gpsColor = (!gpsSignalLost && engine.gpsGood()) ? green : 0xFFFFB84D;
            int roadColor = (downloadingRoads || (engine.mapWays != null && !engine.mapWays.isEmpty())) ? green : 0xFFFFB84D;
            if (land) {
                txt(c, gpsSummary(), w * .46f, dp(23), fs, gpsColor, Paint.Align.CENTER);
                String road = downloadingRoads ? tr("SCARICO STRADE…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "STRADE " + engine.mapWays.size() : tr("STRADE IN ATTESA"));
                txt(c, road, w - dp(10), dp(23), fs, roadColor, Paint.Align.RIGHT);
            } else {
                txt(c, gpsSummary(), w - dp(10), dp(21), fs, gpsColor, Paint.Align.RIGHT);
                String road = downloadingRoads ? tr("DOWNLOAD DATI STRADALI…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "DATI STRADALI OK · " + engine.mapWays.size() + " STRADE" : tr("DATI STRADALI IN ATTESA"));
                txt(c, road, w / 2f, dp(42), Math.max(9f, fs - 1), roadColor, Paint.Align.CENTER);
            }
        }

        void drawDemoInfo(Canvas c, boolean land) {
            float y = dp(48), h = dp(29), w = getWidth();
            panel(c, new RectF(0, y, w, y + h), 0xFF111820, 0);
            float fs = Math.max(9f, Math.min(12f, minDp() * .030f));
            txt(c, now(), dp(9), y + dp(19), fs, Color.WHITE, Paint.Align.LEFT);
            txt(c, gpsSummary(), w * .48f, y + dp(19), fs, engine.gpsGood() ? green : 0xFFFFB84D, Paint.Align.CENTER);
            String roads = downloadingRoads ? "DOWNLOAD…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : tr("STRADE IN ATTESA"));
            txt(c, roads, w - dp(9), y + dp(19), fs, (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D, Paint.Align.RIGHT);
        }

        void drawRide(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            Location l = engine.loc;
            Curve q = engine.current == null ? emptyCurve : engine.current;
            drawTopStatus(c);
            float b = dp(10);
            float buttonTop = dp(land ? 39 : 54);

            if (land) {
                // Landscape: the left 55% is divided into NAV/header/speed zones;
                // the map owns the right side. No element is positioned relative to another
                // element's text bounds, which was the source of the previous collisions.
                float speedCx = w * .52f;
                float speedBase = h * .62f;
                if (!navigationActive) {
                    // Use exactly the same dedicated navigation band used when NAV is active.
                    // This keeps the predicted curve in the same visual position as navigation.
                    float navLeft = dp(12);
                    float navRight = Math.min(speedBounds.left - dp(24), w * .35f);
                    float navTop = dp(150);
                    float navBottom = h * .84f;
                    float navW = Math.max(0f, navRight - navLeft);
                    float navH = Math.max(0f, navBottom - navTop);
                    if (navW > dp(120) && navH > dp(100)) {
                        drawCurveAlertCard(c, new RectF(navLeft, navTop, navRight, navBottom), q, land);
                    }
                }
                drawSpeed(c, speedCx, speedBase, l == null ? 0 : speed(l), q.recommended, currentSpeedLimitKmh, true);
                drawRadarAlert(c, w * .15f, h * .18f, true);
                txt(c, String.format(Locale.US, "%.1f km", dailyKm), speedCx, h * .93f, 18, Color.WHITE, Paint.Align.CENTER);

                float mapW = Math.min(w * .31f, h * .70f);
                float mapH = Math.min(h * .62f, w * .29f);
                float mapCx = w * .82f, mapCy = h * .55f;
                mapBounds.set(mapCx - mapW / 2f, mapCy - mapH / 2f, mapCx + mapW / 2f, mapCy + mapH / 2f);
                drawRoadMap(c, mapBounds, l, false);

                // Clock and destination have their own two-line header above the map.
                drawAltitude(c, mapBounds.centerX(), Math.min(h - dp(8), mapBounds.bottom + dp(22)), l, true);

            } else {
                // Portrait: header -> navigation -> speed -> trip/map. Everything has a
                // dedicated vertical zone and the header never shares the map coordinates.
                float speedCx = w * .50f;
                float speedBase = h * .73f;
                if (!navigationActive) {
                    // Portrait uses the exact same vertical band reserved for navigation.
                    float navLeft = dp(18);
                    float navRight = w - dp(18);
                    // Weather occupies the upper portrait header; keep the curve card
                    // below the temperature/icon zone with a deliberate safety gap.
                    float navTop = dp(132);
                    float navBottom = Math.min(h * .41f, speedBounds.top - dp(105));
                    float navW = Math.max(0f, navRight - navLeft);
                    float navH = Math.max(0f, navBottom - navTop);
                    if (navW > dp(150) && navH > dp(100)) {
                        drawCurveAlertCard(c, new RectF(navLeft, navTop, navRight, navBottom), q, land);
                    }
                }
                drawRadarAlert(c, w * .82f, h * .125f, false);

                float mapW = w * .88f;
                float mapH = h * .105f;
                float mapCy = h * .91f;
                mapBounds.set((w - mapW) / 2f, mapCy - mapH / 2f, (w + mapW) / 2f, mapCy + mapH / 2f);

                drawSpeed(c, speedCx, speedBase, l == null ? 0 : speed(l), q.recommended, currentSpeedLimitKmh, false);
                txt(c, String.format(Locale.US, "%.1f km", dailyKm), speedCx, h * .84f, 17, Color.WHITE, Paint.Align.CENTER);

                drawRoadMap(c, mapBounds, l, false);
                drawAltitude(c, mapBounds.centerX(), Math.min(h - dp(6), mapBounds.bottom + dp(18)), l, false);
            }

            // Explicit app-exit control: keeps the rider from accidentally using Android's
            // system Back gesture/button, which can be interpreted as a map interaction.
            // It is deliberately small and isolated from the navigation controls.
            exitButtonBounds.set(w - dp(54), buttonTop, w - b, buttonTop + dp(26));
            tripsButtonBounds.set(w - dp(132), buttonTop, w - dp(58), buttonTop + dp(26));
            navButtonBounds.set(w - dp(208), buttonTop, w - dp(136), buttonTop + dp(26));
            panel(c, navButtonBounds, navigationActive ? 0xFF6B5200 : 0xFF252A30, dp(7));
            stroke.setColor(navigationActive ? yellow : 0xFF7E8994); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE); c.drawRoundRect(navButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, navigationActive ? tr("NAV ON") : tr("NAV"), navButtonBounds.centerX(), navButtonBounds.centerY() + dp(4), 10, navigationActive ? yellow : Color.WHITE, Paint.Align.CENTER);
            panel(c, tripsButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(tripsButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, "VIAGGI", tripsButtonBounds.centerX(), tripsButtonBounds.centerY() + dp(4), 10, yellow, Paint.Align.CENTER);
            panel(c, exitButtonBounds, 0xFF35191D, dp(7));
            stroke.setColor(0xFFB94A55); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(exitButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, "ESCI", exitButtonBounds.centerX(), exitButtonBounds.centerY() + dp(4), 9, 0xFFFFA0A8, Paint.Align.CENTER);
            weatherButtonBounds.set(dp(10), buttonTop, dp(78), buttonTop + dp(26));
            panel(c, weatherButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(weatherButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, weatherLoading ? tr("METEO…") : tr("METEO ↻"), weatherButtonBounds.centerX(), weatherButtonBounds.centerY() + dp(4), 10, 0xFF8ED7FF, Paint.Align.CENTER);
            txt(c, airTemperature, weatherButtonBounds.centerX(), weatherButtonBounds.bottom + dp(34), 38.4f, 0xFFFFD66B, Paint.Align.CENTER);
            txt(c, weatherIcon(), weatherButtonBounds.right + dp(38), weatherButtonBounds.bottom + dp(34), 36f, 0xFFFFD66B, Paint.Align.CENTER);
            if (weatherAdverse || (showWeatherDetails && !weatherDetail.isEmpty())) {
                float stripBottom = buttonTop + dp(land ? 26 : 38);
                float weatherInfoRight = weatherButtonBounds.right + dp(48);
                RectF weatherStrip = new RectF(weatherInfoRight, buttonTop, Math.max(weatherInfoRight + dp(12), tripsButtonBounds.left - dp(5)), stripBottom);
                panel(c, weatherStrip, weatherAdverse ? 0xFFE00020 : 0xFF17212B, dp(4));
                String line1 = weatherAdverse ? "ATTENZIONE METEO" : weatherSummary;
                String line2 = weatherAdverse ? weatherSummary + " · " + weatherDetail : weatherDetail;
                float bannerSize = Math.max(7f, Math.min(9f, minDp() * .021f));
                p.setTextSize(bannerSize * density);
                float maxText = Math.max(dp(20), weatherStrip.width() - dp(8));
                while (p.measureText(line1) > maxText && bannerSize > 7f) { bannerSize -= .5f; p.setTextSize(bannerSize * density); }
                if (p.measureText(line1) > maxText) line1 = "METEO";
                if (p.measureText(line2) > maxText) { while (line2.length() > 8 && p.measureText(line2) > maxText) line2 = line2.substring(0, line2.length()-2) + "…"; }
                if (land) txt(c, line1 + " · " + line2, weatherStrip.centerX(), weatherStrip.centerY() + dp(3), bannerSize, Color.WHITE, Paint.Align.CENTER);
                else {
                    float mid = weatherStrip.centerY();
                    txt(c, line1, weatherStrip.centerX(), mid - dp(3), bannerSize, Color.WHITE, Paint.Align.CENTER);
                    txt(c, line2, weatherStrip.centerX(), mid + dp(10), bannerSize, Color.WHITE, Paint.Align.CENTER);
                }
            }

            // FINAL LAYOUT PASS: each information block is drawn exactly once.
            // Navigation has one dedicated rectangle; clock/destination have a separate
            // header above the speed display; battery is always bottom-right.
            if (navigationActive || navigationLoading) {
                float navLeft, navRight, navTop, navBottom;
                if (land) {
                    // Landscape: navigation lives in its own LEFT column.
                    // IMPORTANT: do not make its vertical size depend on speedBounds.top.
                    // The speed display occupies the adjacent column, so the two blocks
                    // can safely share the same vertical band. The previous dependency
                    // could make the available height smaller than 110dp on high-density
                    // phones, causing the entire navigation block to be skipped.
                    navLeft = dp(12);
                    navRight = Math.min(speedBounds.left - dp(24), w * .35f);
                    navTop = dp(150);
                    navBottom = h * .84f;
                } else {
                    // Portrait: reserve a real navigation band between the status area
                    // and the clock/destination/speed cluster.  The old h*.29 bottom
                    // was too high on tall/high-density phones (notably the Note 10),
                    // making navH < 120dp and therefore skipping the entire block.
                    // Keep a safe gap above the header: drawRideHeader uses speedRect.top
                    // - 82dp for the clock and - 42dp for the destination.
                    navLeft = dp(18);
                    navRight = w - dp(18);
                    // Portrait weather occupies the upper header through the temperature
                    // and weather icon. Keep a protected clearance band below it so the
                    // curve/NAV cards can never cover the weather readout.
                    navTop = dp(132);
                    navBottom = Math.min(h * .41f, speedBounds.top - dp(105));
                }
                float navW = navRight - navLeft;
                float navH = navBottom - navTop;
                // Width is the only hard constraint in landscape because navigation
                // is horizontally separated from the speed display.
                if (navW > dp(150) && navH > dp(120)) {
                    // The curve warning and navigation instruction now occupy two
                    // independent columns at the SAME vertical level.  This removes
                    // the old vertical stacking/overlap and makes the warning glanceable.
                    float gap = dp(8);
                    float curveW = navW * (land ? .40f : .40f);
                    curveW = Math.max(dp(112), Math.min(curveW, navW - dp(150) - gap));
                    float curveRight = navLeft + curveW;
                    float guidanceLeft = curveRight + gap;
                    float guidanceW = navRight - guidanceLeft;
                    if (guidanceW >= dp(140)) {
                        drawNavigationCurveAlert(c, navLeft, curveRight, navTop, navBottom, land);
                        drawNavigationGuidance(c, (guidanceLeft + navRight) / 2f,
                                (navTop + navBottom) / 2f, land, guidanceW, navH);
                    } else {
                        // Very narrow fallback: keep the two blocks vertically separated,
                        // never allow their drawing bounds to overlap.
                        float half = (navH - gap) * .5f;
                        drawNavigationCurveAlert(c, navLeft, navRight, navTop, navTop + half, land);
                        drawNavigationGuidance(c, (navLeft + navRight) / 2f,
                                navTop + half + gap + (navBottom - (navTop + half + gap)) / 2f,
                                land, navW, navBottom - (navTop + half + gap));
                    }
                }
            }

            // Single prominent clock + destination header, always above the speed display.
            drawRideHeader(c, land, speedBounds);

            int bat = batteryPercent();
            if (bat >= 0) {
                int bc = bat <= 15 ? Color.RED : (bat <= 30 ? yellow : 0xFFB8C2CC);
                txt(c, "BAT " + bat + "%", w - dp(10), h - dp(10), 11, bc, Paint.Align.RIGHT);
            }
            txt(c, tr("AUDIO ON"), dp(12), h - dp(10), 11, green, Paint.Align.LEFT);
        }

        void drawRideHeader(Canvas c, boolean land, RectF speedRect) {
            int w = getWidth();
            float cx = land ? speedRect.centerX() : w * .50f;
            // Landscape header is part of the same centered instrument cluster as speed/trip.
            // Keep it below the GPS status row and just above the large speed digits.
            float timeY = land ? speedRect.top - dp(48) : speedRect.top - dp(70);
            float destY = land ? speedRect.top - dp(15) : speedRect.top - dp(30);
            float timeSize = land ? 27f : 27f;
            txt(c, now(), cx, timeY, timeSize, Color.WHITE, Paint.Align.CENTER);
            if (navigationActive && navigationDestinationLabel != null && !navigationDestinationLabel.isEmpty()) {
                String dest = navigationDestinationLabel.toUpperCase(Locale.ROOT);
                float maxW = land ? w * .40f : w * .72f;
                float fs = land ? 14f : 14f;
                p.setTypeface(TypefaceCompat.bold());
                p.setTextSize(fs * density);
                while (p.measureText(dest) > maxW && fs > 8f) { fs -= .5f; p.setTextSize(fs * density); }
                if (p.measureText(dest) > maxW) {
                    while (dest.length() > 8 && p.measureText(dest + "…") > maxW) dest = dest.substring(0, dest.length()-2);
                    dest += "…";
                }
                txt(c, "→ " + dest, cx, destY, fs, yellow, Paint.Align.CENTER);
            }
        }

        void drawMapHeader(Canvas c, RectF map, boolean land) {
            float center = map.centerX();
            float gap = land ? dp(7) : dp(6);
            float destY = map.top - gap;
            float timeY = destY - (land ? dp(20) : dp(22));
            String time = now();
            txt(c, time, center, timeY, land ? 22 : 20, Color.WHITE, Paint.Align.CENTER);
            if (navigationActive && navigationDestinationLabel != null && !navigationDestinationLabel.isEmpty()) {
                String dest = navigationDestinationLabel.toUpperCase(Locale.ROOT);
                float maxW = map.width() - dp(8);
                float fs = land ? 12f : 11f;
                p.setTypeface(TypefaceCompat.bold()); p.setTextSize(fs * density);
                while (p.measureText(dest) > maxW && fs > 8f) { fs -= .5f; p.setTextSize(fs * density); }
                if (p.measureText(dest) > maxW) {
                    while (dest.length() > 8 && p.measureText(dest + "…") > maxW) dest = dest.substring(0, dest.length()-2);
                    dest += "…";
                }
                txt(c, "→ " + dest, center, destY, fs, yellow, Paint.Align.CENTER);
            }
        }

        void drawRoadMap(Canvas c, RectF bounds, Location location, boolean expanded) {
            float radius = dp(7);
            panel(c, bounds, 0xFF080C10, radius);
            c.save();
            Path clip = new Path(); clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
            c.clipPath(clip);
            boolean raster = drawRasterTiles(c, bounds, location, expanded);
            if (navigationActive && location != null) drawNavigationRoute(c, bounds, location, expanded);
            if (!raster) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(0.6f)); p.setColor(0xFF202A33);
                for (int i = 1; i < 4; i++) {
                    float x = bounds.left + bounds.width() * i / 4f;
                    float y = bounds.top + bounds.height() * i / 4f;
                    c.drawLine(x, bounds.top, x, bounds.bottom, p);
                    c.drawLine(bounds.left, y, bounds.right, y, p);
                }
                if (location != null && engine.mapWays != null && !engine.mapWays.isEmpty()) {
                    double lat0 = location.getLatitude(), lon0 = location.getLongitude();
                    double cosLat = Math.cos(Math.toRadians(lat0));
                    float bearing = hasMapBearing ? mapBearing : 0f;
                    double theta = Math.toRadians(bearing);
                    float scaleX = bounds.width() / 1000f, scaleY = bounds.height() / 1000f;
                    for (RoadWay way : engine.mapWays) {
                        if (way == null || way.pts == null || way.pts.size() < 2) continue;
                        Path road = new Path(); boolean started = false;
                        for (Geo point : way.pts) {
                            double east = (point.lon - lon0) * 111320.0 * cosLat;
                            double north = (point.lat - lat0) * 110540.0;
                            double eastRot = east * Math.cos(theta) - north * Math.sin(theta);
                            double northRot = east * Math.sin(theta) + north * Math.cos(theta);
                            float x = bounds.centerX() + (float)eastRot * scaleX;
                            float y = bounds.centerY() - (float)northRot * scaleY;
                            if (x < bounds.left - dp(10) || x > bounds.right + dp(10) || y < bounds.top - dp(10) || y > bounds.bottom + dp(10)) { started = false; continue; }
                            if (!started) { road.moveTo(x, y); started = true; } else road.lineTo(x, y);
                        }
                        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
                        p.setStrokeWidth(dp(3)); p.setColor(0xFF59636D); c.drawPath(road, p);
                        p.setStrokeWidth(dp(1.1f)); p.setColor(0xFFD5DDE4); c.drawPath(road, p);
                    }
                }
                String status = downloadingRoads ? tr("SCARICO STRADE…") :
                        (location == null ? tr("GPS IN RICERCA") : (!tilesLoading.isEmpty() ? tr("CARICAMENTO MAPPA…") :
                        (tileFailures > 0 ? tr("MAPPA NON DISPONIBILE") : (roadDataStatus.isEmpty() ? tr("MAPPA IN ATTESA") : roadDataStatus))));
                float statusSize = Math.max(8, Math.min(expanded ? 14 : 10, minDp() * .026f));
                txt(c, status, bounds.centerX(), bounds.bottom - dp(expanded ? 30 : 5), statusSize, 0xFFB8C2CC, Paint.Align.CENTER);
            }
            // Attribution is kept visible in both compact and expanded map views.
            String attribution = "© OpenStreetMap contributors";
            float attribSize = expanded ? 9f : 6.5f;
            p.setTextSize(attribSize * density);
            float attribWidth = p.measureText(attribution) + dp(6);
            RectF attrib = new RectF(bounds.right - attribWidth - dp(2), bounds.bottom - dp(expanded ? 21 : 13), bounds.right - dp(2), bounds.bottom - dp(2));
            panel(c, attrib, 0xD9000000, dp(2));
            txt(c, attribution, attrib.right - dp(3), attrib.bottom - dp(2), attribSize, Color.WHITE, Paint.Align.RIGHT);
            c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(Color.WHITE);
            c.drawRoundRect(bounds, radius, radius, p); p.setStyle(Paint.Style.FILL);
            // GPS marker is projected from its real coordinate; it is not artificially pinned to the viewport.
            float markerSize=Math.min(bounds.width(),bounds.height())*(expanded?.045f:.10f);float markerCx=bounds.centerX(),markerCy=bounds.centerY();
            if(location!=null){double centerLat=expanded&&!Double.isNaN(mapViewLat)?mapViewLat:mapAnchorLat,centerLon=expanded&&!Double.isNaN(mapViewLon)?mapViewLon:mapAnchorLon;if(Double.isNaN(centerLat)||Double.isNaN(centerLon)){centerLat=location.getLatitude();centerLon=location.getLongitude();}
                int z=expanded?Math.max(15,Math.min(19,15+Math.round((mapZoom-.5f)*4f))):Math.max(16,Math.min(19,16+Math.round((mapZoomCompact-.8f)*4.3f)));double world=256.0*(1<<z);
                double sc=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,centerLat)))),ccx=(centerLon+180.0)/360.0*world,ccy=(.5-Math.log((1+sc)/(1-sc))/(4*Math.PI))*world;
                double sl=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,location.getLatitude())))),lcx=(location.getLongitude()+180.0)/360.0*world,lcy=(.5-Math.log((1+sl)/(1-sl))/(4*Math.PI))*world;double br=Math.toRadians(expanded?mapFrozenBearing:(hasMapBearing?mapBearing:0f));
                double dx=lcx-ccx,dy=lcy-ccy,sx=dx*Math.cos(br)+dy*Math.sin(br),sy=-dx*Math.sin(br)+dy*Math.cos(br);markerCx+=(float)sx;markerCy+=(float)sy;}
            c.save();c.clipRect(bounds);Path bike=new Path();bike.moveTo(markerCx,markerCy-markerSize*.72f);bike.lineTo(markerCx-markerSize*.46f,markerCy+markerSize*.48f);bike.lineTo(markerCx,markerCy+markerSize*.20f);bike.lineTo(markerCx+markerSize*.46f,markerCy+markerSize*.48f);bike.close();stroke.setStyle(Paint.Style.STROKE);stroke.setColor(Color.BLACK);stroke.setStrokeWidth(dp(expanded?3:2));c.drawPath(bike,stroke);p.setStyle(Paint.Style.FILL);p.setColor(0xFFFFD400);c.drawPath(bike,p);
            if(expanded&&!Double.isNaN(selectedMapLat)&&!Double.isNaN(selectedMapLon)){float[] pt=mapScreenPoint(selectedMapLat,selectedMapLon,bounds);if(pt!=null){float fs=Math.max(dp(18),Math.min(dp(30),Math.min(bounds.width(),bounds.height())*.035f));stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(dp(2));stroke.setColor(Color.BLACK);c.drawLine(pt[0],pt[1]+fs*.55f,pt[0],pt[1]-fs*.35f,stroke);Path flag=new Path();flag.moveTo(pt[0],pt[1]-fs*.35f);flag.lineTo(pt[0]+fs*.65f,pt[1]-fs*.12f);flag.lineTo(pt[0],pt[1]+fs*.05f);flag.close();p.setStyle(Paint.Style.FILL);p.setColor(Color.RED);c.drawPath(flag,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(dp(1.5f));stroke.setColor(Color.WHITE);c.drawPath(flag,stroke);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(pt[0],pt[1],dp(3),p);}}
            c.restore();
            txt(c, expanded ? tr("MAPPA · TRASCINA PER SCORRERE") : tr("MAPPA"), bounds.centerX(), bounds.top + dp(expanded ? 23 : 13),
                    Math.max(8, Math.min(expanded ? 14 : 10, minDp() * .026f)), Color.WHITE, Paint.Align.CENTER);
            if (expanded && !Double.isNaN(selectedMapLat) && !Double.isNaN(selectedMapLon)) {
                String place = selectedMapPlaceName.isEmpty() ? tr("RICERCA LUOGO…") : selectedMapPlaceName;
                float fs = Math.max(10f, Math.min(17f, minDp() * .032f));
                float maxW = bounds.width() * .72f; p.setTextSize(fs * density);
                while (p.measureText(place) > maxW && fs > 8f) { fs -= .5f; p.setTextSize(fs * density); }
                panel(c, new RectF(bounds.centerX()-maxW/2f, bounds.bottom-dp(62), bounds.centerX()+maxW/2f, bounds.bottom-dp(34)), 0xD9000000, dp(7));
                txt(c, place, bounds.centerX(), bounds.bottom-dp(43), fs, Color.WHITE, Paint.Align.CENTER);
            }
            // Map zoom controls are deliberately small and kept inside the map frame.
            float zbtn = dp(expanded ? 48 : 36);
            RectF zin = new RectF(bounds.right-zbtn-dp(6), bounds.bottom-zbtn*2-dp(10), bounds.right-dp(6), bounds.bottom-zbtn-dp(10));
            RectF zout = new RectF(bounds.right-zbtn-dp(6), bounds.bottom-zbtn-dp(6), bounds.right-dp(6), bounds.bottom-dp(6));
            panel(c, zin, 0xCC18212A, dp(6)); panel(c, zout, 0xCC18212A, dp(6));
            txt(c, "+", zin.centerX(), zin.centerY()+dp(expanded?8:6), expanded?24:17, Color.WHITE, Paint.Align.CENTER);
            txt(c, "−", zout.centerX(), zout.centerY()+dp(expanded?6:5), expanded?24:17, Color.WHITE, Paint.Align.CENTER);
            if (location != null && !hasMapBearing) txt(c, tr("DIREZIONE IN ATTESA"), bounds.centerX(), bounds.bottom - dp(expanded ? 28 : 15),
                    Math.max(8, Math.min(10, minDp() * .024f)), 0xFFFFD400, Paint.Align.CENTER);
        }

        void drawNavigationRoute(Canvas c, RectF bounds, Location location, boolean expanded) {
            ArrayList<RoutePoint> snapshot;
            synchronized(navigationLock){ if(navigationRoute.isEmpty()) return; snapshot=new ArrayList<>(navigationRoute); }
            final int zoom=expanded?Math.max(15,Math.min(19,15+Math.round((mapZoom-.5f)*4f))):Math.max(16,Math.min(19,16+Math.round((mapZoomCompact-.8f)*4.3f)));
            double lat0,lon0;
            if(expanded&&!Double.isNaN(mapViewLat)&&!Double.isNaN(mapViewLon)){lat0=mapViewLat;lon0=mapViewLon;}
            else{lat0=Math.max(-85,Math.min(85,Double.isNaN(mapAnchorLat)?location.getLatitude():mapAnchorLat));lon0=Double.isNaN(mapAnchorLon)?location.getLongitude():mapAnchorLon;}
            double world=256.0*(1<<zoom);double cx=(lon0+180.0)/360.0*world;double ss=Math.sin(Math.toRadians(lat0));double cy=(.5-Math.log((1+ss)/(1-ss))/(4*Math.PI))*world;
            float scale=expanded?1f:1.15f;Path route=new Path();boolean started=false;
            float renderBearing=expanded?mapFrozenBearing:(hasMapBearing?mapBearing:0f);
            c.save();c.clipRect(bounds);c.translate(bounds.centerX(),bounds.centerY());c.rotate(-renderBearing);
            for(RoutePoint rp:snapshot){double yy=Math.max(-85,Math.min(85,rp.lat));double s=Math.sin(Math.toRadians(yy));double px=(rp.lon+180.0)/360.0*world;double py=(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*world;float x=(float)((px-cx)*scale),y=(float)((py-cy)*scale);if(!started){route.moveTo(x,y);started=true;}else route.lineTo(x,y);}
            stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);stroke.setStrokeJoin(Paint.Join.ROUND);stroke.setColor(Color.BLACK);stroke.setStrokeWidth(dp(expanded?10:5));c.drawPath(route,stroke);stroke.setColor(yellow);stroke.setStrokeWidth(dp(expanded?5:2.8f));c.drawPath(route,stroke);c.restore();
        }

        void prioritizeVisibleRouteTiles(int zoom, int minX, int maxX, int minY, int maxY, double world) {
            if (!navigationActive) return;
            long now = System.currentTimeMillis();
            if (now - lastRouteTilePriorityAt < 700L) return;
            lastRouteTilePriorityAt = now;
            ArrayList<RoutePoint> snapshot;
            synchronized(navigationLock) {
                if (navigationRoute.isEmpty()) return;
                snapshot = new ArrayList<>(navigationRoute);
            }
            int tileCount = 1 << zoom;
            HashSet<String> priority = new HashSet<>();
            // Sample the route rather than walking/requesting it on every frame.
            // A route can contain hundreds or thousands of geometry points.
            int stride = Math.max(1, snapshot.size() / 180);
            for (int i = 0; i < snapshot.size(); i += stride) {
                RoutePoint rp = snapshot.get(i);
                if (rp == null) continue;
                double yy = Math.max(-85.0, Math.min(85.0, rp.lat));
                double ss = Math.sin(Math.toRadians(yy));
                double px = (rp.lon + 180.0) / 360.0 * world;
                double py = (0.5 - Math.log((1.0 + ss) / (1.0 - ss)) / (4.0 * Math.PI)) * world;
                int tx = (int)Math.floor(px / 256.0);
                int ty = (int)Math.floor(py / 256.0);
                if (tx < minX - 1 || tx > maxX + 1 || ty < minY - 1 || ty > maxY + 1) continue;
                for (int ox=-1; ox<=1; ox++) for (int oy=-1; oy<=1; oy++) {
                    int qx=tx+ox, qy=ty+oy;
                    if(qx<minX||qx>maxX||qy<minY||qy>maxY||qy<0||qy>=tileCount) continue;
                    int wx=((qx%tileCount)+tileCount)%tileCount;
                    priority.add(zoom+"/"+wx+"/"+qy);
                }
            }
            // Route tiles first, adjacent tiles second. Keep this deliberately small:
            // fullscreen rendering must not flood the worker queue with dozens of
            // simultaneous tile downloads, otherwise panning becomes visibly jerky.
            int requested=0;
            for(String key: priority) {
                if(requested>=6) break;
                String[] a=key.split("/");
                if(a.length!=3) continue;
                int x,y; try { x=Integer.parseInt(a[1]); y=Integer.parseInt(a[2]); } catch(Exception ignored){continue;}
                Bitmap b=tileBitmaps.get(key);
                if(b==null||b.isRecycled()){
                    Long retryAt=tileRetryAfter.get(key);
                    if(retryAt==null||now>=retryAt) { requestTile(zoom,x,y,key); requested++; }
                }
            }
        }

        boolean drawRasterTiles(Canvas c, RectF bounds, Location location, boolean expanded) {
            if(location==null)return false;
            final int zoom=tripMapRendering?Math.max(10,Math.min(17,tripMapZoom)):(expanded?Math.max(15,Math.min(19,15+Math.round((mapZoom-.5f)*4f))):Math.max(16,Math.min(19,16+Math.round((mapZoomCompact-.8f)*4.3f))));
            double lat=Math.max(-85.0,Math.min(85.0,location.getLatitude())),lon=location.getLongitude();
            if(expanded){if(Double.isNaN(mapViewLat)||Double.isNaN(mapViewLon)){mapViewLat=lat;mapViewLon=lon;}lat=Math.max(-85,Math.min(85,mapViewLat));lon=mapViewLon;}
            else{if(Double.isNaN(mapAnchorLat)||mapAnchorLocation==null||mapAnchorLocation.distanceTo(location)>=40f||System.currentTimeMillis()-lastTileAnchorUpdate>30000L){mapAnchorLat=lat;mapAnchorLon=lon;mapAnchorLocation=new Location(location);lastTileAnchorUpdate=System.currentTimeMillis();}lat=mapAnchorLat;lon=mapAnchorLon;}
            double world=256.0*(1<<zoom);double centerX=(lon+180.0)/360.0*world;double sin=Math.sin(Math.toRadians(lat));double centerY=(.5-Math.log((1.0+sin)/(1.0-sin))/(4.0*Math.PI))*world;
            float scale=expanded?1f:1.15f;if(scale<=0f)return false;
            float renderBearing=expanded?mapFrozenBearing:(hasMapBearing?mapBearing:0f);double angle=Math.toRadians(renderBearing);double ca=Math.abs(Math.cos(angle)),sa=Math.abs(Math.sin(angle));
            double halfX=(ca*bounds.width()+sa*bounds.height())/(2.0*scale)+256.0;double halfY=(sa*bounds.width()+ca*bounds.height())/(2.0*scale)+256.0;
            int tileCount=1<<zoom;int minX=(int)Math.floor((centerX-halfX)/256.0)-1,maxX=(int)Math.floor((centerX+halfX)/256.0)+1;int minY=Math.max(0,(int)Math.floor((centerY-halfY)/256.0)-1),maxY=Math.min(tileCount-1,(int)Math.floor((centerY+halfY)/256.0)+1);
            prioritizeVisibleRouteTiles(zoom,minX,maxX,minY,maxY,world);
            boolean any=false;int requestsThisFrame=0;final int maxRequestsThisFrame=expanded?12:8;
            c.save();c.translate(bounds.centerX(),bounds.centerY());c.rotate(-renderBearing);p.setStyle(Paint.Style.FILL);
            for(int tx=minX;tx<=maxX;tx++){int wrappedX=((tx%tileCount)+tileCount)%tileCount;for(int ty=minY;ty<=maxY;ty++){String key=zoom+"/"+wrappedX+"/"+ty;Bitmap bitmap=tileBitmaps.get(key);
                float left=(float)(tx*256.0-centerX)*scale,top=(float)(ty*256.0-centerY)*scale;
                if(bitmap==null||bitmap.isRecycled()){Bitmap stable=stableTileBitmaps.get(key);if(stable!=null&&!stable.isRecycled()){c.drawBitmap(stable,null,new RectF(left,top,left+256f*scale,top+256f*scale),p);any=true;}else{if(requestsThisFrame<maxRequestsThisFrame){requestTile(zoom,wrappedX,ty,key);requestsThisFrame++;}Bitmap parent=drawParentTile(c,zoom,wrappedX,ty,tx,centerX,centerY,scale);if(parent!=null)any=true;else{p.setColor(0xFF202830);c.drawRect(new RectF(left,top,left+256f*scale,top+256f*scale),p);}}continue;}
                if(isTileStale(zoom,wrappedX,ty)){Long retryAt=tileRetryAfter.get(key);if(requestsThisFrame<maxRequestsThisFrame&&(retryAt==null||System.currentTimeMillis()>=retryAt)){requestTile(zoom,wrappedX,ty,key);requestsThisFrame++;}}
                c.drawBitmap(bitmap,null,new RectF(left,top,left+256f*scale,top+256f*scale),p);any=true;
            }}
            c.restore();return any;
        }

        File tileDirectory() {
            File dir = new File(getContext().getFilesDir(), "maptiles");
            if (!dir.exists()) dir.mkdirs();
            return dir;
        }

        File tileImageFile(int z, int x, int y) { return new File(tileDirectory(), z + "_" + x + "_" + y + ".png"); }
        File tileExpiryFile(int z, int x, int y) { return new File(tileDirectory(), z + "_" + x + "_" + y + ".exp"); }

        boolean isTileStale(int z, int x, int y) {
            Long expiry = tileExpiries.get(z + "/" + x + "/" + y);
            return expiry != null && expiry <= System.currentTimeMillis();
        }

        // Draw a parent tile quadrant while the sharper child tile downloads, avoiding black squares.
        Bitmap drawParentTile(Canvas c, int z, int x, int y, int wrappedX, double centerX, double centerY, float scale) {
            for (int level = z - 1; level >= Math.max(1, z - 4); level--) {
                int shift = z - level;
                int px = x >> shift, py = y >> shift;
                int parentCount = 1 << level;
                px = ((px % parentCount) + parentCount) % parentCount;
                if (py < 0 || py >= parentCount) continue;
                String parentKey = level + "/" + px + "/" + py;
                Bitmap parent = tileBitmaps.get(parentKey);
                if (parent == null || parent.isRecycled()) { Long retryAt = tileRetryAfter.get(parentKey); if (retryAt == null || System.currentTimeMillis() >= retryAt) requestTile(level, px, py, parentKey); continue; }
                int quadrant = 1 << shift;
                int srcSize = 256 / quadrant;
                int sx = (x & (quadrant - 1)) * srcSize, sy = (y & (quadrant - 1)) * srcSize;
                android.graphics.Rect src = new android.graphics.Rect(sx, sy, sx + srcSize, sy + srcSize);
                float left = (float)(wrappedX * 256.0 - centerX) * scale;
                float top = (float)(y * 256.0 - centerY) * scale;
                RectF dest = new RectF(left, top, left + 256f * scale, top + 256f * scale);
                c.drawBitmap(parent, src, dest, p);
                return parent;
            }
            return null;
        }

        void requestTile(int z, int x, int y, String key) {
            if (!tilesLoading.add(key)) return;
            Long retry = tileRetryAfter.get(key);
            if (retry != null && System.currentTimeMillis() < retry) { tilesLoading.remove(key); return; }
            tileExecutor.execute(() -> {
                try {
                    File dir = tileDirectory();
                    String safe = "osm_v2_" + z + "_" + x + "_" + y;
                    File imageFile = new File(dir, safe + ".png"), expiryFile = new File(dir, safe + ".exp");
                    // Migrate a previously cached tile lazily on the worker thread, never during drawing.
                    File legacyImage = new File(new File(getContext().getCacheDir(), "maptiles"), safe + ".png");
                    File legacyExpiry = new File(new File(getContext().getCacheDir(), "maptiles"), safe + ".exp");
                    if (!imageFile.exists() && legacyImage.isFile()) {
                        try (InputStream in = new java.io.FileInputStream(legacyImage); FileOutputStream out = new FileOutputStream(imageFile)) {
                            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                            if (legacyExpiry.isFile()) try (InputStream ei = new java.io.FileInputStream(legacyExpiry); FileOutputStream eo = new FileOutputStream(expiryFile)) { while ((n = ei.read(buffer)) > 0) eo.write(buffer, 0, n); }
                        } catch (Exception ignored) { }
                    }
                    long expiry = 0L;
                    if (expiryFile.exists()) try { expiry = Long.parseLong(new String(java.nio.file.Files.readAllBytes(expiryFile.toPath()), "UTF-8").trim()); } catch (Exception ignored) { }
                    if (imageFile.exists() && expiry == 0L) expiry = imageFile.lastModified() + 7L * 86400000L;
                    if (imageFile.exists()) tileExpiries.put(key, expiry);
                    boolean fresh = imageFile.exists() && expiry > System.currentTimeMillis();
                    if (imageFile.exists()) {
                        Bitmap cached = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                        if (cached != null) { tileBitmaps.put(key, cached); stableTileBitmaps.put(key, cached); }
                    }
                    if (fresh) return; // Keep the on-disk tile and avoid needless requests.
                    // CARTO raster endpoints now return an "API key required" watermark
                    // without a project-owned key. Use the public OSM raster endpoint directly.
                    // Keep the provider configurable in code; do not silently accept HTTP-200
                    // watermark images as valid map tiles.
                    // Providers are used sequentially, never in parallel. This keeps the
                    // primary OSM service protected while still giving the map a resilient
                    // fallback path when a provider is temporarily unavailable.
                    String subdomain = new String[]{"a","b","c"}[Math.floorMod(x + y, 3)];
                    String[] urls = {
                        "https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png",
                        "https://" + subdomain + ".tile.openstreetmap.fr/osmfr/" + z + "/" + x + "/" + y + ".png",
                        "https://" + subdomain + ".tile.openstreetmap.fr/hot/" + z + "/" + x + "/" + y + ".png",
                        "https://" + subdomain + ".tile-cyclosm.openstreetmap.fr/cyclosm-lite/" + z + "/" + x + "/" + y + ".png"
                    };
                    for (int provider = 0; provider < urls.length; provider++) {
                        HttpURLConnection conn = null;
                        try {
                            conn = (HttpURLConnection)new URL(urls[provider]).openConnection();
                            conn.setConnectTimeout(3000); conn.setReadTimeout(7000);
                            conn.setRequestMethod("GET");
                            conn.setRequestProperty("User-Agent", "RoadDisplayPRO/3.22.17 (Android motorcycle dashboard; map attribution visible)");
                            conn.setRequestProperty("Accept", "image/png,image/*;q=0.8,*/*;q=0.5");
                            int code = conn.getResponseCode();
                            if (code != HttpURLConnection.HTTP_OK) continue;
                            byte[] bytes;
                            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                                byte[] buffer = new byte[8192]; int n;
                                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                                bytes = out.toByteArray();
                            }
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            if (bitmap == null) continue;
                            try (FileOutputStream out = new FileOutputStream(imageFile)) { out.write(bytes); }
                            long maxAge = 7L * 86400L;
                            String cacheControl = conn.getHeaderField("Cache-Control");
                            if (cacheControl != null) {
                                Matcher matcher = Pattern.compile("max-age\\s*=\\s*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(cacheControl);
                                if (matcher.find()) try { maxAge = Math.max(60L, Long.parseLong(matcher.group(1))); } catch (Exception ignored) { }
                            }
                            long tileExpiry = System.currentTimeMillis() + maxAge * 1000L;
                            try (FileOutputStream out = new FileOutputStream(expiryFile)) { out.write(Long.toString(tileExpiry).getBytes("UTF-8")); }
                            tileExpiries.put(key, tileExpiry);
                            tileBitmaps.put(key, bitmap);
                            stableTileBitmaps.put(key, bitmap);
                            tileFailures = Math.max(0, tileFailures - 1);
                            tileRetryAfter.remove(key);
                            return;
                        } catch (Exception ignored) { }
                        finally { if (conn != null) conn.disconnect(); }
                    }
                    tileFailures++;
                    tileRetryAfter.put(key, System.currentTimeMillis() + 60000L);
                } finally {
                    tilesLoading.remove(key);
                    postInvalidate();
                }
            });
        }

        void releaseTiles() {
            tileExecutor.shutdownNow();
            tileBitmaps.evictAll();
            stableTileBitmaps.evictAll();
        }


        String fmtTripDuration(long ms) {
            long sec=Math.max(0,ms/1000), h=sec/3600, m=(sec%3600)/60;
            return h>0 ? String.format(Locale.getDefault(),"%dh %02dm",h,m) : String.format(Locale.getDefault(),"%dm",m);
        }
        String fmtTripDate(long t) { return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t)); }

        String tripDayKey(long t) { return new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date(t)); }
        String tripDayLabel(String key) {
            try {
                Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).parse(key);
                return new SimpleDateFormat("EEEE dd MMMM yyyy",Locale.getDefault()).format(d);
            } catch(Exception e) { return key; }
        }
        java.util.LinkedHashMap<String,java.util.ArrayList<TripDb.TripSummary>> groupTripsByDay(java.util.List<TripDb.TripSummary> list) {
            java.util.LinkedHashMap<String,java.util.ArrayList<TripDb.TripSummary>> groups=new java.util.LinkedHashMap<>();
            for(TripDb.TripSummary t:list){String k=tripDayKey(t.startTime); java.util.ArrayList<TripDb.TripSummary> g=groups.get(k); if(g==null){g=new java.util.ArrayList<>();groups.put(k,g);} g.add(t);}
            return groups;
        }
        void drawTrips(Canvas c) {
            int w=getWidth(), h=getHeight(); c.drawColor(0xFF070A0D);
            panel(c,new RectF(0,0,w,dp(58)),0xFF141B22,0);
            txt(c,"DIARIO VIAGGI",dp(16),dp(37),22,yellow,Paint.Align.LEFT);
            tripsCloseBounds.set(w-dp(104),dp(8),w-dp(8),dp(50)); panel(c,tripsCloseBounds,0xFF26313A,dp(8));
            txt(c,"← RIDE",tripsCloseBounds.centerX(),tripsCloseBounds.centerY()+dp(5),13,Color.WHITE,Paint.Align.CENTER);
            java.util.List<TripDb.TripSummary> list=tripDb==null?new java.util.ArrayList<>():tripDb.listTrips(500);
            java.util.LinkedHashMap<String,java.util.ArrayList<TripDb.TripSummary>> groups=groupTripsByDay(list);
            double total=0; for(TripDb.TripSummary t:list) total+=t.distanceM/1000.0;
            txt(c,String.format(Locale.getDefault(),"GIORNI  %d",groups.size()),dp(16),dp(84),15,Color.WHITE,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"TOTALE  %.1f km",total),w-dp(16),dp(84),15,0xFF65D7FF,Paint.Align.RIGHT);
            if(tripRecording){panel(c,new RectF(dp(12),dp(98),w-dp(12),dp(132)),0xFF153323,dp(7));txt(c,"● REGISTRAZIONE VIAGGIO IN CORSO",w/2f,dp(121),13,green,Paint.Align.CENTER);}
            float top=tripRecording?dp(146):dp(100), rowH=Math.max(dp(82),Math.min(dp(98),h*.11f)), bottom=h-dp(10);
            c.save(); c.clipRect(0,top,w,bottom);
            java.util.ArrayList<String> keys=new java.util.ArrayList<>(groups.keySet());
            for(int i=0;i<keys.size();i++){
                String key=keys.get(i); java.util.ArrayList<TripDb.TripSummary> g=groups.get(key); float yy=top+i*rowH-tripsScroll; if(yy>bottom||yy+rowH<top)continue;
                double km=0; for(TripDb.TripSummary t:g) km+=t.distanceM/1000.0;
                panel(c,new RectF(dp(10),yy,w-dp(10),yy+rowH-dp(5)),0xFF10171E,dp(8));
                txt(c,tripDayLabel(key),dp(20),yy+dp(27),16,Color.WHITE,Paint.Align.LEFT);
                txt(c,String.format(Locale.getDefault(),"%d %s",g.size(),g.size()==1?"VIAGGIO":"VIAGGI"),w-dp(20),yy+dp(27),15,yellow,Paint.Align.RIGHT);
                txt(c,String.format(Locale.getDefault(),"%.1f km totali",km),dp(20),yy+dp(53),12,0xFF65D7FF,Paint.Align.LEFT);
                txt(c,"TOCCA PER APRIRE LA GIORNATA  ›",w-dp(20),yy+dp(53),10,0xFFB7C0C8,Paint.Align.RIGHT);
            }
            c.restore();
            if(groups.isEmpty()) txt(c,"Nessun viaggio registrato. I viaggi vengono registrati automaticamente con GPS preciso e movimento reale.",w/2f,h*.55f,14,0xFF9AA3AD,Paint.Align.CENTER);
            txt(c,"Ogni giornata raggruppa tutti i viaggi effettuati quel giorno",w/2f,h-dp(7),10,0xFF7E8994,Paint.Align.CENTER);
        }

        void openTripDay(String key){ selectedTripDayKey=key; tripDayScreen=true; tripsScroll=0f; invalidate(); }

        void drawTripDay(Canvas c){
            int w=getWidth(), h=getHeight(); c.drawColor(0xFF070A0D);
            panel(c,new RectF(0,0,w,dp(58)),0xFF141B22,0);
            txt(c,"GIORNATA",dp(16),dp(37),20,yellow,Paint.Align.LEFT);
            tripsCloseBounds.set(w-dp(104),dp(8),w-dp(8),dp(50)); panel(c,tripsCloseBounds,0xFF26313A,dp(8));
            txt(c,"← VIAGGI",tripsCloseBounds.centerX(),tripsCloseBounds.centerY()+dp(5),13,Color.WHITE,Paint.Align.CENTER);
            java.util.List<TripDb.TripSummary> all=tripDb==null?new java.util.ArrayList<>():tripDb.listTrips(500);
            java.util.ArrayList<TripDb.TripSummary> day=new java.util.ArrayList<>();
            for(TripDb.TripSummary t:all) if(tripDayKey(t.startTime).equals(selectedTripDayKey)) day.add(t);
            double km=0; for(TripDb.TripSummary t:day) km+=t.distanceM/1000.0;
            txt(c,tripDayLabel(selectedTripDayKey),dp(16),dp(82),17,Color.WHITE,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"%d %s  •  %.1f km",day.size(),day.size()==1?"viaggio":"viaggi",km),w-dp(16),dp(82),14,0xFF65D7FF,Paint.Align.RIGHT);
            if(tripRecording){panel(c,new RectF(dp(12),dp(94),w-dp(12),dp(128)),0xFF153323,dp(7));txt(c,"● REGISTRAZIONE VIAGGIO IN CORSO",w/2f,dp(117),13,green,Paint.Align.CENTER);}
            float top=tripRecording?dp(142):dp(96), rowH=Math.max(dp(76),Math.min(dp(92),h*.10f)), bottom=h-dp(58);
            c.save(); c.clipRect(0,top,w,bottom);
            for(int i=0;i<day.size();i++){
                TripDb.TripSummary t=day.get(i); float yy=top+i*rowH-tripsScroll; if(yy>bottom||yy+rowH<top)continue;
                panel(c,new RectF(dp(10),yy,w-dp(10),yy+rowH-dp(5)),0xFF10171E,dp(7));
                String times=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(t.startTime))+" → "+(t.endTime>0?new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(t.endTime)):"IN CORSO");
                txt(c,times,dp(20),yy+dp(22),15,Color.WHITE,Paint.Align.LEFT);
                txt(c,String.format(Locale.getDefault(),"%.1f km",t.distanceM/1000.0),w-dp(20),yy+dp(22),16,yellow,Paint.Align.RIGHT);
                txt(c,String.format(Locale.getDefault(),"%s   •   media %.1f   •   max %.1f km/h",fmtTripDuration(t.durationMs),t.avgKmh,t.maxKmh),dp(20),yy+dp(46),11,0xFFB7C0C8,Paint.Align.LEFT);
                txt(c,String.format(Locale.getDefault(),"%d punti GPS",t.pointCount),w-dp(20),yy+dp(46),11,0xFF65D7FF,Paint.Align.RIGHT);
                txt(c,"TOCCA PER DETTAGLI  ›",w-dp(20),yy+dp(67),9,0xFF7E8994,Paint.Align.RIGHT);
            }
            c.restore();
            if(day.isEmpty()) txt(c,"Nessun viaggio per questa giornata.",w/2f,h*.5f,14,0xFF9AA3AD,Paint.Align.CENTER);
            txt(c,"← VIAGGI",dp(18),h-dp(18),10,0xFF7E8994,Paint.Align.LEFT);
        }

        void openTripDetail(long id){
            selectedTripId=id;
            new Thread(() -> {
                TripDb.TripSummary summary=tripDb.getTrip(id);
                java.util.ArrayList<TripDb.Point> pts=tripDb.getPoints(id);
                runOnUiThread(() -> { selectedTripSummary=summary; selectedTripPoints=pts; tripMapZoomOffset=0; tripMapUserPanned=false; tripMapCenterLat=Double.NaN; tripMapCenterLon=Double.NaN; tripsScreen=false; tripsScroll=0f; invalidate(); });
            },"trip-detail-load").start();
        }

        void drawTripDetail(Canvas c){
            int w=getWidth(), h=getHeight(); boolean land=w>h;
            c.drawColor(0xFF070A0D);
            panel(c,new RectF(0,0,w,dp(58)),0xFF141B22,0);
            txt(c,"DETTAGLIO VIAGGIO",dp(16),dp(37),20,yellow,Paint.Align.LEFT);
            RectF back=new RectF(w-dp(116),dp(8),w-dp(8),dp(50)); panel(c,back,0xFF26313A,dp(8));
            txt(c,"← VIAGGI",back.centerX(),back.centerY()+dp(5),13,Color.WHITE,Paint.Align.CENTER);
            TripDb.TripSummary t=selectedTripSummary;
            if(t==null){txt(c,"CARICAMENTO VIAGGIO…",w/2f,h*.45f,16,Color.WHITE,Paint.Align.CENTER);return;}

            if(land){
                float sideW=Math.max(dp(285),Math.min(dp(390),w*.34f));
                RectF info=new RectF(dp(10),dp(72),dp(10)+sideW,h-dp(68));
                RectF map=new RectF(info.right+dp(12),dp(72),w-dp(10),h-dp(68));
                drawTripInfo(c,info,t,true);
                drawTripMap(c,map,selectedTripPoints);
                RectF home=new RectF(dp(10),h-dp(56),dp(150),h-dp(12)); panel(c,home,0xFF26313A,dp(7));
                txt(c,"⌂ PRINCIPALE",home.centerX(),home.centerY()+dp(5),12,Color.WHITE,Paint.Align.CENTER);
                RectF list=new RectF(dp(160),h-dp(56),dp(300),h-dp(12)); panel(c,list,0xFF26313A,dp(7));
                txt(c,"← VIAGGI",list.centerX(),list.centerY()+dp(5),12,Color.WHITE,Paint.Align.CENTER);
                RectF del=new RectF(w-dp(150),h-dp(56),w-dp(10),h-dp(12)); panel(c,del,0xFF342020,dp(7));
                txt(c,"ELIMINA",del.centerX(),del.centerY()+dp(5),12,0xFFFF7777,Paint.Align.CENTER);
                tripDetailHomeBounds.set(home); tripDetailListBounds.set(list); tripDetailDeleteBounds.set(del);
            } else {
                float mapTop=dp(68), mapBottom=Math.min(h*.48f,h-dp(270));
                if(mapBottom<mapTop+dp(170)) mapBottom=Math.min(h-dp(190),mapTop+dp(190));
                RectF map=new RectF(dp(10),mapTop,w-dp(10),mapBottom);
                drawTripMap(c,map,selectedTripPoints);
                RectF info=new RectF(dp(10),mapBottom+dp(10),w-dp(10),h-dp(72));
                drawTripInfo(c,info,t,false);
                RectF list=new RectF(dp(10),h-dp(56),w*.48f,h-dp(12)); panel(c,list,0xFF26313A,dp(7));
                txt(c,"← VIAGGI",list.centerX(),list.centerY()+dp(5),12,Color.WHITE,Paint.Align.CENTER);
                RectF home=new RectF(w*.52f,h-dp(56),w-dp(10),h-dp(12)); panel(c,home,0xFF26313A,dp(7));
                txt(c,"⌂ PRINCIPALE",home.centerX(),home.centerY()+dp(5),12,Color.WHITE,Paint.Align.CENTER);
                tripDetailListBounds.set(list); tripDetailHomeBounds.set(home); tripDetailDeleteBounds.setEmpty();
            }
        }

        void drawTripInfo(Canvas c,RectF r,TripDb.TripSummary t,boolean land){
            panel(c,r,0xFF10171E,dp(9));
            txt(c,"DATI DEL VIAGGIO",r.left+dp(14),r.top+dp(25),14,yellow,Paint.Align.LEFT);
            String endLabel=t.endTime>0?fmtTripDate(t.endTime):"IN CORSO";
            txt(c,fmtTripDate(t.startTime)+"  →  "+endLabel,r.left+dp(14),r.top+dp(49),11,Color.WHITE,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"%.1f km",t.distanceM/1000.0),r.right-dp(14),r.top+dp(49),18,yellow,Paint.Align.RIGHT);
            float y=r.top+dp(78);
            if(land){
                float col=r.width()/2f;
                tripInfoCell(c,"DURATA",fmtTripDuration(t.durationMs),r.left+dp(14),y);
                tripInfoCell(c,"MEDIA",String.format(Locale.getDefault(),"%.1f km/h",t.avgKmh),r.left+col,y);
                y+=dp(62);
                tripInfoCell(c,"MASSIMA",String.format(Locale.getDefault(),"%.1f km/h",t.maxKmh),r.left+dp(14),y);
                tripInfoCell(c,"PUNTI GPS",String.valueOf(t.pointCount),r.left+col,y);
                y+=dp(62);
                tripInfoCell(c,"QUOTA MIN",String.format(Locale.getDefault(),"%.0f m",t.minAlt),r.left+dp(14),y);
                tripInfoCell(c,"QUOTA MAX",String.format(Locale.getDefault(),"%.0f m",t.maxAlt),r.left+col,y);
                y+=dp(62);
                tripInfoCell(c,"DISLIVELLO +",String.format(Locale.getDefault(),"%.0f m",t.elevationGainM),r.left+dp(14),y);
            } else {
                float col=r.width()/2f;
                tripInfoCell(c,"DURATA",fmtTripDuration(t.durationMs),r.left+dp(14),y);
                tripInfoCell(c,"MEDIA",String.format(Locale.getDefault(),"%.1f km/h",t.avgKmh),r.left+col,y);
                y+=dp(54);
                tripInfoCell(c,"MASSIMA",String.format(Locale.getDefault(),"%.1f km/h",t.maxKmh),r.left+dp(14),y);
                tripInfoCell(c,"PUNTI GPS",String.valueOf(t.pointCount),r.left+col,y);
                y+=dp(54);
                txt(c,String.format(Locale.getDefault(),"QUOTA %.0f → %.0f m   •   DISLIVELLO +%.0f m",t.minAlt,t.maxAlt,t.elevationGainM),r.left+dp(14),y,11,0xFF65D7FF,Paint.Align.LEFT);
            }
        }

        void tripInfoCell(Canvas c,String label,String value,float x,float y){
            txt(c,label,x,y,9,0xFF7E8994,Paint.Align.LEFT);
            txt(c,value,x,y+dp(22),16,Color.WHITE,Paint.Align.LEFT);
        }

        void drawTripMap(Canvas c,RectF r,java.util.ArrayList<TripDb.Point> pts){
            panel(c,r,0xFF0C1218,dp(9));
            if(pts==null||pts.size()<2){txt(c,"TRACCIA GPS NON DISPONIBILE",r.centerX(),r.centerY(),13,0xFF7E8994,Paint.Align.CENTER);return;}
            double minLa=Double.MAX_VALUE,minLo=Double.MAX_VALUE,maxLa=-Double.MAX_VALUE,maxLo=-Double.MAX_VALUE;
            for(TripDb.Point q:pts){if(q==null)continue;minLa=Math.min(minLa,q.lat);maxLa=Math.max(maxLa,q.lat);minLo=Math.min(minLo,q.lon);maxLo=Math.max(maxLo,q.lon);}
            double centerLat=(minLa+maxLa)/2.0,centerLon=(minLo+maxLo)/2.0;
            if(!tripMapUserPanned || Double.isNaN(tripMapCenterLat) || Double.isNaN(tripMapCenterLon)){ tripMapCenterLat=centerLat; tripMapCenterLon=centerLon; }
            centerLat=tripMapCenterLat; centerLon=tripMapCenterLon;
            Location center=new Location("trip-map"); center.setLatitude(centerLat); center.setLongitude(centerLon);
            double oldLat=mapViewLat,oldLon=mapViewLon; float oldBearing=mapFrozenBearing,oldZoom=mapZoom; boolean oldUser=mapUserPanned;
            mapViewLat=centerLat; mapViewLon=centerLon; mapFrozenBearing=0f; mapUserPanned=true;
            tripMapBounds.set(r);
            double spanLat=Math.max(1e-7,maxLa-minLa), spanLon=Math.max(1e-7,maxLo-minLo);
            double cos=Math.max(.15,Math.cos(Math.toRadians(centerLat)));
            double usableW=Math.max(120.0,r.width()/density-56.0), usableH=Math.max(120.0,r.height()/density-56.0);
            double zoomLon=Math.log((usableW*360.0)/(256.0*spanLon))/Math.log(2.0);
            double zoomLat=Math.log((usableH*360.0*cos)/(256.0*spanLat))/Math.log(2.0);
            int baseTripZoom=(int)Math.floor(Math.min(zoomLon,zoomLat));
            tripMapZoom=(int)Math.max(10,Math.min(18,baseTripZoom+tripMapZoomOffset));
            tripMapRendering=true;
            boolean raster=drawRasterTiles(c,r,center,true);
            if(!raster){p.setStyle(Paint.Style.FILL);p.setColor(0xFF111A22);c.drawRect(r,p);}
            drawTripTrace(c,r,pts);
            txt(c,"TRACCIA GPS",r.left+dp(12),r.top+dp(22),11,Color.WHITE,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"%d punti",pts.size()),r.right-dp(12),r.top+dp(22),11,0xFF65D7FF,Paint.Align.RIGHT);
            // Dedicated trip-map zoom controls. The trip starts in a fit-to-route view,
            // but the rider can now zoom in several steps to inspect bends and GPS drift.
            float zb=dp(38), zg=dp(6);
            tripMapZoomInBounds.set(r.right-zb-dp(10), r.top+dp(10), r.right-dp(10), r.top+dp(10)+zb);
            tripMapZoomOutBounds.set(r.right-zb-dp(10), r.top+dp(10)+zb+zg, r.right-dp(10), r.top+dp(10)+2*zb+zg);
            panel(c,tripMapZoomInBounds,0xCC18212A,dp(7));
            panel(c,tripMapZoomOutBounds,0xCC18212A,dp(7));
            txt(c,"+",tripMapZoomInBounds.centerX(),tripMapZoomInBounds.centerY()+dp(8),23,Color.WHITE,Paint.Align.CENTER);
            txt(c,"−",tripMapZoomOutBounds.centerX(),tripMapZoomOutBounds.centerY()+dp(7),23,Color.WHITE,Paint.Align.CENTER);
            tripMapRendering=false;
            mapViewLat=oldLat;mapViewLon=oldLon;mapFrozenBearing=oldBearing;mapZoom=oldZoom;mapUserPanned=oldUser;
        }

        void drawTripTrace(Canvas c,RectF r,java.util.ArrayList<TripDb.Point> pts){
            if(pts==null||pts.size()<2){txt(c,"TRACCIA NON DISPONIBILE",r.centerX(),r.centerY(),13,0xFF7E8994,Paint.Align.CENTER);return;}
            // The raster map uses Web Mercator. Project the GPS trace with the EXACT
            // same centre/zoom/world transform instead of fitting latitude/longitude
            // linearly into the card. This keeps the yellow trace locked to the roads.
            int zoom=Math.max(10,Math.min(17,tripMapZoom));
            double world=256.0*(1L<<zoom);
            double centerLat=mapViewLat, centerLon=mapViewLon;
            if(Double.isNaN(centerLat)||Double.isNaN(centerLon)){
                centerLat=pts.get(pts.size()/2).lat; centerLon=pts.get(pts.size()/2).lon;
            }
            double cxWorld=(centerLon+180.0)/360.0*world;
            double sin=Math.sin(Math.toRadians(Math.max(-85.0,Math.min(85.0,centerLat))));
            double cyWorld=(.5-Math.log((1.0+sin)/(1.0-sin))/(4.0*Math.PI))*world;
            Path path=new Path(); boolean first=true;
            for(TripDb.Point q:pts){
                if(q==null||Double.isNaN(q.lat)||Double.isNaN(q.lon))continue;
                double lat=Math.max(-85.0,Math.min(85.0,q.lat));
                double ss=Math.sin(Math.toRadians(lat));
                double px=(q.lon+180.0)/360.0*world;
                double py=(.5-Math.log((1.0+ss)/(1.0-ss))/(4.0*Math.PI))*world;
                float x=(float)(r.centerX()+(px-cxWorld));
                float y=(float)(r.centerY()+(py-cyWorld));
                if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);
            }
            stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(dp(3));stroke.setColor(yellow);stroke.setStrokeCap(Paint.Cap.ROUND);stroke.setStrokeJoin(Paint.Join.ROUND);c.drawPath(path,stroke);stroke.setStyle(Paint.Style.FILL);
            TripDb.Point a=pts.get(0),b=pts.get(pts.size()-1);
            float[] ap=tripMapPoint(r,a,world,cxWorld,cyWorld),bp=tripMapPoint(r,b,world,cxWorld,cyWorld);
            p.setColor(green);c.drawCircle(ap[0],ap[1],dp(6),p);p.setColor(Color.RED);c.drawCircle(bp[0],bp[1],dp(6),p);
            txt(c,"PARTENZA",ap[0],ap[1]+dp(18),9,green,Paint.Align.CENTER);txt(c,"ARRIVO",bp[0],bp[1]+dp(18),9,0xFFFF7777,Paint.Align.CENTER);
        }

        float[] tripMapPoint(RectF r,TripDb.Point q,double world,double cxWorld,double cyWorld){
            double lat=Math.max(-85.0,Math.min(85.0,q.lat));
            double ss=Math.sin(Math.toRadians(lat));
            double px=(q.lon+180.0)/360.0*world;
            double py=(.5-Math.log((1.0+ss)/(1.0-ss))/(4.0*Math.PI))*world;
            return new float[]{(float)(r.centerX()+(px-cxWorld)),(float)(r.centerY()+(py-cyWorld))};
        }

        void deleteSelectedTrip(){
            final long id=selectedTripId;
            new AlertDialog.Builder(MainActivity.this).setTitle("ELIMINARE IL VIAGGIO?").setMessage("La traccia GPS e tutte le statistiche di questo viaggio verranno eliminate.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA",(d,w)->new Thread(()->{tripDb.deleteTrip(id);runOnUiThread(()->{selectedTripId=-1;selectedTripSummary=null;selectedTripPoints.clear();tripsScreen=true;invalidate();});},"trip-delete").start()).show();
        }

        void showExitConfirmation() {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("CHIUDERE ROAD DISPLAY PRO?")
                    .setMessage("La navigazione verrà chiusa e l'app verrà terminata.")
                    .setNegativeButton("ANNULLA", null)
                    .setPositiveButton("CHIUDI APP", (d, w) -> {
                        try { if (navigationActive) stopNavigation(); } catch (Exception ignored) { }
                        finishAndRemoveTask();
                    })
                    .show();
        }

        void showWeatherPopup() {
            LinearLayout root=new LinearLayout(MainActivity.this);
            root.setOrientation(LinearLayout.VERTICAL); root.setPadding((int)dp(18),(int)dp(8),(int)dp(18),(int)dp(8));
            ScrollView scroll=new ScrollView(MainActivity.this);
            LinearLayout content=new LinearLayout(MainActivity.this); content.setOrientation(LinearLayout.VERTICAL);
            TextView title=new TextView(MainActivity.this); title.setText("METEO ATTUALE"); title.setTextSize(18); title.setTextColor(yellow); content.addView(title);
            TextView place=new TextView(MainActivity.this); place.setText(weatherPlaceName.isEmpty()?"Luogo in rilevamento…":weatherPlaceName); place.setTextSize(14); place.setTextColor(0xFF8ED7FF); content.addView(place);
            TextView current=new TextView(MainActivity.this); current.setText(weatherSummary+"\n"+weatherDetail); current.setTextSize(15); current.setTextColor(Color.WHITE); current.setPadding(0,(int)dp(6),0,(int)dp(12)); content.addView(current);
            TextView hoursTitle=new TextView(MainActivity.this); hoursTitle.setText("PREVISIONI ORARIE"); hoursTitle.setTextSize(16); hoursTitle.setTextColor(yellow); content.addView(hoursTitle);
            TextView hours=new TextView(MainActivity.this); hours.setText(weatherHourlySummary.isEmpty()?(weatherLoading?"Caricamento…":"Previsioni non disponibili"):weatherHourlySummary); hours.setTextSize(14); hours.setTextColor(Color.WHITE); hours.setPadding(0,(int)dp(6),0,(int)dp(14)); content.addView(hours);
            TextView dt=null, dc=null, dh=null;
            if(navigationActive && !Double.isNaN(navigationDestLat)) {
                dt=new TextView(MainActivity.this); dt.setText("METEO DESTINAZIONE"); dt.setTextSize(18); dt.setTextColor(yellow); content.addView(dt);
                dc=new TextView(MainActivity.this); dc.setText(destinationWeatherLoading?"Caricamento…":(destinationWeatherSummary.isEmpty()?"Meteo destinazione non disponibile":destinationWeatherSummary)); dc.setTextSize(15); dc.setTextColor(Color.WHITE); dc.setPadding(0,(int)dp(6),0,(int)dp(10)); content.addView(dc);
                dh=new TextView(MainActivity.this); dh.setText(destinationWeatherHourlySummary.isEmpty()?(destinationWeatherLoading?"Caricamento…":"Previsioni non disponibili"):destinationWeatherHourlySummary); dh.setTextSize(14); dh.setTextColor(Color.WHITE); content.addView(dh);
            }
            scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,(int)dp(430)));
            final TextView fPlace=place, fCurrent=current, fHours=hours, fDest=dc, fDestHours=dh;
            final android.os.Handler handler=new android.os.Handler(Looper.getMainLooper());
            final AlertDialog dialog=new AlertDialog.Builder(MainActivity.this).setTitle("METEO").setView(root).setPositiveButton("CHIUDI",null).create();
            final Runnable updater=new Runnable(){ public void run(){
                fPlace.setText(weatherPlaceName.isEmpty()?"Luogo in rilevamento…":weatherPlaceName);
                fCurrent.setText(weatherSummary+"\n"+weatherDetail);
                fHours.setText(weatherHourlySummary.isEmpty()?(weatherLoading?"Caricamento…":"Previsioni non disponibili"):weatherHourlySummary);
                if(fDest!=null) fDest.setText(destinationWeatherLoading?"Caricamento…":(destinationWeatherSummary.isEmpty()?"Meteo destinazione non disponibile":destinationWeatherSummary));
                if(fDestHours!=null) fDestHours.setText(destinationWeatherHourlySummary.isEmpty()?(destinationWeatherLoading?"Caricamento…":"Previsioni non disponibili"):destinationWeatherHourlySummary);
                if(dialog.isShowing() && (weatherLoading || destinationWeatherLoading || weatherPlaceName.isEmpty())) handler.postDelayed(this,700);
            }};
            dialog.setOnDismissListener(d -> handler.removeCallbacks(updater));
            dialog.show();
            handler.post(updater);
        }

        void showNavigationDialog() { showNavigationDialog(Double.NaN, Double.NaN); }

        void showNavigationDialog(double pickedLat, double pickedLon) {
            final android.widget.LinearLayout box = new android.widget.LinearLayout(MainActivity.this);
            box.setOrientation(android.widget.LinearLayout.VERTICAL);
            box.setPadding((int)dp(18), (int)dp(4), (int)dp(18), 0);

            final android.widget.EditText departure = new android.widget.EditText(MainActivity.this);
            departure.setSingleLine(true);
            departure.setHint("Partenza (vuoto = posizione GPS)");
            departure.setTextSize(16f);

            final android.widget.AutoCompleteTextView destination = new android.widget.AutoCompleteTextView(MainActivity.this);
            destination.setSingleLine(true);
            destination.setHint("Destinazione");
            destination.setTextSize(16f);
            destination.setThreshold(0);
            final ArrayList<String> recentDestinations=getRecentDestinations();
            final ArrayAdapter<String> recentAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,recentDestinations);
            destination.setAdapter(recentAdapter);
            destination.setOnFocusChangeListener((v,has)->{if(has && !recentDestinations.isEmpty()) destination.postDelayed(destination::showDropDown,120);});
            destination.setOnClickListener(v->{if(!recentDestinations.isEmpty()) destination.showDropDown();});
            if(!Double.isNaN(pickedLat)&&!Double.isNaN(pickedLon)) destination.setText(String.format(Locale.US,"%.6f,%.6f",pickedLat,pickedLon));

            android.widget.LinearLayout depRow = new android.widget.LinearLayout(MainActivity.this);
            depRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            depRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            depRow.addView(departure, new android.widget.LinearLayout.LayoutParams(0, (int)dp(54), 1f));
            android.widget.Button depHomeBtn = new android.widget.Button(MainActivity.this);
            depHomeBtn.setText("CASA"); depHomeBtn.setTextSize(11f); depHomeBtn.setAllCaps(false);
            depRow.addView(depHomeBtn, new android.widget.LinearLayout.LayoutParams((int)dp(66), (int)dp(48)));
            box.addView(depRow);

            android.widget.LinearLayout destRow = new android.widget.LinearLayout(MainActivity.this);
            destRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            destRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            destRow.addView(destination, new android.widget.LinearLayout.LayoutParams(0, (int)dp(54), 1f));
            android.widget.Button destHomeBtn = new android.widget.Button(MainActivity.this);
            destHomeBtn.setText("CASA"); destHomeBtn.setTextSize(11f); destHomeBtn.setAllCaps(false);
            destRow.addView(destHomeBtn, new android.widget.LinearLayout.LayoutParams((int)dp(66), (int)dp(48)));
            box.addView(destRow);

            android.widget.LinearLayout saveRow = new android.widget.LinearLayout(MainActivity.this);
            saveRow.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
            android.widget.Button saveHomeBtn = new android.widget.Button(MainActivity.this);
            saveHomeBtn.setText("SALVA CASA"); saveHomeBtn.setTextSize(10f); saveHomeBtn.setAllCaps(false);
            saveRow.addView(saveHomeBtn, new android.widget.LinearLayout.LayoutParams((int)dp(110), (int)dp(38)));
            box.addView(saveRow);

            final android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
            final String savedHome = prefs.getString(PREF_HOME_ADDRESS, "");
            if (!savedHome.isEmpty()) { depHomeBtn.setText("CASA ✓"); destHomeBtn.setText("CASA ✓"); }

            depHomeBtn.setOnClickListener(v -> fillHome(departure));
            destHomeBtn.setOnClickListener(v -> fillHome(destination));
            saveHomeBtn.setOnClickListener(v -> {
                String home = destination.getText().toString().trim();
                if (home.isEmpty()) home = departure.getText().toString().trim();
                if (home.isEmpty()) {
                    android.widget.Toast.makeText(MainActivity.this, "Inserisci prima l'indirizzo di casa", android.widget.Toast.LENGTH_SHORT).show();
                    return;
                }
                android.content.SharedPreferences.Editor e = prefs.edit().putString(PREF_HOME_ADDRESS, home);
                Location currentHome = engine.loc;
                if (isUsableNavigationStart(currentHome)) {
                    e.putString(PREF_HOME_LAT, Double.toString(currentHome.getLatitude()));
                    e.putString(PREF_HOME_LON, Double.toString(currentHome.getLongitude()));
                    e.apply();
                    depHomeBtn.setText("CASA ✓"); destHomeBtn.setText("CASA ✓");
                    android.widget.Toast.makeText(MainActivity.this, "CASA memorizzata con posizione GPS", android.widget.Toast.LENGTH_SHORT).show();
                } else {
                    e.remove(PREF_HOME_LAT).remove(PREF_HOME_LON).apply();
                    depHomeBtn.setText("CASA ✓"); destHomeBtn.setText("CASA ✓");
                    android.widget.Toast.makeText(MainActivity.this, "Indirizzo di casa memorizzato", android.widget.Toast.LENGTH_SHORT).show();
                }
            });

            android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(MainActivity.this)
                    .setTitle(navigationActive ? "NAVIGAZIONE ATTIVA" : "NAVIGAZIONE")
                    .setView(box)
                    .setNegativeButton("ANNULLA", null);
            if (navigationActive) b.setNeutralButton("STOP NAV", (d,w)-> stopNavigation());
            b.setPositiveButton("VAI", null);
            final android.app.AlertDialog dialog=b.create();
            dialog.setOnShowListener(d -> {
                android.widget.Button go=dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
                go.setOnClickListener(v -> {
                    String from=departure.getText().toString().trim();
                    String to=destination.getText().toString().trim();
                    if(to.isEmpty()) {
                        android.widget.Toast.makeText(MainActivity.this,"Inserisci una destinazione",android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }
                    dialog.dismiss();
                    startNavigation(from,to);
                });
            });
            dialog.show();
        }


        ArrayList<String> getRecentDestinations() {
            ArrayList<String> list=new ArrayList<>();
            String raw=getSharedPreferences("road_display",MODE_PRIVATE).getString(PREF_RECENT_DESTINATIONS,"");
            if(raw.isEmpty()) return list;
            try { JSONArray a=new JSONArray(raw); for(int i=0;i<a.length() && list.size()<10;i++){String x=a.optString(i,"").trim(); if(!x.isEmpty()&&!list.contains(x))list.add(x);} } catch(Exception ignored) {}
            return list;
        }
        void saveRecentDestination(String value) {
            String x=value==null?"":value.trim(); if(x.isEmpty()) return;
            ArrayList<String> list=getRecentDestinations(); list.remove(x); list.add(0,x); while(list.size()>10)list.remove(list.size()-1);
            JSONArray a=new JSONArray(); for(String item:list)a.put(item);
            getSharedPreferences("road_display",MODE_PRIVATE).edit().putString(PREF_RECENT_DESTINATIONS,a.toString()).apply();
        }

        void fillHome(android.widget.EditText field) {
            android.content.SharedPreferences p = getSharedPreferences("road_display", MODE_PRIVATE);
            String home = p.getString(PREF_HOME_ADDRESS, "");
            if (home.isEmpty()) {
                android.widget.Toast.makeText(MainActivity.this, "Prima salva l'indirizzo di casa", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            field.setText(home);
            field.setSelection(field.length());
        }

        void stopNavigation() {
            navigationActive=false; navigationLoading=false; navigationStatus=""; navigationInstruction=""; navigationDistance=""; navigationDestinationDistance="";
            synchronized (navigationLock) { navigationRoute.clear(); navigationSteps.clear(); }
            navigationStepIndex=0; lastSpokenNavigationStep=-1; lastSpokenNavigationStage=-1; navigationDestLat=Double.NaN; navigationDestLon=Double.NaN; navigationDestinationLabel=""; view.invalidate();
        }

        boolean isUsableNavigationStart(Location l) {
            if (l == null) return false;
            if (LocationManager.GPS_PROVIDER.equals(l.getProvider()) && l.hasAccuracy() && l.getAccuracy() <= 80f) return true;
            long age = Math.abs(System.currentTimeMillis() - l.getTime());
            return age <= 15L * 60L * 1000L && l.hasAccuracy() && l.getAccuracy() <= 250f;
        }

        Location getBestLastKnownNavigationStart() {
            Location best = null;
            if (lm != null) {
                String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
                for (String provider : providers) {
                    try {
                        Location candidate = lm.getLastKnownLocation(provider);
                        if (candidate == null) continue;
                        long age = Math.abs(System.currentTimeMillis() - candidate.getTime());
                        if (age > 2L * 60L * 60L * 1000L) continue;
                        if (best == null || (candidate.hasAccuracy() && (!best.hasAccuracy() || candidate.getAccuracy() < best.getAccuracy())) || candidate.getTime() > best.getTime()) best = new Location(candidate);
                    } catch (Exception ignored) { }
                }
            }
            if (best == null) {
                Location saved = loadSavedLocation();
                if (saved != null) {
                    long age = Math.abs(System.currentTimeMillis() - saved.getTime());
                    if (age <= 24L * 60L * 60L * 1000L) best = saved;
                }
            }
            return best;
        }

        void startNavigation(final String departureQuery, final String destinationQuery) {
            final String fromQuery = departureQuery == null ? "" : departureQuery.trim();
            final String toQuery = destinationQuery == null ? "" : destinationQuery.trim();
            Location gpsStart = engine.loc;
            if (fromQuery.isEmpty() && !isUsableNavigationStart(gpsStart)) {
                Location fallback = getBestLastKnownNavigationStart();
                if (fallback != null) {
                    gpsStart = fallback;
                    engine.loc = new Location(fallback);
                }
            }

            if (toQuery.isEmpty()) {
                navigationStatus="DESTINAZIONE MANCANTE";
                navigationActive=false; navigationLoading=false; view.invalidate();
                return;
            }
            if (fromQuery.isEmpty() && gpsStart == null) {
                navigationStatus="POSIZIONE DI PARTENZA NON DISPONIBILE";
                navigationActive=false; navigationLoading=false; view.invalidate();
                return;
            }

            // Snapshot the selected start position before entering the worker thread.
            // Java lambdas may capture only final/effectively-final local variables.
            final Location navigationStart = gpsStart == null ? null : new Location(gpsStart);

            navigationLoading=true;
            navigationActive=false;
            navigationStatus="RICERCA DESTINAZIONE…";
            view.invalidate();

            new Thread(() -> {
                HttpURLConnection conn=null;
                try {
                    Location start = navigationStart == null ? null : new Location(navigationStart);
                    android.content.SharedPreferences hp=getSharedPreferences("road_display", MODE_PRIVATE);
                    String savedHome=hp.getString(PREF_HOME_ADDRESS, "");

                    if(!fromQuery.isEmpty()) {
                        double[] home=homeCoordsIfMatch(fromQuery,savedHome,hp);
                        if(home!=null) {
                            start=new Location("saved-home");
                            start.setLatitude(home[0]); start.setLongitude(home[1]);
                        } else {
                            start=geocodeAddressPhoton(fromQuery);
                            if(start==null) start=geocodeAddressNominatim(fromQuery);
                            if(start==null) throw new Exception("Partenza non trovata");
                        }
                    }

                    if(start==null) throw new Exception("Posizione di partenza non disponibile");

                    navigationStatus="RICERCA DESTINAZIONE…";
                    view.postInvalidate();
                    Location destinationLocation;
                    double[] homeDestination=homeCoordsIfMatch(toQuery,savedHome,hp);
                    if(homeDestination!=null) {
                        destinationLocation=new Location("saved-home");
                        destinationLocation.setLatitude(homeDestination[0]); destinationLocation.setLongitude(homeDestination[1]);
                    } else {
                        destinationLocation=geocodeAddressPhoton(toQuery);
                        if(destinationLocation==null) destinationLocation=geocodeAddressNominatim(toQuery);
                    }
                    if(destinationLocation==null) throw new Exception("Destinazione non trovata");

                    final double lat=destinationLocation.getLatitude();
                    final double lon=destinationLocation.getLongitude();
                    navigationDestLat=lat; navigationDestLon=lon; navigationDestinationLabel=toQuery;
                    saveRecentDestination(toQuery);
                    view.postInvalidate();
                    navigationStatus="CALCOLO PERCORSO…";
                    view.postInvalidate();

                    String routeUrl="https://router.project-osrm.org/route/v1/driving/"
                            +start.getLongitude()+","+start.getLatitude()+";"+lon+","+lat
                            +"?overview=full&geometries=geojson&steps=true&alternatives=false";
                    conn=(HttpURLConnection)new URL(routeUrl).openConnection();
                    conn.setConnectTimeout(9000); conn.setReadTimeout(15000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept","application/json");
                    conn.setRequestProperty("User-Agent","RoadDisplayPRO/3.22.17 (Android motorcycle dashboard; map attribution visible)");
                    int response=conn.getResponseCode();
                    if(response!=HttpURLConnection.HTTP_OK) throw new Exception("Routing HTTP "+response);
                    String json=readHttp(conn);
                    conn.disconnect(); conn=null;

                    JSONObject root=new JSONObject(json);
                    if(!"Ok".equalsIgnoreCase(root.optString("code"))) throw new Exception("Percorso non disponibile");
                    JSONArray routes=root.optJSONArray("routes");
                    if(routes==null || routes.length()==0) throw new Exception("Nessun percorso trovato");
                    JSONObject route=routes.getJSONObject(0);
                    JSONObject geometry=route.optJSONObject("geometry");
                    JSONArray coords=geometry==null?null:geometry.optJSONArray("coordinates");
                    if(coords==null || coords.length()<2) throw new Exception("Geometria percorso assente");

                    ArrayList<RoutePoint> newRoute=new ArrayList<>();
                    for(int i=0;i<coords.length();i++) {
                        JSONArray pt=coords.getJSONArray(i);
                        if(pt.length()>=2) newRoute.add(new RoutePoint(pt.getDouble(1),pt.getDouble(0)));
                    }
                    if(newRoute.size()<2) throw new Exception("Percorso non valido");

                    ArrayList<RouteStep> newSteps=new ArrayList<>();
                    JSONArray legs=route.optJSONArray("legs");
                    if(legs!=null) for(int li=0;li<legs.length();li++) {
                        JSONArray steps=legs.getJSONObject(li).optJSONArray("steps");
                        if(steps==null) continue;
                        for(int si=0;si<steps.length();si++) {
                            JSONObject st=steps.getJSONObject(si);
                            JSONObject man=st.optJSONObject("maneuver");
                            if(man==null) continue;
                            JSONArray loc=man.optJSONArray("location");
                            if(loc==null || loc.length()<2) continue;
                            String type=man.optString("type","");
                            String mod=man.optString("modifier","");
                            String name=st.optString("name","");
                            if(name.isEmpty()) name=st.optString("ref","");
                            double dist=st.optDouble("distance",0);
                            String ins=navInstruction(type,mod,name);
                            int roundaboutExit=man.optInt("exit",-1);
                            if (("roundabout".equals(type) || "rotary".equals(type)) && roundaboutExit > 0) {
                                ins = "ROTONDA · " + ordinalItalian(roundaboutExit).toUpperCase(Locale.ROOT) + " USCITA";
                            }
                            newSteps.add(new RouteStep(loc.getDouble(1),loc.getDouble(0),dist,ins,name,type,roundaboutExit));
                        }
                    }

                    synchronized(navigationLock) {
                        navigationRoute.clear(); navigationRoute.addAll(newRoute);
                        navigationSteps.clear(); navigationSteps.addAll(newSteps);
                        navigationStepIndex=navigationSteps.isEmpty()?0:firstUsefulStep(start);
                        lastSpokenNavigationStep=-1;
                        lastSpokenNavigationStage=-1;
                        navigationInstruction=navigationSteps.isEmpty()?"PROSEGUI":navigationSteps.get(navigationStepIndex).instruction;
                        navigationDistance=navigationSteps.isEmpty()?"":formatNavDistance(start);
                        navigationStatus="";
                        navigationActive=true;
                        navigationLoading=false;
                        navigationLastRouteAt=System.currentTimeMillis();
                    }
                    if(!newSteps.isEmpty()) { speakNavigationMessage("Navigazione avviata."); }
                    view.postInvalidate();
                } catch(Exception ex) {
                    if(conn!=null) try { conn.disconnect(); } catch(Exception ignored) {}
                    navigationLoading=false; navigationActive=false;
                    navigationStatus="NAVIGAZIONE NON DISPONIBILE";
                    navigationInstruction=""; navigationDistance=""; navigationDestinationDistance="";
                    view.postInvalidate();
                }
            },"navigation-route").start();
        }

        // Global geocoder: Photon/OpenStreetMap is tried first so the app is not Spain-specific.
        // CartoCiudad remains a Spain-specific high-quality fallback, then global Nominatim.
        Location geocodeAddressPhoton(String query) throws Exception {
            String clean = query == null ? "" : query.trim();
            if (clean.isEmpty()) return null;
            String enc = java.net.URLEncoder.encode(clean, "UTF-8");
            String url = "https://photon.komoot.io/api/?q=" + enc + "&limit=8&lang=it";
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestMethod("GET");
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("User-Agent", "RoadDisplayPRO/3.22.17 (Android motorcycle dashboard)");
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) return null;
                JSONObject root = new JSONObject(readHttp(c));
                JSONArray features = root.optJSONArray("features");
                if (features == null || features.length() == 0) return null;
                String ql = clean.toLowerCase(Locale.ROOT);
                JSONObject best = null; int bestScore = Integer.MIN_VALUE;
                for (int i=0; i<features.length(); i++) {
                    JSONObject f = features.optJSONObject(i); if (f == null) continue;
                    JSONObject prop = f.optJSONObject("properties");
                    JSONObject geom = f.optJSONObject("geometry");
                    JSONArray coord = geom == null ? null : geom.optJSONArray("coordinates");
                    if (coord == null || coord.length() < 2) continue;
                    String hay = prop == null ? "" : prop.toString().toLowerCase(Locale.ROOT);
                    int score = 0;
                    String[] toks = ql.split("\\s+");
                    for (String t : toks) if (t.length() >= 3 && hay.contains(t)) score += 5;
                    if (prop != null) {
                        String hnum = prop.optString("housenumber", "");
                        String street = prop.optString("street", "");
                        if (!hnum.isEmpty() && ql.contains(hnum.toLowerCase(Locale.ROOT))) score += 25;
                        if (!street.isEmpty() && ql.contains(street.toLowerCase(Locale.ROOT))) score += 25;
                    }
                    if (score > bestScore) { bestScore = score; best = f; }
                }
                if (best == null) return null;
                JSONArray coord = best.getJSONObject("geometry").getJSONArray("coordinates");
                Location r = new Location("photon");
                r.setLongitude(coord.getDouble(0)); r.setLatitude(coord.getDouble(1));
                return r;
            } finally { if (c != null) c.disconnect(); }
        }

        Location geocodeAddressCartoCiudad(String query) throws Exception {
            String clean = query == null ? "" : query.trim();
            if (clean.isEmpty()) return null;
            String[] queries = new String[]{
                    clean + ", Adeje, Santa Cruz de Tenerife",
                    clean + ", Tenerife, Canarias"
            };
            for (String q : queries) {
                String enc = java.net.URLEncoder.encode(q, "UTF-8");
                String url = "https://www.cartociudad.es/geocoder/api/geocoder/candidates?q=" + enc
                        + "&limit=12&countrycode=es";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection)new URL(url).openConnection();
                    c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestMethod("GET");
                    c.setRequestProperty("Accept", "application/json");
                    c.setRequestProperty("User-Agent", "RoadDisplayPRO/3.22.17 (Android motorcycle dashboard)");
                    if (c.getResponseCode() != HttpURLConnection.HTTP_OK) continue;
                    JSONArray arr = new JSONArray(readHttp(c));
                    JSONObject best = null; int bestScore = Integer.MIN_VALUE;
                    for (int i=0;i<arr.length();i++) {
                        JSONObject it = arr.getJSONObject(i);
                        String type = it.optString("type", "");
                        String address = it.optString("address", "");
                        String muni = it.optString("muni", "");
                        String poblacion = it.optString("poblacion", "");
                        String hay = (address + " " + muni + " " + poblacion).toLowerCase(Locale.ROOT);
                        int score = 0;
                        if ("portal".equalsIgnoreCase(type)) score += 100;
                        if (hay.contains("adeje")) score += 50;
                        if (hay.contains("tijoco")) score += 40;
                        String[] toks = clean.toLowerCase(Locale.ROOT).split("\\s+");
                        for (String t : toks) if (t.length() >= 3 && hay.contains(t)) score += 5;
                        if (it.has("lat") && it.has("lng")) score += 10;
                        if (score > bestScore) { bestScore = score; best = it; }
                    }
                    if (best != null && best.has("lat") && best.has("lng")) {
                        Location r = new Location("cartociudad");
                        r.setLatitude(best.getDouble("lat")); r.setLongitude(best.getDouble("lng"));
                        return r;
                    }
                } finally { if (c != null) c.disconnect(); }
            }
            return null;
        }

        Location geocodeAddressNominatim(String query) throws Exception {
            long now=System.currentTimeMillis();
            long wait=1000L-(now-lastNominatimGeocodeAt);
            if(wait>0) Thread.sleep(wait);
            lastNominatimGeocodeAt=System.currentTimeMillis();
            String clean=query.trim();
            Matcher coord=Pattern.compile("@?\\s*(-?\\d+(?:\\.\\d+)?)[,;]\\s*(-?\\d+(?:\\.\\d+)?)").matcher(clean);
            if(coord.matches()) {
                double lat=Double.parseDouble(coord.group(1)), lon=Double.parseDouble(coord.group(2));
                if(Math.abs(lat)<=90 && Math.abs(lon)<=180) { Location r=new Location("saved-coordinate"); r.setLatitude(lat); r.setLongitude(lon); return r; }
            }
            String[] queries = new String[]{ clean };
            JSONArray bestArr=null;
            for(int qi=0;qi<queries.length;qi++) {
                if(qi>0) { Thread.sleep(Math.max(0L,1000L-(System.currentTimeMillis()-lastNominatimGeocodeAt))); lastNominatimGeocodeAt=System.currentTimeMillis(); }
                String enc=java.net.URLEncoder.encode(queries[qi],"UTF-8");
                String url="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&addressdetails=1&layer=address&accept-language=it,en&q="+enc;
                HttpURLConnection c=null;
                try {
                    c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestMethod("GET"); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("User-Agent","RoadDisplayPRO/3.22.17 (Android motorcycle dashboard; map attribution visible)");
                    if(c.getResponseCode()!=HttpURLConnection.HTTP_OK) continue;
                    JSONArray arr=new JSONArray(readHttp(c)); if(arr.length()>0){bestArr=arr; break;}
                } finally { if(c!=null)c.disconnect(); }
            }
            if(bestArr==null||bestArr.length()==0)return null;
            String ql=clean.toLowerCase(Locale.ROOT);
            JSONObject best=bestArr.getJSONObject(0); int bestScore=Integer.MIN_VALUE;
            for(int i=0;i<bestArr.length();i++){ JSONObject it=bestArr.getJSONObject(i); String disp=it.optString("display_name","").toLowerCase(Locale.ROOT); String name=it.optString("name","").toLowerCase(Locale.ROOT); int score=0;
                String[] toks=ql.split("\\s+"); for(String t:toks) if(t.length()>=3&&disp.contains(t))score+=5;
                if(!name.isEmpty()&&ql.contains(name))score+=10;
                JSONObject addr=it.optJSONObject("address");
                if(addr!=null){
                    String hn=addr.optString("house_number","");
                    String st=addr.optString("road","");
                    if(!hn.isEmpty()&&ql.matches(".*\\b"+java.util.regex.Pattern.quote(hn.toLowerCase(Locale.ROOT))+"\\b.*"))score+=25;
                    if(!st.isEmpty()&&ql.contains(st.toLowerCase(Locale.ROOT)))score+=25;
                }
                if(score>bestScore){bestScore=score;best=it;}
            }
            Location result=new Location("nominatim"); result.setLatitude(best.getDouble("lat")); result.setLongitude(best.getDouble("lon")); return result;
        }

        double[] homeCoordsIfMatch(String query,String savedHome,android.content.SharedPreferences hp) {
            if(savedHome.isEmpty() || query.isEmpty() || !query.equalsIgnoreCase(savedHome)) return null;
            try {
                double lat=Double.parseDouble(hp.getString(PREF_HOME_LAT,"NaN"));
                double lon=Double.parseDouble(hp.getString(PREF_HOME_LON,"NaN"));
                if(!Double.isNaN(lat)&&!Double.isNaN(lon)) return new double[]{lat,lon};
            } catch(Exception ignored) {}
            return null;
        }

        String readHttp(HttpURLConnection c) throws Exception { try(InputStream in=c.getInputStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);return b.toString();} }
        int firstUsefulStep(Location l){
            synchronized(navigationLock){
                if(navigationSteps.isEmpty())return 0;
                if(l==null||navigationRoute.size()<2)return 0;
                int currentRouteIndex=0; double currentBest=Double.MAX_VALUE;
                for(int i=0;i<navigationRoute.size();i++){RoutePoint p=navigationRoute.get(i);double d=distanceMeters(l.getLatitude(),l.getLongitude(),p.lat,p.lon);if(d<currentBest){currentBest=d;currentRouteIndex=i;}}
                for(int i=0;i<navigationSteps.size();i++){
                    RouteStep st=navigationSteps.get(i); int stepRouteIndex=0; double best=Double.MAX_VALUE;
                    for(int j=0;j<navigationRoute.size();j++){RoutePoint p=navigationRoute.get(j);double d=distanceMeters(st.lat,st.lon,p.lat,p.lon);if(d<best){best=d;stepRouteIndex=j;}}
                    if(stepRouteIndex>=currentRouteIndex-3)return i;
                }
                return Math.max(0,navigationSteps.size()-1);
            }
        }
        RouteStep upcomingRoundaboutLocked(Location l) {
            if (l == null || navigationSteps.isEmpty()) return null;
            int start = Math.max(0, Math.min(navigationStepIndex, navigationSteps.size() - 1));
            RouteStep best = null; double bestD = Double.MAX_VALUE;
            for (int i = start; i < Math.min(navigationSteps.size(), start + 2); i++) {
                RouteStep st = navigationSteps.get(i);
                String type = st.maneuverType == null ? "" : st.maneuverType.toLowerCase(Locale.ROOT);
                if (!("roundabout".equals(type) || "rotary".equals(type))) continue;
                double d = distanceMeters(l.getLatitude(), l.getLongitude(), st.lat, st.lon);
                if (d <= 350.0 && d < bestD) { best = st; bestD = d; }
            }
            return best;
        }

        int directionFromModifier(String type) {
            if (type == null) return 1;
            String x = type.toLowerCase(Locale.ROOT);
            return (x.contains("left")) ? -1 : 1;
        }

        String navInstruction(String type,String modifier,String name){String m=modifier==null?"":modifier; if("roundabout".equals(type)||"rotary".equals(type))return "ROTONDA"; if("arrive".equals(type))return "ARRIVO"; if("merge".equals(type))return "IMMETTITI"; if("fork".equals(type))return "BIVIO"; if("uturn".equals(type))return "INVERSIONE"; if("new name".equals(type))return "PROSEGUI"; return directionLabel(m);}
        String directionLabel(String m){if("left".equals(m))return "SVOLTA A SINISTRA";if("right".equals(m))return "SVOLTA A DESTRA";if("slight left".equals(m))return "SINISTRA LEGGERA";if("slight right".equals(m))return "DESTRA LEGGERA";if("sharp left".equals(m))return "SINISTRA STRETTA";if("sharp right".equals(m))return "DESTRA STRETTA";return "PROSEGUI";}
        String formatNavDistance(Location l){synchronized(navigationLock){if(navigationSteps.isEmpty())return "";int idx=Math.min(navigationStepIndex,navigationSteps.size()-1);RouteStep st=navigationSteps.get(idx);double d=distanceMeters(l.getLatitude(),l.getLongitude(),st.lat,st.lon);if(d<8&&idx<navigationSteps.size()-1){navigationStepIndex++;st=navigationSteps.get(navigationStepIndex);d=distanceMeters(l.getLatitude(),l.getLongitude(),st.lat,st.lon);navigationInstruction=st.instruction;}return d<1000?Math.max(0,Math.round(d))+" m":String.format(Locale.US,"%.1f km",d/1000.0);}}
        void speakNavigationMessage(String message) {
            if (!audio || !navigationTtsReady || navigationTts == null || message == null || message.trim().isEmpty()) return;
            final String spoken = message.trim();
            runOnUiThread(() -> {
                try { navigationTts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "nav-message-" + System.currentTimeMillis()); } catch (Exception ignored) {}
            });
        }

        String maneuverSpeech(String instruction) {
            if (instruction == null || instruction.trim().isEmpty()) return "prosegui";
            String x = instruction.toLowerCase(Locale.ITALIAN);
            if (x.contains("sinistra")) return "svolta a sinistra";
            if (x.contains("destra")) return "svolta a destra";
            if (x.contains("inversione")) return "fai inversione";
            if (x.contains("rotonda")) return "entra nella rotonda";
            if (x.contains("arrivo")) return "arrivo";
            if (x.contains("bivio")) return "al bivio";
            if (x.contains("immettiti")) return "immettiti";
            return x;
        }

        String ordinalItalian(int n) {
            switch(n) {
                case 1: return "prima"; case 2: return "seconda"; case 3: return "terza";
                case 4: return "quarta"; case 5: return "quinta"; case 6: return "sesta";
                default: return n + "ª";
            }
        }

        String maneuverSpeech(RouteStep st) {
            if(st == null) return "prosegui";
            String base = maneuverSpeech(st.instruction);
            String type = st.maneuverType == null ? "" : st.maneuverType.toLowerCase(Locale.ITALIAN);
            if(("roundabout".equals(type) || "rotary".equals(type)) && st.roundaboutExit > 0) {
                return "alla rotonda, prendi la " + ordinalItalian(st.roundaboutExit) + " uscita";
            }
            return base;
        }

        void speakNavigationStep(int index, RouteStep step, int stage, double distanceMetersValue) {
            if (!audio || !navigationTtsReady || navigationTts == null || step == null || step.instruction == null || step.instruction.isEmpty()) return;
            if (index == lastSpokenNavigationStep && stage == lastSpokenNavigationStage) return;

            // The threshold decides WHEN to speak; the actual GPS-derived distance decides WHAT to speak.
            // This avoids saying "500 m" when the rider is actually 380 m from the maneuver.
            int meters = Math.max(1, (int)Math.round(distanceMetersValue));
            StringBuilder msg = new StringBuilder();
            if (stage >= 2) {
                msg.append("Ora, ").append(maneuverSpeech(step));
            } else {
                msg.append("Tra ").append(meters).append(" metri, ").append(maneuverSpeech(step));
                if (stage == 0 && step.roadName != null && !step.roadName.trim().isEmpty() && !"ARRIVO".equalsIgnoreCase(step.instruction)) {
                    msg.append(" su ").append(step.roadName.trim());
                }
            }

            lastSpokenNavigationStep = index;
            lastSpokenNavigationStage = stage;
            final String spoken = msg.toString();
            runOnUiThread(() -> {
                try {
                    navigationTts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "nav-step-" + index + "-" + stage);
                } catch (Exception ignored) {}
            });
        }

        double distanceToRouteMeters(Location l) {
            synchronized (navigationLock) {
                if (l == null || navigationRoute == null || navigationRoute.size() < 2) return Float.MAX_VALUE;
                double best = Double.MAX_VALUE;
                for (int i=0;i<navigationRoute.size()-1;i++) {
                    RoutePoint a=navigationRoute.get(i), b=navigationRoute.get(i+1);
                    double d=distanceToSegmentMeters(l.getLatitude(),l.getLongitude(),a.lat,a.lon,b.lat,b.lon);
                    if (d<best) best=d;
                }
                return best;
            }
        }

        double distanceToSegmentMeters(double lat,double lon,double alat,double alon,double blat,double blon) {
            double cos=Math.cos(Math.toRadians(lat));
            double ax=(alon-lon)*111320.0*cos, ay=(alat-lat)*110540.0;
            double bx=(blon-lon)*111320.0*cos, by=(blat-lat)*110540.0;
            double dx=bx-ax, dy=by-ay, len2=dx*dx+dy*dy;
            double t=len2<0.001?0.0:Math.max(0.0,Math.min(1.0,-(ax*dx+ay*dy)/len2));
            return Math.hypot(ax+t*dx,ay+t*dy);
        }

        void requestNavigationReroute(Location l) {
            if (!navigationActive || l == null || Double.isNaN(navigationDestLat) || navigationRerouteInProgress) return;
            long now=System.currentTimeMillis();
            if (now-navigationLastRerouteAt < 7000L) return;
            navigationRerouteInProgress=true;
            navigationLastRerouteAt=now;
            final Location start=new Location(l);
            final double destLat=navigationDestLat, destLon=navigationDestLon;
            navigationStatus="RICALCOLO PERCORSO…";
            view.postInvalidate();
            new Thread(() -> {
                HttpURLConnection conn=null;
                try {
                    String routeUrl="https://router.project-osrm.org/route/v1/driving/"+
                            start.getLongitude()+","+start.getLatitude()+";"+destLon+","+destLat+
                            "?overview=full&geometries=geojson&steps=true&alternatives=false";
                    conn=(HttpURLConnection)new URL(routeUrl).openConnection();
                    conn.setConnectTimeout(9000); conn.setReadTimeout(15000); conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept","application/json");
                    conn.setRequestProperty("User-Agent","RoadDisplayPRO/3.22.17 (Android motorcycle dashboard)");
                    if(conn.getResponseCode()!=HttpURLConnection.HTTP_OK) throw new Exception("Routing HTTP "+conn.getResponseCode());
                    JSONObject root=new JSONObject(readHttp(conn));
                    if(!"Ok".equalsIgnoreCase(root.optString("code"))) throw new Exception("Percorso non disponibile");
                    JSONArray routes=root.optJSONArray("routes");
                    if(routes==null||routes.length()==0) throw new Exception("Nessun percorso trovato");
                    JSONObject route=routes.getJSONObject(0), geometry=route.optJSONObject("geometry");
                    JSONArray coords=geometry==null?null:geometry.optJSONArray("coordinates");
                    if(coords==null||coords.length()<2) throw new Exception("Geometria percorso assente");
                    ArrayList<RoutePoint> newRoute=new ArrayList<>();
                    for(int i=0;i<coords.length();i++){
                        JSONArray pt=coords.getJSONArray(i);
                        if(pt.length()>=2)newRoute.add(new RoutePoint(pt.getDouble(1),pt.getDouble(0)));
                    }
                    ArrayList<RouteStep> newSteps=new ArrayList<>();
                    JSONArray legs=route.optJSONArray("legs");
                    if(legs!=null)for(int li=0;li<legs.length();li++){
                        JSONArray steps=legs.getJSONObject(li).optJSONArray("steps"); if(steps==null)continue;
                        for(int si=0;si<steps.length();si++){
                            JSONObject st=steps.getJSONObject(si), man=st.optJSONObject("maneuver"); if(man==null)continue;
                            JSONArray loc=man.optJSONArray("location"); if(loc==null||loc.length()<2)continue;
                            String type=man.optString("type",""); String mod=man.optString("modifier","");
                            String name=st.optString("name",""); if(name.isEmpty())name=st.optString("ref","");
                            int exit=man.optInt("exit",-1);
                            String ins=navInstruction(type,mod,name);
                            if (("roundabout".equals(type) || "rotary".equals(type)) && exit > 0) {
                                ins = "ROTONDA · " + ordinalItalian(exit).toUpperCase(Locale.ROOT) + " USCITA";
                            }
                            newSteps.add(new RouteStep(loc.getDouble(1),loc.getDouble(0),st.optDouble("distance",0),ins,name,type,exit));
                        }
                    }
                    synchronized(navigationLock){
                        navigationRoute.clear(); navigationRoute.addAll(newRoute);
                        navigationSteps.clear(); navigationSteps.addAll(newSteps);
                        navigationStepIndex=navigationSteps.isEmpty()?0:firstUsefulStep(start);
                        lastSpokenNavigationStep=-1; lastSpokenNavigationStage=-1;
                        navigationInstruction=navigationSteps.isEmpty()?"PROSEGUI":navigationSteps.get(navigationStepIndex).instruction;
                        navigationDistance=navigationSteps.isEmpty()?"":formatNavDistance(start);
                        navigationStatus="";
                        navigationOffRouteSince=0L;
                        navigationRouteDeviation=0f;
                    }
                    // Rerouting is visual; do not add another unsolicited voice message.
                    // The next maneuver will be announced by the normal three-stage trigger.
                }catch(Exception ignored){
                    navigationStatus="";
                }finally{
                    if(conn!=null)try{conn.disconnect();}catch(Exception ignored){}
                    navigationRerouteInProgress=false;
                    if(view!=null)view.postInvalidate();
                }
            },"navigation-reroute").start();
        }

        void updateNavigation(Location l){
            synchronized (navigationLock) {
            if(!navigationActive||l==null||navigationSteps.isEmpty())return;
            navigationRouteDeviation=(float)distanceToRouteMeters(l);
            float speedKmh=l.hasSpeed()?l.getSpeed()*3.6f:0f;
            long now=System.currentTimeMillis();
            // Off-route is based on the actual routed polyline, not on the next maneuver point.
            // Require a short persistence window to reject isolated GPS spikes.
            if(navigationRouteDeviation>75f && speedKmh>=8f){
                if(navigationOffRouteSince==0L)navigationOffRouteSince=now;
                if(now-navigationOffRouteSince>=1800L)requestNavigationReroute(l);
            }else if(navigationRouteDeviation<45f){
                navigationOffRouteSince=0L;
            }

            int before=navigationStepIndex;
            navigationDistance=formatNavDistance(l);
            if(Double.isNaN(navigationDestLat))return;
            double dest=distanceMeters(l.getLatitude(),l.getLongitude(),navigationDestLat,navigationDestLon);
            navigationDestinationDistance=dest<1000?Math.max(0,Math.round(dest))+" m":String.format(Locale.US,"%.1f km",dest/1000.0);
            if(dest<25){
                navigationInstruction="ARRIVO";navigationDistance="0 m";
                if(lastSpokenNavigationStep!=-2){lastSpokenNavigationStep=-2;lastSpokenNavigationStage=3;speakNavigationMessage("Sei arrivato a destinazione.");}
                view.invalidate();return;
            }
            int idx=navigationStepIndex;
            if(idx>=0&&idx<navigationSteps.size()){
                RouteStep st=navigationSteps.get(idx);
                double d=distanceMeters(l.getLatitude(),l.getLongitude(),st.lat,st.lon);
                if(idx!=before)lastSpokenNavigationStage=-1;
                int stage=-1;
                // Deliberately sparse voice guidance: 250 m, 80 m, then the action.
                if(d<=12)stage=2;else if(d<=45)stage=1;else if(d<=150)stage=0;
                if(stage>=0&&(idx!=lastSpokenNavigationStep||stage>lastSpokenNavigationStage))speakNavigationStep(idx,st,stage,d);
            }
            if(navigationDistance.isEmpty())navigationDistance=formatNavDistance(l);
            view.invalidate();
            }
        }
        /**
         * Curve warning is a self-contained card.  The card owns its background,
         * icon and text, so nothing can bleed into the navigation instruction below
         * (or beside it).  The icon is deliberately centred on the card's geometric
         * centre, not on the text or on an approximate triangle vertex.
         */
        void drawNavigationCurveAlert(Canvas c, float left, float right, float top, float bottom, boolean land) {
            if (!navigationActive) return;
            Curve q = engine.current;
            if (q == null || !q.valid || q.distance < 0f || q.distance > 100f) return;

            boolean blink = q.distance <= 50f;
            if (blink && ((System.currentTimeMillis() / 500L) & 1L) != 0L) {
                postInvalidateDelayed(120L);
                return;
            }

            drawCurveAlertCard(c, new RectF(left, top, right, bottom), q, land);
            postInvalidateDelayed(blink ? 120L : 1000L);
        }

        void drawCurveAlertCard(Canvas c, RectF area, Curve q, boolean land) {
            if (q == null || !q.valid) return;
            float pad = dp(6);
            RectF card = new RectF(area.left + pad, area.top + pad, area.right - pad, area.bottom - pad);
            if (card.width() <= dp(80) || card.height() <= dp(70)) return;

            // Opaque background: this is intentional.  The warning must remain readable
            // over every possible navigation label and map/dashboard element.
            int bg = q.type == 5 ? 0xFF071A24 : (q.type >= 3 ? 0xFF211010 : 0xFF10161C);
            panel(c, card, bg, dp(10));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(2));
            stroke.setColor(q.type == 5 ? 0xFF55D6FF : (q.type >= 3 ? 0xFFFFD400 : 0xFF6F7C88));
            c.drawRoundRect(card, dp(10), dp(10), stroke);
            stroke.setStyle(Paint.Style.FILL);

            float cx = card.centerX();
            // Reserve the upper ~58% exclusively for the sign.  Its centre is exact,
            // and its maximum size is constrained by BOTH dimensions of the card.
            float iconCy = card.top + card.height() * .40f;
            float iconSize = Math.min(dp(70), Math.min(card.width() * .62f, card.height() * .47f));
            drawCurveSymbol(c, cx, iconCy, q, iconSize);

            float labelSize = land ? 11f : 12f;
            float distSize = land ? 16f : 18f;
            float dirSize = land ? 8.5f : 9.5f;
            txt(c, tr(q.label == null ? "CURVA" : q.label), cx,
                    card.top + card.height() * .68f, labelSize,
                    q.type == 5 ? 0xFF55D6FF : (q.type >= 3 ? 0xFFFFD400 : (q.type == 1 ? 0xFF35D66F : 0xFFFFD400)), Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx,
                    card.top + card.height() * .82f, distSize, yellow, Paint.Align.CENTER);
            txt(c, tr(q.dir < 0 ? "SINISTRA" : "DESTRA"), cx,
                    card.top + card.height() * .94f, dirSize, 0xFFE0E5EA, Paint.Align.CENTER);
        }

        void drawNavigationGuidance(Canvas c,float cx,float cy,boolean land,float availableW,float availableH){
            Location l=engine.loc;
            if(navigationLoading){txt(c,"NAVIGAZIONE…",cx,cy+dp(8),land?22:25,yellow,Paint.Align.CENTER);return;}
            if(!navigationActive){txt(c,"NAV",cx,cy+dp(8),land?22:25,0xFF6B737B,Paint.Align.CENTER);return;}
            if(l!=null) navigationDistance=formatNavDistance(l);
            String ins=navigationInstruction==null?"PROSEGUI":navigationInstruction;
            String d=navigationDistance==null?"":navigationDistance;
            String road="";
            synchronized(navigationLock){if(!navigationSteps.isEmpty()){int idx=Math.min(navigationStepIndex,navigationSteps.size()-1);road=navigationSteps.get(idx).roadName;}}
            float aw=Math.max(dp(120),availableW);
            float ah=Math.max(dp(90),availableH);
            float top=cy-ah/2f;
            // The curve warning is now a separate side-by-side card, so the navigation
            // guidance never needs to move itself downward to make room for it.
            float arrowCy = top + ah * .20f;
            float arrowSize=Math.min(land?dp(64):dp(72),ah*.20f);
            float arrowX=cx;
            String upper=ins.toUpperCase(Locale.ROOT);
            boolean right=upper.contains("DESTRA"), left=upper.contains("SINISTRA"), down=upper.contains("INVERSIONE");
            float dirX=right?1:left?-1:0;
            Path a=new Path();
            if(down){
                a.moveTo(arrowX,arrowCy-arrowSize*.28f);
                a.cubicTo(arrowX-arrowSize*.42f,arrowCy-arrowSize*.28f,arrowX-arrowSize*.42f,arrowCy+arrowSize*.22f,arrowX,arrowCy+arrowSize*.22f);
                a.lineTo(arrowX+arrowSize*.14f,arrowCy+arrowSize*.07f);
            } else {
                a.moveTo(arrowX,arrowCy+arrowSize*.28f);
                a.lineTo(arrowX+dirX*arrowSize*.25f,arrowCy);
                a.lineTo(arrowX+dirX*arrowSize*.25f,arrowCy-arrowSize*.28f);
            }
            stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK);stroke.setStrokeWidth(dp(14));c.drawPath(a,stroke);
            stroke.setColor(yellow);stroke.setStrokeWidth(dp(7));c.drawPath(a,stroke);
            Path head=new Path();
            float hx=down?arrowX+arrowSize*.14f:arrowX+dirX*arrowSize*.25f, hy=down?arrowCy+arrowSize*.07f:arrowCy-arrowSize*.28f;
            head.moveTo(hx-arrowSize*.12f,hy+arrowSize*.12f);head.lineTo(hx,hy-arrowSize*.12f);head.lineTo(hx+arrowSize*.12f,hy+arrowSize*.12f);
            stroke.setColor(Color.BLACK);stroke.setStrokeWidth(dp(12));c.drawPath(head,stroke);stroke.setColor(yellow);stroke.setStrokeWidth(dp(6));c.drawPath(head,stroke);

            float maxW=aw-dp(12);
            String line1=upper, line2=road==null?"":road.trim();
            p.setTypeface(TypefaceCompat.bold());
            float size=land?16f:18f;
            while(size>8f){p.setTextSize(size*density);if(p.measureText(line1)<=maxW)break;size-=.5f;}
            if(p.measureText(line1)>maxW){
                int cut=line1.lastIndexOf(' ',Math.min(line1.length()-1,Math.max(1,line1.length()/2+3)));
                if(cut>0){String second=line1.substring(cut+1);line1=line1.substring(0,cut);if(line2.isEmpty())line2=second;}
            }
            txt(c,line1,cx,top+ah*.43f,size,Color.WHITE,Paint.Align.CENTER);
            if(!line2.isEmpty()){
                float roadSize=Math.max(8f,Math.min(size-1f,land?14f:15f));
                while(roadSize>8f){p.setTextSize(roadSize*density);if(p.measureText(line2)<=maxW)break;roadSize-=.5f;}
                txt(c,line2,cx,top+ah*.58f,roadSize,0xFFDCE3E8,Paint.Align.CENTER);
            }
            txt(c,d,cx,top+ah*.74f,land?22:25,yellow,Paint.Align.CENTER);
            if(!navigationDestinationDistance.isEmpty()){
                txt(c,"DESTINAZIONE  "+navigationDestinationDistance,cx,top+ah*.91f,land?14:15,0xFF65D7FF,Paint.Align.CENTER);
            }
        }

        void drawExpandedMap(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            c.drawColor(0xFF05080B);
            RectF full = new RectF(0, 0, w, h);
            mapBounds.set(full);
            drawRoadMap(c, full, engine.loc, true);

            // Map toolbar: landscape keeps one compact row. Portrait uses two rows
            // (3 + 2 buttons), with generous button widths so labels remain readable.
            // The toolbar stays at the upper-left, leaving the map centre unobstructed.
            float gap = Math.max(dp(5), Math.min(dp(9), w * .012f));
            float side = Math.max(dp(8), Math.min(dp(14), w * .018f));
            float top = Math.max(dp(8), Math.min(dp(12), h * .012f));
            float barH = land ? Math.max(dp(42), Math.min(dp(54), h * .055f))
                              : Math.max(dp(42), Math.min(dp(50), h * .050f));
            if (!land) {
                float buttonW = Math.min(dp(190), (w - 2f * side - 2f * gap) / 3f);
                float groupW = 3f * buttonW + 2f * gap;
                float left = side;
                mapRecenterBounds.set(left, top, left + buttonW, top + barH);
                mapSetDestBounds.set(left + buttonW + gap, top, left + 2f * buttonW + gap, top + barH);
                mapSetHomeBounds.set(left + 2f * (buttonW + gap), top, left + 3f * buttonW + 2f * gap, top + barH);
                float row2Top = top + barH + gap;
                float row2W = Math.min(dp(190), (groupW - gap) / 2f);
                float row2Left = left + (groupW - (2f * row2W + gap)) / 2f;
                mapClearPointBounds.set(row2Left, row2Top, row2Left + row2W, row2Top + barH);
                mapCloseBounds.set(row2Left + row2W + gap, row2Top, row2Left + 2f * row2W + gap, row2Top + barH);
            } else {
                float buttonW = Math.min(dp(230), (w - 2f * side - 4f * gap) / 5f);
                float groupW = 5f * buttonW + 4f * gap;
                float left = (w - groupW) * .5f;
                mapRecenterBounds.set(left, top, left + buttonW, top + barH);
                mapSetDestBounds.set(left + buttonW + gap, top, left + 2f * buttonW + gap, top + barH);
                mapSetHomeBounds.set(left + 2f * (buttonW + gap), top, left + 3f * buttonW + 2f * gap, top + barH);
                mapClearPointBounds.set(left + 3f * (buttonW + gap), top, left + 4f * buttonW + 3f * gap, top + barH);
                mapCloseBounds.set(left + 4f * (buttonW + gap), top, left + 5f * buttonW + 4f * gap, top + barH);
            }
            drawMapToolbarButton(c, mapRecenterBounds, tr("RICENTRA GPS"), yellow);
            drawMapToolbarButton(c, mapSetDestBounds, tr("DESTINAZIONE QUI"), yellow);
            drawMapToolbarButton(c, mapSetHomeBounds, tr("SALVA CASA QUI"), yellow);
            drawMapToolbarButton(c, mapClearPointBounds, tr("ELIMINA PUNTO"), Color.WHITE);
            drawMapToolbarButton(c, mapCloseBounds, tr("CHIUDI ✕"), Color.WHITE);
        }

        void drawMapToolbarButton(Canvas c, RectF r, String label, int color) {
            panel(c, r, 0xFF202A33, dp(7));
            stroke.setColor(0xFFE4E8EC); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            c.drawRoundRect(r, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            float fs = Math.min(11f, Math.max(8.5f, (r.width() / density) * .052f));
            p.setTypeface(TypefaceCompat.bold()); p.setTextSize(fs * density);
            while (p.measureText(label) > r.width() - dp(10) && fs > 7.5f) { fs -= .5f; p.setTextSize(fs * density); }
            txt(c, label, r.centerX(), r.centerY() + dp(4), fs, color, Paint.Align.CENTER);
        }

        float speed(Location l) { return l.hasSpeed() ? l.getSpeed() * 3.6f : 0f; }
        String fmtDist(float d) { return d < 1000 ? Math.round(d) + " m" : String.format(Locale.US, "%.1f km", d / 1000f); }

        void drawSpeed(Canvas c, float cx, float baseY, float s, float rec, int speedLimit, boolean land) {
            int value=Math.max(0,Math.min(999,Math.round(s)));
            String digits=String.format(Locale.US,"%03d",value);
            float w=getWidth(),h=getHeight();
            // Size the tachometer from the actual screen dimensions, with separate portrait/landscape caps.
            // Taller, more readable race-style tachometer. Keep the three digits
            // separated while using the available display area efficiently.
            float targetHeight=land ? Math.min(520f, h*.58f) : Math.min(760f, h*.37f);
            float digitWidthFactor=3f*.42f+2f*.10f;
            float widthLimit=(w*(land?.50f:.99f)-dp(24))/digitWidthFactor;
            float topLimit=land?h*.10f:h*.29f, bottomLimit=land?h*.82f:h*.77f;
            float heightLimit=Math.max(90f,Math.min((baseY-topLimit)/.78f,(bottomLimit-baseY)/.12f));
            float numberHeight=Math.max(dp(90),Math.min(targetHeight,Math.min(widthLimit,heightLimit)));
            android.content.SharedPreferences prefs=getSharedPreferences("road_display",MODE_PRIVATE);
            int yellowAt=prefs.getInt("speed_yellow",90),redAt=prefs.getInt("speed_red",120);
            boolean overLimit=speedLimit>0&&s>speedLimit;
            int normalFill=overLimit?Color.RED:(s>=redAt?Color.RED:(s>=yellowAt?0xFFFFD400:Color.WHITE));
            int border=(s<=50f&&!overLimit)?0xFF00FF55:(overLimit?Color.WHITE:(s>=redAt?Color.WHITE:(s>=yellowAt?0xFFFF8A00:0xFF101010)));
            float digitWidth=numberHeight*.42f,gap=numberHeight*.10f,total=3f*digitWidth+2f*gap,left=cx-total/2f;
            boolean leading=true;
            for(int i=0;i<3;i++){
                char ch=digits.charAt(i);
                boolean gray=leading&&ch=='0';
                if(ch!='0') leading=false;
                int fill=gray?0xFF454A50:normalFill;
                drawSevenDigit(c,left+i*(digitWidth+gap)+digitWidth/2f,baseY,numberHeight,ch,fill,border);
            }
            // Information row: km/h on the right, recommended speed on the left.
            // Both live in a dedicated zone below the tachometer so neither can overlap
            // the tachometer or the trip-distance readout.
            float dailyY=land?h*.93f:h*.84f;
            // Dedicated lower information row: keep both blocks low, symmetric and
            // completely outside the tachometer. The trip distance remains centered
            // below this row, leaving a clean visual hierarchy in both orientations.
            float infoY=dailyY-dp(52);
            // Anchor the two information blocks exactly to the outer edges of the
            // three-digit tachometer. This keeps the layout balanced in both orientations.
            float leftCx=left;
            float rightCx=left+total;
            if(!land) infoY=dailyY-dp(22);
            // Small km/h label: intentionally reduced so the speed remains dominant.
            txt(c,"km/h",rightCx,infoY,Math.min(15f,Math.max(10f,numberHeight*.055f)),Color.WHITE,Paint.Align.RIGHT);
            if(speedLimit>0){String lt=Integer.toString(speedLimit);txtOutlined(c,"LIMITE "+lt,cx,baseY-numberHeight*.86f,Math.min(18f,Math.max(11f,numberHeight*.09f)),Color.RED,Color.WHITE,dp(2));}
            if(rec>0){
                txt(c,tr("CONSIGLIATA"),leftCx,infoY-dp(1),Math.min(12f,Math.max(8f,numberHeight*.06f)),yellow,Paint.Align.LEFT);
                txt(c,Math.round(rec)+" km/h",leftCx,infoY+dp(19),Math.min(18f,Math.max(11f,numberHeight*.085f)),yellow,Paint.Align.LEFT);
            }
            speedBounds.set(cx-total/2f-dp(14),baseY-numberHeight*.88f,cx+total/2f+dp(14),baseY+numberHeight*.72f);
        }

        void drawSevenDigit(Canvas c,float cx,float baseline,float h,char digit,int fill,int border){
            int mask; switch(digit){case '0':mask=0x3F;break;case '1':mask=0x06;break;case '2':mask=0x5B;break;case '3':mask=0x4F;break;case '4':mask=0x66;break;case '5':mask=0x6D;break;case '6':mask=0x7D;break;case '7':mask=0x07;break;case '8':mask=0x7F;break;case '9':mask=0x6F;break;default:mask=0;break;}
            float w=h*.50f, t=Math.max(dp(4.5f),h*.095f), x=cx-w/2f, top=baseline-h*.78f, bottom=baseline+h*.12f, mid=(top+bottom)/2f, inset=t*.8f;
            // Keep a small, uniform physical gap between horizontal and vertical segments.
            // The gap is measured from the outer edge of the stroke, so segments never touch
            // even when the display is rendered at large sizes.
            float gap=Math.max(dp(3f),t*.32f);
            float endGap=t*.50f+gap;
            float[][] seg={
                    {x+inset+endGap,top,x+w-inset-endGap,top},
                    {x+w-inset,top+endGap,x+w-inset,mid-endGap},
                    {x+w-inset,mid+endGap,x+w-inset,bottom-endGap},
                    {x+inset+endGap,bottom,x+w-inset-endGap,bottom},
                    {x+inset,mid+endGap,x+inset,bottom-endGap},
                    {x+inset,top+endGap,x+inset,mid-endGap},
                    {x+inset+endGap,mid,x+w-inset-endGap,mid}
            };
            for(int i=0;i<7;i++)if((mask&(1<<i))!=0){
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeCap(Paint.Cap.ROUND);
                stroke.setStrokeWidth(t+dp(2));
                stroke.setColor(border);
                c.drawLine(seg[i][0],seg[i][1],seg[i][2],seg[i][3],stroke);
                stroke.setStrokeWidth(t);
                stroke.setColor(fill);
                c.drawLine(seg[i][0],seg[i][1],seg[i][2],seg[i][3],stroke);
            }
        }

        void txtOutlined(Canvas c,String text,float x,float y,float size,int fill,int outline,float ow){p.setTypeface(TypefaceCompat.bold());p.setTextSize(size*density);p.setTextAlign(Paint.Align.CENTER);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(ow);p.setColor(outline);c.drawText(text,x,y,p);p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawText(text,x,y,p);}

        void drawAltitude(Canvas c, float cx, float y, Location location, boolean land) {
            String altitude = (location != null && location.hasAltitude() &&
                    (location.getProvider() == null || (!"ip-approx".equals(location.getProvider()) && !"saved-network".equals(location.getProvider()))))
                    ? "ALT " + Math.round(location.getAltitude()) + " m s.l.m."
                    : "ALT -- m s.l.m.";
            float size = land ? 14f : 13f;
            // Yellow on black, bold typeface: readable in strong outdoor light.
            txt(c, altitude, cx, y, size, 0xFFFFD400, Paint.Align.CENTER);
        }

        void drawCenteredCurveGlyph(Canvas c, float cx, float cy, float sz, float sign, int color, int type) {
            // Each severity has its own geometry. Mirroring only the X coordinate keeps
            // left/right perfectly symmetric while making LIGHT/MEDIUM/TIGHT/HAIRPIN
            // visually distinct at a glance.
            Path inner = new Path();
            float ex, ey;
            if (type == 4) {
                float x1=sz*.30f, x2=sz*.34f, y0=sz*.28f, y1=sz*.02f, y2=-sz*.24f;
                inner.moveTo(cx-sign*x1, cy+y0);
                inner.cubicTo(cx-sign*sz*.05f, cy+y0, cx+sign*x2, cy+y0, cx+sign*x2, cy+y1);
                inner.cubicTo(cx+sign*x2, cy+y2, cx-sign*sz*.08f, cy-y2*.25f, cx-sign*sz*.16f, cy-y2);
                ex=cx-sign*sz*.16f; ey=cy-y2;
            } else if (type == 3) {
                float x0=sz*.30f;
                inner.moveTo(cx-sign*x0, cy+sz*.28f);
                inner.cubicTo(cx-sign*sz*.02f, cy+sz*.28f, cx+sign*sz*.34f, cy+sz*.14f, cx+sign*sz*.30f, cy-sz*.02f);
                inner.cubicTo(cx+sign*sz*.26f, cy-sz*.20f, cx+sign*sz*.08f, cy-sz*.30f, cx-sign*sz*.04f, cy-sz*.36f);
                ex=cx-sign*sz*.04f; ey=cy-sz*.36f;
            } else if (type == 2) {
                float x0=sz*.30f;
                inner.moveTo(cx-sign*x0, cy+sz*.28f);
                inner.cubicTo(cx-sign*sz*.06f, cy+sz*.28f, cx+sign*sz*.30f, cy+sz*.12f, cx+sign*sz*.30f, cy-sz*.05f);
                inner.cubicTo(cx+sign*sz*.30f, cy-sz*.20f, cx+sign*sz*.14f, cy-sz*.30f, cx+sign*sz*.02f, cy-sz*.36f);
                ex=cx+sign*sz*.02f; ey=cy-sz*.36f;
            } else {
                float x0=sz*.24f;
                inner.moveTo(cx-sign*x0, cy+sz*.25f);
                inner.cubicTo(cx-sign*sz*.08f, cy+sz*.25f, cx+sign*sz*.27f, cy+sz*.13f, cx+sign*sz*.27f, cy-sz*.04f);
                inner.cubicTo(cx+sign*sz*.27f, cy-sz*.20f, cx+sign*sz*.10f, cy-sz*.30f, cx+sign*sz*.02f, cy-sz*.35f);
                ex=cx+sign*sz*.02f; ey=cy-sz*.35f;
            }
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4),sz*.105f)); c.drawPath(inner,stroke);
            stroke.setColor(color); stroke.setStrokeWidth(Math.max(dp(2.5f),sz*.060f)); c.drawPath(inner,stroke);
            Path arrow=new Path();
            arrow.moveTo(ex-sign*sz*.10f,ey+sz*.015f); arrow.lineTo(ex,ey-sz*.075f); arrow.lineTo(ex+sign*sz*.10f,ey+sz*.015f);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(3.5f),sz*.075f)); c.drawPath(arrow,stroke);
            stroke.setColor(color); stroke.setStrokeWidth(Math.max(dp(2),sz*.045f)); c.drawPath(arrow,stroke);
            stroke.setStyle(Paint.Style.FILL);
        }

        void drawCurveSymbol(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) return;
            boolean left = q.dir < 0;
            int curveColor = q.type == 5 ? 0xFF55D6FF : (q.type == 1 ? 0xFF35D66F : q.type == 2 ? 0xFFFFD400 : 0xFFF04438);
            float sign = left ? 1f : -1f;

            if (q.type == 5) {
                float half = sz * .72f;
                RectF square = new RectF(cx-half, cy-half, cx+half, cy+half);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF07131A); c.drawRoundRect(square, dp(7), dp(7), p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
                stroke.setStrokeWidth(Math.max(dp(3), sz*.075f)); stroke.setColor(curveColor);
                c.drawRoundRect(square, dp(7), dp(7), stroke);
                float ringR = sz*.31f;
                stroke.setStrokeWidth(Math.max(dp(3), sz*.09f)); stroke.setStrokeCap(Paint.Cap.ROUND);
                c.drawCircle(cx,cy,ringR,stroke);
                // Gap the ring on the exit side and draw a centred directional arrow.
                float ax = cx + sign*ringR*.98f, ay = cy;
                Path arrow = new Path();
                arrow.moveTo(ax-sign*sz*.14f, ay-sz*.12f);
                arrow.lineTo(ax, ay);
                arrow.lineTo(ax-sign*sz*.14f, ay+sz*.12f);
                stroke.setStrokeWidth(Math.max(dp(3), sz*.075f)); c.drawPath(arrow,stroke);
                stroke.setStyle(Paint.Style.FILL);
            } else if (q.type == 1) {
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF07130B);
                c.drawCircle(cx, cy, sz * .70f, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor);
                stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawCircle(cx, cy, sz * .70f, stroke);
                drawCenteredCurveGlyph(c, cx, cy, sz, sign, curveColor, q.type);
            } else if (q.type == 2) {
                float half = sz * .70f;
                RectF square = new RectF(cx - half, cy - half, cx + half, cy + half);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF171300); c.drawRoundRect(square, dp(5), dp(5), p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor);
                stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawRoundRect(square, dp(5), dp(5), stroke);
                drawCenteredCurveGlyph(c, cx, cy, sz, sign, curveColor, q.type);
            } else {
                // Equilateral warning triangle: all three vertices are generated from
                // the same centre and radius, so the warning symbol can never drift sideways.
                float radius = sz * .78f;
                Path triangle = new Path();
                triangle.moveTo(cx, cy - radius);
                triangle.lineTo(cx - radius * .8660254f, cy + radius * .5f);
                triangle.lineTo(cx + radius * .8660254f, cy + radius * .5f);
                triangle.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF050608); c.drawPath(triangle, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
                stroke.setColor(yellow); stroke.setStrokeWidth(Math.max(dp(3), sz * .085f));
                c.drawPath(triangle, stroke);

                // The directional glyph is severity-specific and remains centred
                // inside the warning triangle.
                drawCenteredCurveGlyph(c, cx, cy, sz * .72f, sign, curveColor, q.type);

                // The exclamation marks are mirrored around the same centre line.
                float exclamationY = cy + sz * .28f;
                float exclamationSize = Math.max(26, sz / density * .40f);
                txt(c, "!", cx - sz * .43f, exclamationY, exclamationSize, Color.WHITE, Paint.Align.CENTER);
                txt(c, "!", cx + sz * .43f, exclamationY, exclamationSize, Color.WHITE, Paint.Align.CENTER);
            }
        }

        void drawCurve(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) {
                txt(c, "—", cx, cy + dp(12), Math.max(32, sz / density * .62f), 0xFF6B737B, Paint.Align.CENTER);
                txt(c, tr("NESSUNA CURVA RILEVATA"), cx, cy + sz * .82f,
                        Math.max(11, Math.min(15, sz / density * .13f)), 0xFF9AA3AD, Paint.Align.CENTER);
                return;
            }
            drawCurveSymbol(c, cx, cy, q, sz);
            int curveColor = q.type == 5 ? 0xFF55D6FF : q.type == 1 ? 0xFF35D66F : q.type == 2 ? 0xFFFFD400 : 0xFFF04438;
            txt(c, tr(q.label == null ? "CURVA" : q.label), cx, cy + sz * 1.02f,
                    Math.max(13, Math.min(21, sz / density * .18f)), curveColor, Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx, cy + sz * 1.24f,
                    Math.max(18, Math.min(29, sz / density * .23f)), yellow, Paint.Align.CENTER);
            txt(c, tr(q.dir < 0 ? "SINISTRA" : "DESTRA"), cx, cy + sz * 1.43f,
                    Math.max(10, Math.min(15, sz / density * .12f)), 0xFFE0E5EA, Paint.Align.CENTER);
        }

        RectF boundsForZoom(boolean expanded, boolean plus) {
            float zbtn = dp(expanded ? 48 : 36);
            if (plus) return new RectF(mapBounds.right-zbtn-dp(6), mapBounds.bottom-zbtn*2-dp(10), mapBounds.right-dp(6), mapBounds.bottom-zbtn-dp(10));
            return new RectF(mapBounds.right-zbtn-dp(6), mapBounds.bottom-zbtn-dp(6), mapBounds.right-dp(6), mapBounds.bottom-dp(6));
        }
        boolean mapZoomButton(RectF r,float x,float y){return r.contains(x,y);}

        void showSpeedSettings() {
            android.content.SharedPreferences prefs=getSharedPreferences("road_display",MODE_PRIVATE);
            final android.widget.LinearLayout box=new android.widget.LinearLayout(MainActivity.this); box.setOrientation(android.widget.LinearLayout.VERTICAL); box.setPadding((int)dp(20),(int)dp(8),(int)dp(20),0);
            final android.widget.EditText e1=new android.widget.EditText(MainActivity.this); e1.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e1.setHint("Giallo da km/h"); e1.setText(Integer.toString(prefs.getInt("speed_yellow",90)));
            final android.widget.EditText e2=new android.widget.EditText(MainActivity.this); e2.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e2.setHint("Rosso da km/h"); e2.setText(Integer.toString(prefs.getInt("speed_red",120)));
            box.addView(e1); box.addView(e2);
            new android.app.AlertDialog.Builder(MainActivity.this).setTitle("COLORI VELOCITÀ").setMessage("Imposta le soglie del display. Il limite stradale, quando disponibile, ha sempre priorità.").setView(box).setNegativeButton("ANNULLA",null).setPositiveButton("SALVA",(d,w)->{try{int y=Integer.parseInt(e1.getText().toString());int r=Integer.parseInt(e2.getText().toString());if(y<1)y=90;if(r<=y)r=y+1;if(r>250)r=250;prefs.edit().putInt("speed_yellow",y).putInt("speed_red",r).apply();invalidate();}catch(Exception ignored){}}).show();
        }

        void drawRadarAlert(Canvas c,float cx,float cy,boolean land){
            long left=radarAlertUntil-System.currentTimeMillis(); if(left<=0) return;
            boolean flash=((System.currentTimeMillis()/500L)&1L)==0L;
            if (flash) {
                float sz=land?dp(54):dp(50); Path t=new Path();t.moveTo(cx,cy-sz*.5f);t.lineTo(cx-sz*.5f,cy+sz*.4f);t.lineTo(cx+sz*.5f,cy+sz*.4f);t.close();p.setStyle(Paint.Style.FILL);p.setColor(Color.RED);c.drawPath(t,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(dp(2));stroke.setColor(Color.WHITE);c.drawPath(t,stroke);txt(c,"RADAR",cx,cy+dp(6),land?10:9,Color.WHITE,Paint.Align.CENTER);
            }
            postInvalidateDelayed(250);
        }

        double pendingMapLat=Double.NaN, pendingMapLon=Double.NaN;

        int expandedMapZoom(){return Math.max(15,Math.min(19,15+Math.round((mapZoom-.5f)*4f)));}

        float[] mapScreenPoint(double lat,double lon,RectF bounds){if(Double.isNaN(mapViewLat)||Double.isNaN(mapViewLon))return null;double world=256.0*(1<<expandedMapZoom());double s1=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,mapViewLat)))),cx=(mapViewLon+180.0)/360.0*world,cy=(.5-Math.log((1+s1)/(1-s1))/(4*Math.PI))*world;double s2=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,lat)))),px=(lon+180.0)/360.0*world,py=(.5-Math.log((1+s2)/(1-s2))/(4*Math.PI))*world,br=Math.toRadians(mapFrozenBearing),dx=px-cx,dy=py-cy,sx=dx*Math.cos(br)+dy*Math.sin(br),sy=-dx*Math.sin(br)+dy*Math.cos(br);return new float[]{bounds.centerX()+(float)sx,bounds.centerY()+(float)sy};}

        Location mapLocationFromScreen(float x,float y){if(Double.isNaN(mapViewLat)||Double.isNaN(mapViewLon))return engine.loc==null?null:new Location(engine.loc);double world=256.0*(1<<expandedMapZoom());double s=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,mapViewLat)))),cx=(mapViewLon+180.0)/360.0*world,cy=(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*world,sx=x-mapBounds.centerX(),sy=y-mapBounds.centerY(),br=Math.toRadians(mapFrozenBearing),dx=sx*Math.cos(br)-sy*Math.sin(br),dy=sx*Math.sin(br)+sy*Math.cos(br),px=cx+dx,py=cy+dy,lon=px/world*360.0-180.0,n=Math.PI-2.0*Math.PI*py/world;Location l=new Location("map-pick");l.setLatitude(Math.max(-85,Math.min(85,Math.toDegrees(Math.atan(Math.sinh(n))))));l.setLongitude(lon);return l;}

        Location mapCenterLocation(){if(!Double.isNaN(selectedMapLat)&&!Double.isNaN(selectedMapLon)){Location l=new Location("map-pick");l.setLatitude(selectedMapLat);l.setLongitude(selectedMapLon);return l;}if(!Double.isNaN(mapViewLat)&&!Double.isNaN(mapViewLon)){Location l=new Location("map-center");l.setLatitude(mapViewLat);l.setLongitude(mapViewLon);return l;}return engine.loc==null?null:new Location(engine.loc);}

        void reverseGeocodeSelectedMapPoint(final double lat, final double lon) {
            final int token = ++selectedMapGeocodeToken;
            selectedMapPlaceName = "";
            postInvalidate();
            new Thread(() -> {
                HttpURLConnection c = null;
                String name = "";
                try {
                    long now = System.currentTimeMillis();
                    long wait = 1000L - (now - lastNominatimGeocodeAt);
                    if (wait > 0) Thread.sleep(wait);
                    lastNominatimGeocodeAt = System.currentTimeMillis();
                    String urlText = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=" + lat + "&lon=" + lon + "&zoom=18&addressdetails=1&accept-language=it";
                    c = (HttpURLConnection)new URL(urlText).openConnection();
                    c.setConnectTimeout(6000); c.setReadTimeout(9000); c.setRequestMethod("GET");
                    c.setRequestProperty("Accept", "application/json");
                    c.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.22.20 (Android motorcycle display; map attribution visible)");
                    if (c.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        JSONObject root = new JSONObject(readConnection(c));
                        JSONObject a = root.optJSONObject("address");
                        if (a != null) {
                            String road = a.optString("road", "");
                            String hn = a.optString("house_number", "");
                            String locality = firstNonEmpty(a.optString("village", ""), a.optString("town", ""), a.optString("city", ""), a.optString("municipality", ""), a.optString("suburb", ""), a.optString("hamlet", ""));
                            String first = road.isEmpty() ? root.optString("name", "") : road + (hn.isEmpty() ? "" : " " + hn);
                            if (!first.isEmpty() && !locality.isEmpty()) name = first + ", " + locality; else if (!first.isEmpty()) name = first; else name = locality;
                        }
                        if (name.isEmpty()) name = root.optString("display_name", "");
                    }
                } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); }
                final String result = name;
                post(() -> { if (token == selectedMapGeocodeToken && !Double.isNaN(selectedMapLat) && Math.abs(selectedMapLat-lat)<1e-8 && Math.abs(selectedMapLon-lon)<1e-8) { selectedMapPlaceName = result; invalidate(); } });
            }, "map-reverse-geocode").start();
        }

        void clearSelectedMapPoint() {
            selectedMapLat = Double.NaN; selectedMapLon = Double.NaN; selectedMapPlaceName = ""; ++selectedMapGeocodeToken; invalidate();
        }

        void saveHomeLocation(Location l) {
            if(l==null)return;
            getSharedPreferences("road_display",MODE_PRIVATE).edit().putString(PREF_HOME_ADDRESS,String.format(Locale.US,"Posizione salvata %.6f, %.6f",l.getLatitude(),l.getLongitude())).putString(PREF_HOME_LAT,Double.toString(l.getLatitude())).putString(PREF_HOME_LON,Double.toString(l.getLongitude())).apply();
            android.widget.Toast.makeText(MainActivity.this,"Posizione CASA memorizzata",android.widget.Toast.LENGTH_SHORT).show();
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            final int action=e.getActionMasked(); final float x=e.getX(), y=e.getY();
            if(mapExpanded){
                if(action==MotionEvent.ACTION_DOWN){
                    downX=x; downY=y; movedMap=false; draggingMap=true; pinching=false;
                    downMapLat=mapViewLat; downMapLon=mapViewLon; return true;
                }
                if(action==MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount()>=2){
                    float dx=e.getX(0)-e.getX(1), dy=e.getY(0)-e.getY(1);
                    pinchStartDistance=(float)Math.hypot(dx,dy); pinchStartZoom=mapZoom; pinching=pinchStartDistance>2f; draggingMap=false; return true;
                }
                if(action==MotionEvent.ACTION_MOVE){
                    if(pinching && e.getPointerCount()>=2 && pinchStartDistance>2f){
                        float dx=e.getX(0)-e.getX(1), dy=e.getY(0)-e.getY(1), dist=(float)Math.hypot(dx,dy);
                        mapZoom=Math.max(.5f,Math.min(1.7f,pinchStartZoom*dist/pinchStartDistance)); invalidate(); return true;
                    }
                    if(draggingMap && e.getPointerCount()==1 && !Double.isNaN(downMapLat) && !Double.isNaN(downMapLon)){
                        float dx=x-downX, dy=y-downY;
                        if(Math.hypot(dx,dy)>dp(8)) movedMap=true;
                        if(movedMap){
                            int z=expandedMapZoom(); double world=256.0*(1<<z);
                            double s=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,downMapLat))));
                            double cx=(downMapLon+180.0)/360.0*world, cy=(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*world;
                            double br=Math.toRadians(mapFrozenBearing), mdx=dx*Math.cos(br)-dy*Math.sin(br), mdy=dx*Math.sin(br)+dy*Math.cos(br);
                            double px=cx-mdx, py=cy-mdy;
                            mapViewLon=px/world*360.0-180.0; double n=Math.PI-2.0*Math.PI*py/world;
                            mapViewLat=Math.max(-85,Math.min(85,Math.toDegrees(Math.atan(Math.sinh(n))))); mapUserPanned=true; postInvalidateOnAnimation();
                        }
                    }
                    return true;
                }
                if(action==MotionEvent.ACTION_POINTER_UP){ pinching=false; pinchStartDistance=0f; draggingMap=false; return true; }
                if(action==MotionEvent.ACTION_CANCEL || action==MotionEvent.ACTION_UP){
                    if(action==MotionEvent.ACTION_UP && !movedMap && !pinching){
                        if(mapCloseBounds.contains(x,y)){ mapExpanded=false; mapUserPanned=false; clearSelectedMapPoint(); }
                        else if(mapRecenterBounds.contains(x,y)){
                            if(engine.loc!=null){mapViewLat=engine.loc.getLatitude(); mapViewLon=engine.loc.getLongitude();}
                            mapFrozenBearing=hasMapBearing?mapBearing:0f; mapUserPanned=false; clearSelectedMapPoint();
                        } else if(mapSetDestBounds.contains(x,y)){
                            Location picked=mapCenterLocation(); if(picked!=null){pendingMapLat=picked.getLatitude();pendingMapLon=picked.getLongitude();showNavigationDialog(pendingMapLat,pendingMapLon);}
                        } else if(mapSetHomeBounds.contains(x,y)){ Location picked=mapCenterLocation(); if(picked!=null)saveHomeLocation(picked);
                        } else if(mapClearPointBounds.contains(x,y)){ clearSelectedMapPoint();
                        } else if(mapZoomButton(boundsForZoom(true,true),x,y)){ mapZoom=Math.min(1.7f,mapZoom+.2f);
                        } else if(mapZoomButton(boundsForZoom(true,false),x,y)){ mapZoom=Math.max(.5f,mapZoom-.2f);
                        } else {
                            Location picked=mapLocationFromScreen(x,y);
                            if(picked!=null){ selectedMapLat=picked.getLatitude(); selectedMapLon=picked.getLongitude(); selectedMapPlaceName=""; reverseGeocodeSelectedMapPoint(selectedMapLat,selectedMapLon); }
                        }
                        invalidate();
                    }
                    draggingMap=false; pinching=false; pinchStartDistance=0f; return true;
                }
                return true;
            }
            if(action==MotionEvent.ACTION_DOWN){downX=x;downY=y;return true;} if(action!=MotionEvent.ACTION_UP)return true;
            if(selectedTripId>0){
                if(action==MotionEvent.ACTION_DOWN){
                    tripDownX=x; tripDownY=y; draggingTripMap=tripMapBounds.contains(x,y); tripDownLat=tripMapCenterLat; tripDownLon=tripMapCenterLon; return true;
                }
                if(action==MotionEvent.ACTION_MOVE && draggingTripMap && tripMapBounds.contains(x,y) && !Double.isNaN(tripDownLat) && !Double.isNaN(tripDownLon)){
                    float dx=x-tripDownX, dy=y-tripDownY; if(Math.hypot(dx,dy)>dp(6)){
                        int z=Math.max(10,Math.min(18,tripMapZoom)); double world=256.0*(1L<<z);
                        double s0=Math.sin(Math.toRadians(Math.max(-85,Math.min(85,tripDownLat))));
                        double cxw=(tripDownLon+180.0)/360.0*world, cyw=(.5-Math.log((1+s0)/(1-s0))/(4*Math.PI))*world;
                        double px=cxw-dx, py=cyw-dy; tripMapCenterLon=px/world*360.0-180.0; double nn=Math.PI-2.0*Math.PI*py/world; tripMapCenterLat=Math.max(-85,Math.min(85,Math.toDegrees(Math.atan(Math.sinh(nn))))); tripMapUserPanned=true; invalidate();
                    }
                    return true;
                }
                if(action==MotionEvent.ACTION_UP){
                    if(tripMapZoomInBounds.contains(x,y)){tripMapZoomOffset=Math.min(4,tripMapZoomOffset+1);invalidate();}
                    else if(tripMapZoomOutBounds.contains(x,y)){tripMapZoomOffset=Math.max(-2,tripMapZoomOffset-1);invalidate();}
                    else if(tripDetailListBounds.contains(x,y)){selectedTripId=-1;selectedTripSummary=null;selectedTripPoints.clear();tripsScreen=true;invalidate();}
                    else if(tripDetailHomeBounds.contains(x,y)){selectedTripId=-1;selectedTripSummary=null;selectedTripPoints.clear();tripsScreen=false;invalidate();}
                    else if(tripDetailDeleteBounds.contains(x,y)) deleteSelectedTrip();
                }
                draggingTripMap=false; return true;
            }
            if(tripDayScreen){
                if(tripsCloseBounds.contains(x,y)){tripDayScreen=false;selectedTripDayKey="";tripsScroll=0f;invalidate();}
                else if(Math.abs(y-downY)>dp(8)){tripsScroll=Math.max(0f,tripsScroll+(downY-y));invalidate();}
                else if(action==MotionEvent.ACTION_UP){
                    java.util.List<TripDb.TripSummary> all=tripDb.listTrips(500); java.util.ArrayList<TripDb.TripSummary> day=new java.util.ArrayList<>();
                    for(TripDb.TripSummary t:all) if(tripDayKey(t.startTime).equals(selectedTripDayKey)) day.add(t);
                    float top=tripRecording?dp(142):dp(96), rowH=Math.max(dp(76),Math.min(dp(92),getHeight()*.10f));
                    int idx=(int)((y-top+tripsScroll)/rowH); if(idx>=0&&idx<day.size()&&y>=top){openTripDetail(day.get(idx).id);}
                }
                return true;
            }
            if(tripsScreen){
                if(tripsCloseBounds.contains(x,y)){tripsScreen=false;invalidate();}
                else if(Math.abs(y-downY)>dp(8)){tripsScroll=Math.max(0f,tripsScroll+(downY-y));invalidate();}
                else if(action==MotionEvent.ACTION_UP){
                    java.util.List<TripDb.TripSummary> list=tripDb.listTrips(500); java.util.LinkedHashMap<String,java.util.ArrayList<TripDb.TripSummary>> groups=groupTripsByDay(list); java.util.ArrayList<String> keys=new java.util.ArrayList<>(groups.keySet());
                    float top=tripRecording?dp(146):dp(100), rowH=Math.max(dp(82),Math.min(dp(98),getHeight()*.11f));
                    int idx=(int)((y-top+tripsScroll)/rowH); if(idx>=0&&idx<keys.size()&&y>=top){openTripDay(keys.get(idx));}
                }
                return true;
            }
            if(mapBounds.contains(x,y)){
                if(mapZoomButton(boundsForZoom(false,true),x,y)){mapZoomCompact=Math.min(1.5f,mapZoomCompact+.2f);invalidate();return true;}
                if(mapZoomButton(boundsForZoom(false,false),x,y)){mapZoomCompact=Math.max(.8f,mapZoomCompact-.2f);invalidate();return true;}
                mapExpanded=true; mapUserPanned=false; mapFrozenBearing=hasMapBearing?mapBearing:0f;
                if(engine.loc!=null){mapViewLat=engine.loc.getLatitude();mapViewLon=engine.loc.getLongitude();}
                clearSelectedMapPoint(); invalidate(); return true;
            }
            if(speedBounds.contains(x,y)){showSpeedSettings();return true;} if(navButtonBounds.contains(x,y)){showNavigationDialog();return true;} if(exitButtonBounds.contains(x,y)){showExitConfirmation();return true;}
            if(weatherButtonBounds.contains(x,y)){if(engine.loc!=null&&LocationManager.GPS_PROVIDER.equals(engine.loc.getProvider())&&engine.loc.hasAccuracy()&&engine.loc.getAccuracy()<=50f)maybeUpdateWeather(engine.loc,true);loadDestinationWeather();showWeatherPopup();return true;}
            if(tripsButtonBounds.contains(x,y)){tripsScreen=true;tripsScroll=0f;invalidate();return true;} return true;
        }


    }

    // Keeps typography consistent without depending on downloaded fonts.
    static class TypefaceCompat {
        static android.graphics.Typeface bold() { return android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); }
    }
}
