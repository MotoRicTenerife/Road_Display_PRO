package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    static final int REQ_LOC = 42;
    RideView view;
    LocationManager lm;
    LocationListener listener;
    RoadDb db;
    RoadEngine engine;
    ToneGenerator tone;
    boolean audio = true;                 // Audio is enabled from launch; no activation overlay.
    boolean demo = false;
    volatile boolean downloadingRoads = false;
    volatile boolean roadDownloadAttempted = false;
    int satellitesVisible = 0;
    int satellitesUsed = 0;
    GnssStatus.Callback gnssCallback;
    long lastOnline = 0;
    Location previousMapLocation;
    double lastRoadDownloadLat = Double.NaN, lastRoadDownloadLon = Double.NaN;
    float mapBearing = 0f;
    boolean hasMapBearing = false;
    volatile long lastWeatherAt = 0L;
    volatile double lastWeatherLat = Double.NaN, lastWeatherLon = Double.NaN;
    volatile boolean weatherLoading = false;
    volatile String weatherSummary = "METEO IN ATTESA";
    volatile String weatherDetail = "";
    volatile boolean weatherAdverse = false;
    volatile boolean showWeatherDetails = false;
    volatile boolean approximateLocation = false;
    volatile boolean ipFallbackStarted = false;
    volatile String roadDataStatus = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Prioritise legibility in sunlight while ROAD DISPLAY PRO is in the foreground.
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL;
        getWindow().setAttributes(lp);
        immersive();
        db = new RoadDb(this);
        engine = new RoadEngine(db);
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        view = new RideView(this);
        setContentView(view);
        requestLocation();
    }

    void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        startGps();
    }

    void startGps() {
        if (lm != null) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) { processLocation(l); }
            @Override public void onProviderEnabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onProviderDisabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onStatusChanged(String p, int s, Bundle e) { if (view != null) view.invalidate(); }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = 0, used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) {
                        if (status.usedInFix(i)) used++;
                        visible++;
                    }
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (view != null) view.invalidate();
                }
            };
            try { lm.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper())); }
            catch (Exception ignored) { }
        }
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 250, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 15000, 500, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }

        // Use a recent system last-known position immediately, even before a fresh GPS fix arrives.
        Location best = null;
        String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String provider : providers) {
            try {
                Location candidate = lm.getLastKnownLocation(provider);
                if (candidate != null && (best == null ||
                        (candidate.hasAccuracy() && (!best.hasAccuracy() || candidate.getAccuracy() < best.getAccuracy())) ||
                        candidate.getTime() > best.getTime() + 120000L)) best = candidate;
            } catch (SecurityException ignored) { }
            catch (Exception ignored) { }
        }
        if (best != null) processLocation(best);
        else {
            Location saved = loadSavedLocation();
            if (saved != null) processLocation(saved);
            if (engine.loc == null) startIpLocationFallback();
        }
    }

    void processLocation(Location l) {
        if (l == null) return;
        boolean accurateGps = LocationManager.GPS_PROVIDER.equals(l.getProvider()) && l.hasAccuracy() && l.getAccuracy() <= 50f;
        approximateLocation = !accurateGps;
        updateMapBearing(l);
        if (accurateGps) {
            boolean warn = engine.update(l);
            if (warn) {
                if (engine.current.type == 4) beep(2, true);
                else beep(engine.current.type, false);
            }
        } else {
            // Approximate/network locations are for map loading only, never curve or speed advice.
            engine.loc = new Location(l);
            engine.current = new Curve();
            engine.noRoad = true;
            engine.reloadRoads(l);
        }
        if (!"ip-approx".equals(l.getProvider())) saveLocation(l);
        if (view != null) view.invalidate();
        long now = System.currentTimeMillis();
        boolean firstRoadLoad = !roadDownloadAttempted;
        boolean movedFar = !Double.isNaN(lastRoadDownloadLat) &&
                distanceMeters(lastRoadDownloadLat, lastRoadDownloadLon, l.getLatitude(), l.getLongitude()) >= 8000.0;
        boolean retryFailed = roadDownloadAttempted && (engine.mapWays == null || engine.mapWays.isEmpty()) && now - lastOnline >= 120000L;
        boolean cacheExpired = now - lastOnline >= 6L * 60L * 60L * 1000L;
        // A coarse or network-derived fix is still enough to fetch/display a regional map.
        if (!downloadingRoads && (firstRoadLoad || movedFar || retryFailed || cacheExpired)) {
            lastOnline = now;
            lastRoadDownloadLat = l.getLatitude(); lastRoadDownloadLon = l.getLongitude();
            downloadingRoads = true;
            roadDownloadAttempted = true;
            roadDataStatus = tr("SCARICO STRADE…");
            Location requestLocation = new Location(l);
            new Thread(() -> {
                boolean ok = false;
                try {
                    ok = engine.fetchOnline(requestLocation);
                    engine.reloadRoads(requestLocation);
                    roadDataStatus = ok || (engine.mapWays != null && !engine.mapWays.isEmpty())
                            ? "" : tr("DATI STRADALI NON DISPONIBILI");
                } finally {
                    downloadingRoads = false;
                    if (view != null) view.postInvalidate();
                }
            }, "road-data-download").start();
        }
        if (accurateGps) maybeUpdateWeather(l, false);
    }

    void saveLocation(Location l) {
        try {
            getSharedPreferences("road_display", MODE_PRIVATE).edit()
                    .putString("last_lat", Double.toString(l.getLatitude()))
                    .putString("last_lon", Double.toString(l.getLongitude()))
                    .putLong("last_time", System.currentTimeMillis()).apply();
        } catch (Exception ignored) { }
    }

    Location loadSavedLocation() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
            String lat = prefs.getString("last_lat", null), lon = prefs.getString("last_lon", null);
            if (lat == null || lon == null) return null;
            Location saved = new Location("saved-network");
            saved.setLatitude(Double.parseDouble(lat)); saved.setLongitude(Double.parseDouble(lon));
            saved.setAccuracy(5000f); saved.setTime(prefs.getLong("last_time", System.currentTimeMillis()));
            return saved;
        } catch (Exception ignored) { return null; }
    }

    void startIpLocationFallback() {
        if (ipFallbackStarted) return;
        ipFallbackStarted = true;
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL("https://ipwho.is/").openConnection();
                connection.setConnectTimeout(7000); connection.setReadTimeout(9000);
                connection.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.4.0 Android");
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) return;
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject json = new JSONObject(body.toString());
                if (!json.optBoolean("success", false)) return;
                double lat = json.optDouble("latitude", Double.NaN), lon = json.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
                runOnUiThread(() -> {
                    if (engine.loc != null) return; // A real system location arrived while IP lookup was running.
                    Location approximate = new Location("ip-approx");
                    approximate.setLatitude(lat); approximate.setLongitude(lon); approximate.setAccuracy(15000f);
                    approximate.setTime(System.currentTimeMillis());
                    processLocation(approximate);
                });
            } catch (Exception ignored) {
                roadDataStatus = tr("DATI STRADALI NON DISPONIBILI");
                if (view != null) view.postInvalidate();
            } finally { if (connection != null) connection.disconnect(); }
        }, "ip-location-fallback").start();
    }

    String tr(String it) {
        String lang = Locale.getDefault().getLanguage();
        if ("it".equals(lang) || lang == null) return it;
        String es = "es".equals(lang) ? "es" : "en";
        String[][] rows = {
            {"GPS IN RICERCA","GPS BUSCANDO","GPS SEARCHING"}, {"GPS DEBOLE","GPS DÉBIL","WEAK GPS"},
            {"GPS OK","GPS OK","GPS OK"}, {"DATI STRADALI IN ATTESA","ESPERANDO DATOS DE CARRETERA","WAITING FOR ROAD DATA"},
            {"DATI STRADALI NON DISPONIBILI","DATOS DE CARRETERA NO DISPONIBLES","ROAD DATA UNAVAILABLE"},
            {"SCARICO STRADE…","DESCARGANDO CARRETERAS…","DOWNLOADING ROADS…"},
            {"DOWNLOAD DATI STRADALI…","DESCARGANDO DATOS…","DOWNLOADING ROAD DATA…"},
            {"STRADE IN ATTESA","ESPERANDO CARRETERAS","WAITING FOR ROADS"}, {"DIREZIONE IN ATTESA","ESPERANDO DIRECCIÓN","WAITING FOR HEADING"},
            {"NESSUNA CURVA RILEVATA","NO SE DETECTA CURVA","NO CURVE DETECTED"}, {"LEGGERA","SUAVE","MILD"},
            {"MEDIA","MEDIA","MEDIUM"}, {"STRETTA","CERRADA","SHARP"}, {"TORNANTE","HORQUILLA","HAIRPIN"},
            {"SINISTRA","IZQUIERDA","LEFT"}, {"DESTRA","DERECHA","RIGHT"}, {"CONSIGLIATA","RECOMENDADA","RECOMMENDED"},
            {"VELOCITÀ","VELOCIDAD","SPEED"}, {"DISTANZA","DISTANCIA","DISTANCE"}, {"PENDENZA","PENDIENTE","GRADE"},
            {"SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA","SIMULACIÓN: NO USAR COMO INDICACIÓN DE SEGURIDAD","SIMULATION: NOT A SAFETY RECOMMENDATION"},
            {"AUDIO ON","AUDIO ACTIVADO","AUDIO ON"}, {"METEO IN ATTESA","METEO PENDIENTE","WEATHER PENDING"},
            {"METEO NON DISPONIBILE","METEO NO DISPONIBLE","WEATHER UNAVAILABLE"}, {"SERENO","DESPEJADO","CLEAR"},
            {"NUVOLOSO","NUBLADO","CLOUDY"}, {"NEBBIA","NIEBLA","FOG"}, {"PIOVIGGINE","LLOVIZNA","DRIZZLE"},
            {"PIOVIGGINE GELATA","LLUVIA ENGELANTE","FREEZING DRIZZLE"}, {"PIOGGIA","LLUVIA","RAIN"},
            {"PIOGGIA GELATA","LLUVIA ENGELANTE","FREEZING RAIN"}, {"NEVE","NIEVE","SNOW"}, {"ROVESCI","CHUBASCOS","SHOWERS"},
            {"ROVESCI DI NEVE","CHUBASCOS DE NIEVE","SNOW SHOWERS"}, {"TEMPORALE","TORMENTA","THUNDERSTORM"},
            {"ATTENZIONE METEO","ALERTA METEOROLÓGICA","WEATHER ALERT"}, {"MAPPA · RAGGIO 500 m","MAPA · RADIO 500 m","MAP · 500 m RADIUS"},
            {"MAPPA · RAGGIO 500 m · TRASCINA PER SCORRERE","MAPA · RADIO 500 m · ARRASTRA PARA MOVER","MAP · 500 m RADIUS · DRAG TO PAN"},
            {"CHIUDI ✕","CERRAR ✕","CLOSE ✕"}, {"← RIDE","← CONDUCCIÓN","← RIDE"}, {"METEO ↻","METEO ↻","WEATHER ↻"},
            {"METEO…","METEO…","WEATHER…"}, {"ATTIVA AUDIO","ACTIVAR AUDIO","ENABLE AUDIO"},
            {"MAPPA IN ATTESA","MAPA PENDIENTE","MAP WAITING"},
            {"POSIZIONE APPROSSIMATIVA","POSICIÓN APROXIMADA","APPROXIMATE LOCATION"},
            {"POSIZIONE RETE","POSICIÓN DE RED","NETWORK LOCATION"}
        };
        for (String[] row : rows) if (row[0].equals(it)) return row["es".equals(es) ? 1 : 2];
        return it;
    }

    void maybeUpdateWeather(Location location, boolean manual) {
        if (location == null || weatherLoading) return;
        long now = System.currentTimeMillis();
        boolean timeDue = lastWeatherAt == 0L || now - lastWeatherAt >= 30L * 60L * 1000L;
        boolean distanceDue = !Double.isNaN(lastWeatherLat) &&
                distanceMeters(lastWeatherLat, lastWeatherLon, location.getLatitude(), location.getLongitude()) >= 15000.0;
        if (!manual && !timeDue && !distanceDue) return;
        weatherLoading = true;
        Location at = new Location(location);
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String urlText = "https://api.open-meteo.com/v1/forecast?latitude=" + at.getLatitude()
                        + "&longitude=" + at.getLongitude()
                        + "&current=temperature_2m,apparent_temperature,precipitation,rain,showers,weather_code,wind_speed_10m,wind_gusts_10m"
                        + "&timezone=auto";
                connection = (HttpURLConnection) new URL(urlText).openConnection();
                connection.setConnectTimeout(10000); connection.setReadTimeout(15000);
                connection.setRequestMethod("GET");
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) throw new IllegalStateException("HTTP " + connection.getResponseCode());
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject root = new JSONObject(body.toString()).getJSONObject("current");
                int code = root.optInt("weather_code", -1);
                double temp = root.optDouble("temperature_2m", Double.NaN);
                double rain = root.optDouble("precipitation", 0.0);
                double wind = root.optDouble("wind_speed_10m", 0.0);
                double gust = root.optDouble("wind_gusts_10m", wind);
                String condition = weatherCodeLabel(code);
                weatherSummary = condition + (Double.isNaN(temp) ? "" : " · " + Math.round(temp) + "°C");
                String windLabel = "es".equals(Locale.getDefault().getLanguage()) ? "viento" : "en".equals(Locale.getDefault().getLanguage()) ? "wind" : "vento";
                String gustLabel = "es".equals(Locale.getDefault().getLanguage()) ? "rachas" : "en".equals(Locale.getDefault().getLanguage()) ? "gusts" : "raffiche";
                String rainLabel = "es".equals(Locale.getDefault().getLanguage()) ? "lluvia" : "en".equals(Locale.getDefault().getLanguage()) ? "rain" : "pioggia";
                weatherDetail = condition + " · " + Math.round(temp) + "°C · " + windLabel + " " + Math.round(wind) + " km/h · " + gustLabel + " " + Math.round(gust) + " km/h · " + rainLabel + " " + String.format(Locale.getDefault(), "%.1f", rain) + " mm";
                weatherAdverse = code >= 95 || code == 65 || code == 67 || code == 82 || code == 86 || rain >= 2.0 || gust >= 60.0;
                lastWeatherAt = System.currentTimeMillis();
                lastWeatherLat = at.getLatitude(); lastWeatherLon = at.getLongitude();
            } catch (Exception ex) {
                if (lastWeatherAt == 0L) weatherSummary = tr("METEO NON DISPONIBILE");
                weatherDetail = tr("METEO NON DISPONIBILE") + " · " + ("es".equals(Locale.getDefault().getLanguage()) ? "comprueba la conexión" : "en".equals(Locale.getDefault().getLanguage()) ? "check connection" : "verifica connessione");
                lastWeatherAt = System.currentTimeMillis();
            } finally {
                if (connection != null) connection.disconnect();
                weatherLoading = false;
                if (view != null) view.postInvalidate();
            }
        }, "weather-update").start();
    }

    double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }

    String weatherCodeLabel(int code) {
        switch (code) {
            case 0: return tr("SERENO");
            case 1: case 2: case 3: return tr("NUVOLOSO");
            case 45: case 48: return tr("NEBBIA");
            case 51: case 53: case 55: return tr("PIOVIGGINE");
            case 56: case 57: return tr("PIOVIGGINE GELATA");
            case 61: case 63: case 65: return tr("PIOGGIA");
            case 66: case 67: return tr("PIOGGIA GELATA");
            case 71: case 73: case 75: case 77: return tr("NEVE");
            case 80: case 81: case 82: return tr("ROVESCI");
            case 85: case 86: return tr("ROVESCI DI NEVE");
            case 95: case 96: case 99: return tr("TEMPORALE");
            default: return "METEO";
        }
    }

    void updateMapBearing(Location location) {
        if (location == null) return;
        if (location.hasBearing() && (!location.hasSpeed() || location.getSpeed() > 0.8f)) {
            mapBearing = location.getBearing();
            hasMapBearing = true;
        } else if (previousMapLocation != null) {
            float moved = previousMapLocation.distanceTo(location);
            if (moved >= 3.0f) {
                mapBearing = previousMapLocation.bearingTo(location);
                hasMapBearing = true;
            }
        }
        previousMapLocation = new Location(location);
    }

    void beep(int n, boolean longFirst) {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                if (longFirst) { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 520); Thread.sleep(180); }
                for (int i = 0; i < n; i++) { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(160); }
            } catch (Exception ignored) { }
        }, "curve-audio").start();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_LOC && g != null) {
            boolean granted = false;
            for (int grant : g) if (grant == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) startGps(); else if (view != null) view.invalidate();
        } else if (view != null) view.invalidate();
    }

    @Override public void onBackPressed() {
        if (view != null && view.mapExpanded) { view.mapExpanded = false; view.mapPanX = 0; view.mapPanY = 0; view.invalidate(); }
        else if (demo) { demo = false; if (view != null) view.invalidate(); }
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (lm != null) {
            if (listener != null) lm.removeUpdates(listener);
            if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
                try { lm.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
            }
        }
        if (tone != null) tone.release();
        if (db != null) db.close();
        super.onDestroy();
    }

    class RideView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Curve emptyCurve = new Curve();
        float demoSpeed = 82f, demoDist = 120f, demoGrade = 4f, demoRec = 65f;
        int demoType = 1, demoDir = 1;
        final RectF backRect = new RectF(), typeRect = new RectF(), dirRect = new RectF();
        final RectF mapBounds = new RectF(), demoButtonBounds = new RectF(), weatherButtonBounds = new RectF(), mapCloseBounds = new RectF();
        final ArrayList<SliderHit> sliderHits = new ArrayList<>();
        boolean mapExpanded = false, draggingMap = false, movedMap = false;
        float downX, downY, downPanX, downPanY, mapPanX = 0f, mapPanY = 0f;
        final int yellow = 0xFFFFD400, green = 0xFF00F080, blue = 0xFF42A5FF;
        final float density;

        RideView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            p.setTypeface(TypefaceCompat.bold());
            p.setTextAlign(Paint.Align.LEFT);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
        }

        float dp(float v) { return v * density; }
        float minDp() { return Math.min(getWidth(), getHeight()) / density; }
        void txt(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align) {
            p.setTextSize(Math.max(10f, sizeDp) * density);
            p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            c.drawText(s, x, y, p);
        }
        void panel(Canvas c, RectF r, int color, float radius) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(r, radius, radius, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.BLACK);
            if (mapExpanded) drawExpandedMap(c);
            else if (demo) drawDemo(c); else drawRide(c);
            postInvalidateDelayed(1000); // Keep the on-screen clock current.
        }

        String now() { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); }
        String gpsSummary() {
            Location l = engine.loc;
            if (l == null) return tr("GPS IN RICERCA");
            String acc = l.hasAccuracy() ? " ±" + Math.round(l.getAccuracy()) + "m" : "";
            if ("ip-approx".equals(l.getProvider()) || "saved-network".equals(l.getProvider())) return tr("POSIZIONE APPROSSIMATIVA") + acc;
            if (satellitesVisible > 0 && LocationManager.GPS_PROVIDER.equals(l.getProvider())) return "GPS " + satellitesUsed + "/" + satellitesVisible + " sat" + acc;
            if (!LocationManager.GPS_PROVIDER.equals(l.getProvider())) return tr("POSIZIONE RETE") + acc;
            return engine.gpsGood() ? tr("GPS OK") + acc : tr("GPS DEBOLE") + acc;
        }
        String roadSummary() {
            if (downloadingRoads) return tr("SCARICO STRADE…");
            if (engine.ways != null && !engine.ways.isEmpty()) return "STRADE " + engine.ways.size();
            if (!roadDownloadAttempted) return tr("DATI STRADALI IN ATTESA");
            return tr("DATI STRADALI NON DISPONIBILI");
        }
        void drawTopStatus(Canvas c) {
            int w = getWidth(); boolean land = w > getHeight();
            float barH = dp(land ? 34 : 50);
            panel(c, new RectF(0, 0, w, barH), 0xFF111820, 0);
            float fs = Math.max(10f, Math.min(15f, minDp() * .034f));
            int gpsColor = engine.gpsGood() ? green : 0xFFFFB84D;
            int roadColor = (downloadingRoads || (engine.mapWays != null && !engine.mapWays.isEmpty())) ? green : 0xFFFFB84D;
            if (land) {
                txt(c, now(), dp(10), dp(23), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w * .46f, dp(23), fs, gpsColor, Paint.Align.CENTER);
                String road = downloadingRoads ? tr("SCARICO STRADE…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "STRADE " + engine.mapWays.size() : tr("STRADE IN ATTESA"));
                txt(c, road, w - dp(10), dp(23), fs, roadColor, Paint.Align.RIGHT);
            } else {
                txt(c, now(), dp(10), dp(21), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w - dp(10), dp(21), fs, gpsColor, Paint.Align.RIGHT);
                String road = downloadingRoads ? tr("DOWNLOAD DATI STRADALI…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "DATI STRADALI OK · " + engine.mapWays.size() + " STRADE" : tr("DATI STRADALI IN ATTESA"));
                txt(c, road, w / 2f, dp(42), Math.max(9f, fs - 1), roadColor, Paint.Align.CENTER);
            }
        }

        void drawDemoInfo(Canvas c, boolean land) {
            float y = dp(48), h = dp(29), w = getWidth();
            panel(c, new RectF(0, y, w, y + h), 0xFF111820, 0);
            float fs = Math.max(9f, Math.min(12f, minDp() * .030f));
            txt(c, now(), dp(9), y + dp(19), fs, Color.WHITE, Paint.Align.LEFT);
            txt(c, gpsSummary(), w * .48f, y + dp(19), fs, engine.gpsGood() ? green : 0xFFFFB84D, Paint.Align.CENTER);
            String roads = downloadingRoads ? "DOWNLOAD…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : tr("STRADE IN ATTESA"));
            txt(c, roads, w - dp(9), y + dp(19), fs, (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D, Paint.Align.RIGHT);
        }

        void drawRide(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            Location l = engine.loc;
            Curve q = engine.current == null ? emptyCurve : engine.current;
            drawTopStatus(c);
            if (land) {
                float curveSize = Math.min(h * .235f, w * .12f);
                drawCurve(c, w * .19f, h * .34f, q, curveSize);
                float mapSize = Math.min(h * .44f, w * .22f);
                float mapCenterY = h * .51f;
                mapBounds.set(w * .50f - mapSize / 2f, mapCenterY - mapSize / 2f,
                        w * .50f + mapSize / 2f, mapCenterY + mapSize / 2f);
                drawRoadMap(c, mapBounds, l, false);
                drawSpeed(c, w * .82f, h * .43f, l == null ? 0 : speed(l), q.recommended, true);
                drawGrade(c, w * .82f, h * .90f, q.grade, true);
            } else {
                float curveSize = Math.min(w * .30f, h * .095f);
                drawCurve(c, w * .5f, h * .145f, q, curveSize);
                float mapSize = Math.min(w * .70f, h * .30f);
                float mapCenterY = h * .48f;
                mapBounds.set(w / 2f - mapSize / 2f, mapCenterY - mapSize / 2f,
                        w / 2f + mapSize / 2f, mapCenterY + mapSize / 2f);
                drawRoadMap(c, mapBounds, l, false);
                drawSpeed(c, w * .5f, h * .765f, l == null ? 0 : speed(l), q.recommended, false);
                drawGrade(c, w * .5f, h * .955f, q.grade, false);
            }
            float b = dp(10);
            float buttonTop = dp(land ? 39 : 54);
            demoButtonBounds.set(w - dp(72), buttonTop, w - b, buttonTop + dp(26));
            panel(c, demoButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(demoButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.STROKE);
            txt(c, "DEMO", demoButtonBounds.centerX(), demoButtonBounds.centerY() + dp(4), 10, yellow, Paint.Align.CENTER);
            weatherButtonBounds.set(dp(10), buttonTop, dp(78), buttonTop + dp(26));
            panel(c, weatherButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(weatherButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, weatherLoading ? tr("METEO…") : tr("METEO ↻"), weatherButtonBounds.centerX(), weatherButtonBounds.centerY() + dp(4), 10, 0xFF8ED7FF, Paint.Align.CENTER);
            // Weather information stays in the free strip between METEO and DEMO buttons.
            if (weatherAdverse || (showWeatherDetails && !weatherDetail.isEmpty())) {
                RectF weatherStrip = new RectF(weatherButtonBounds.right + dp(5), buttonTop,
                        Math.max(weatherButtonBounds.right + dp(12), demoButtonBounds.left - dp(5)), buttonTop + dp(26));
                panel(c, weatherStrip, weatherAdverse ? 0xFFE00020 : 0xFF17212B, dp(4));
                String bannerText = weatherAdverse ? tr("ATTENZIONE METEO") + " · " + weatherSummary : weatherDetail;
                float bannerSize = Math.max(7f, Math.min(10f, minDp() * .023f));
                p.setTextSize(bannerSize * density);
                float maxText = Math.max(dp(20), weatherStrip.width() - dp(10));
                while (p.measureText(bannerText) > maxText && bannerSize > 7f) {
                    bannerSize -= .5f; p.setTextSize(bannerSize * density);
                }
                while (p.measureText(bannerText) > maxText && bannerText.length() > 8) {
                    bannerText = bannerText.substring(0, bannerText.length() - 2) + "…";
                }
                txt(c, bannerText, weatherStrip.centerX(), weatherStrip.centerY() + dp(4), bannerSize, Color.WHITE, Paint.Align.CENTER);
            }
            txt(c, tr("AUDIO ON"), dp(12), h - dp(10), 11, green, Paint.Align.LEFT);
        }

        void drawRoadMap(Canvas c, RectF bounds, Location location, boolean expanded) {
            float radius = dp(7);
            panel(c, bounds, 0xFF080C10, radius);
            c.save();
            Path clip = new Path(); clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
            c.clipPath(clip);

            // High-contrast map window; default extent is about 1 km across (500 m radius).
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(0.6f)); p.setColor(0xFF202A33);
            for (int i = 1; i < 4; i++) {
                float x = bounds.left + bounds.width() * i / 4f;
                float y = bounds.top + bounds.height() * i / 4f;
                c.drawLine(x, bounds.top, x, bounds.bottom, p);
                c.drawLine(bounds.left, y, bounds.right, y, p);
            }

            if (location != null && engine.mapWays != null && !engine.mapWays.isEmpty()) {
                double lat0 = location.getLatitude(), lon0 = location.getLongitude();
                double cosLat = Math.cos(Math.toRadians(lat0));
                float bearing = hasMapBearing ? mapBearing : 0f;
                double theta = Math.toRadians(bearing);
                float scaleX = bounds.width() / (expanded ? 1000f : 1000f);
                float scaleY = bounds.height() / (expanded ? 1000f : 1000f);
                for (RoadWay way : engine.mapWays) {
                    if (way == null || way.pts == null || way.pts.size() < 2) continue;
                    Path road = new Path(); boolean started = false;
                    for (Geo point : way.pts) {
                        double east = (point.lon - lon0) * 111320.0 * cosLat;
                        double north = (point.lat - lat0) * 110540.0;
                        // Rotate the map so the current direction of travel points upward.
                        double eastRot = east * Math.cos(theta) - north * Math.sin(theta);
                        double northRot = east * Math.sin(theta) + north * Math.cos(theta);
                        float x = bounds.centerX() + (float)eastRot * scaleX + mapPanX;
                        float y = bounds.centerY() - (float)northRot * scaleY + mapPanY;
                        if (x < bounds.left - dp(10) || x > bounds.right + dp(10)
                                || y < bounds.top - dp(10) || y > bounds.bottom + dp(10)) {
                            started = false;
                            continue;
                        }
                        if (!started) { road.moveTo(x, y); started = true; }
                        else road.lineTo(x, y);
                    }
                    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
                    p.setStrokeWidth(dp(3.0f)); p.setColor(0xFF59636D); c.drawPath(road, p);
                    p.setStrokeWidth(dp(1.1f)); p.setColor(0xFFD5DDE4); c.drawPath(road, p);
                }
            } else {
                String status = downloadingRoads ? tr("SCARICO STRADE…") :
                        (location == null ? tr("GPS IN RICERCA") :
                        (roadDataStatus.isEmpty() ? tr("MAPPA IN ATTESA") : roadDataStatus));
                float statusSize = Math.max(8, Math.min(expanded ? 14 : 10, minDp() * .026f));
                txt(c, status, bounds.centerX(), bounds.bottom - dp(expanded ? 28 : 5),
                        statusSize, 0xFFB8C2CC, Paint.Align.CENTER);
            }

            // Fixed centered motorcycle marker inside a thin white frame. Kept compact so it never hides map status.
            float markerSize = Math.min(bounds.width(), bounds.height()) * (expanded ? 0.05f : 0.13f);
            float markerCx = bounds.centerX() + mapPanX, markerCy = bounds.centerY() + mapPanY;
            RectF marker = new RectF(markerCx - markerSize / 2f, markerCy - markerSize / 2f,
                    markerCx + markerSize / 2f, markerCy + markerSize / 2f);
            p.setStyle(Paint.Style.FILL); p.setColor(0xE6080A0D); c.drawRoundRect(marker, dp(3), dp(3), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(Color.WHITE); c.drawRoundRect(marker, dp(3), dp(3), p);
            Path bike = new Path();
            bike.moveTo(markerCx, marker.top + marker.height() * .18f);
            bike.lineTo(marker.left + marker.width() * .23f, marker.bottom - marker.height() * .20f);
            bike.lineTo(marker.centerX(), marker.bottom - marker.height() * .35f);
            bike.lineTo(marker.right - marker.width() * .23f, marker.bottom - marker.height() * .20f);
            bike.close(); p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFD400); c.drawPath(bike, p);
            c.restore();

            // Border and scale label remain outside the clipped map content.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(Color.WHITE);
            c.drawRoundRect(bounds, radius, radius, p); p.setStyle(Paint.Style.FILL);
            txt(c, expanded ? tr("MAPPA · RAGGIO 500 m · TRASCINA PER SCORRERE") : tr("MAPPA · RAGGIO 500 m"), bounds.centerX(), bounds.top + dp(expanded ? 24 : 15),
                    Math.max(9, Math.min(expanded ? 16 : 12, minDp() * .028f)), Color.WHITE, Paint.Align.CENTER);
            if (location != null && !hasMapBearing) {
                txt(c, tr("DIREZIONE IN ATTESA"), bounds.centerX(), bounds.bottom - dp(8),
                        Math.max(8, Math.min(10, minDp() * .024f)), 0xFFFFD400, Paint.Align.CENTER);
            }
        }

        void drawExpandedMap(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(0xFF05080B);
            RectF full = new RectF(dp(8), dp(8), w - dp(8), h - dp(8));
            drawRoadMap(c, full, engine.loc, true);
            mapCloseBounds.set(w - dp(76), dp(8), w - dp(8), dp(42));
            panel(c, mapCloseBounds, 0xFF202A33, dp(7));
            stroke.setColor(Color.WHITE); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            c.drawRoundRect(mapCloseBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, tr("CHIUDI ✕"), mapCloseBounds.centerX(), mapCloseBounds.centerY() + dp(5), 12, Color.WHITE, Paint.Align.CENTER);
        }

        float speed(Location l) { return l.hasSpeed() ? l.getSpeed() * 3.6f : 0f; }
        String fmtDist(float d) { return d < 1000 ? Math.round(d) + " m" : String.format(Locale.US, "%.1f km", d / 1000f); }

        void drawSpeed(Canvas c, float cx, float baseY, float s, float rec, boolean land) {
            float numberSize = Math.min(minDp() * (land ? .21f : .255f), land ? 78f : 116f);
            numberSize = Math.max(48f, numberSize);
            txt(c, String.valueOf(Math.round(s)), cx, baseY, numberSize, Color.WHITE, Paint.Align.CENTER);
            txt(c, "km/h", cx, baseY + dp(land ? 34 : 42), land ? 25 : 29, Color.WHITE, Paint.Align.CENTER);
            if (rec > 0) {
                txt(c, tr("CONSIGLIATA"), cx, baseY + dp(land ? 62 : 82), land ? 14 : 17, yellow, Paint.Align.CENTER);
                txt(c, Math.round(rec) + " km/h", cx, baseY + dp(land ? 88 : 116), land ? 23 : 29, yellow, Paint.Align.CENTER);
            }
        }

        void drawGrade(Canvas c, float cx, float y, float g, boolean land) {
            String s = (g > 0 ? "▲ +" : g < 0 ? "▼ " : "— ") + Math.round(g) + "%";
            txt(c, s, cx, y, land ? 20 : 23, g > 0 ? green : g < 0 ? blue : Color.WHITE, Paint.Align.CENTER);
        }

        void drawCurve(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) {
                txt(c, "—", cx, cy + dp(12), Math.max(32, sz / density * .62f), 0xFF6B737B, Paint.Align.CENTER);
                txt(c, tr("NESSUNA CURVA RILEVATA"), cx, cy + sz * .82f,
                        Math.max(11, Math.min(15, sz / density * .13f)), 0xFF9AA3AD, Paint.Align.CENTER);
                return;
            }
            boolean left = q.dir < 0;
            int curveColor = q.type == 1 ? 0xFF35D66F : q.type == 2 ? 0xFFFFD400 : 0xFFF04438;
            float sign = left ? -1f : 1f;
            float half = sz * .70f;
            if (q.type == 1) {
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF07130B);
                c.drawCircle(cx, cy, half, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawCircle(cx, cy, half, stroke);
            } else if (q.type == 2) {
                RectF square = new RectF(cx - half, cy - half, cx + half, cy + half);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF171300); c.drawRoundRect(square, dp(5), dp(5), p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawRoundRect(square, dp(5), dp(5), stroke);
            } else {
                Path triangle = new Path();
                triangle.moveTo(cx, cy - sz * .86f);
                triangle.lineTo(cx - sz * .88f, cy + sz * .68f);
                triangle.lineTo(cx + sz * .88f, cy + sz * .68f);
                triangle.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF050608); c.drawPath(triangle, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
                stroke.setColor(yellow); stroke.setStrokeWidth(Math.max(dp(3), sz * .085f)); c.drawPath(triangle, stroke);
                Path inner = new Path();
                inner.moveTo(cx, cy - sz * .76f);
                inner.lineTo(cx - sz * .76f, cy + sz * .61f);
                inner.lineTo(cx + sz * .76f, cy + sz * .61f);
                inner.close();
                stroke.setColor(0xFFF04438); stroke.setStrokeWidth(Math.max(dp(1.8f), sz * .028f)); c.drawPath(inner, stroke);
            }

            Path path = new Path();
            if (q.type == 4) {
                // Compact U-turn entirely inside the warning triangle.
                path.moveTo(cx + sign * sz * .27f, cy + sz * .37f);
                path.cubicTo(cx + sign * sz * .48f, cy + sz * .14f, cx + sign * sz * .42f, cy - sz * .22f, cx, cy - sz * .25f);
                path.cubicTo(cx - sign * sz * .42f, cy - sz * .26f, cx - sign * sz * .39f, cy + sz * .10f, cx - sign * sz * .17f, cy + sz * .15f);
            } else {
                path.moveTo(cx + sign * sz * .30f, cy + sz * .36f);
                path.cubicTo(cx + sign * sz * .08f, cy + sz * .26f, cx + sign * sz * .07f, cy - sz * .08f, cx + sign * sz * .31f, cy - sz * .20f);
                path.cubicTo(cx + sign * sz * .47f, cy - sz * .28f, cx + sign * sz * .47f, cy - sz * .39f, cx + sign * sz * .36f, cy - sz * .46f);
            }
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .16f)); c.drawPath(path, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .105f)); c.drawPath(path, stroke);
            // Arrowhead at the end of the path, kept inside each category's frame.
            float ex = cx + sign * sz * (q.type == 4 ? -.17f : .36f);
            float ey = cy - sz * (q.type == 4 ? -.15f : .46f);
            Path arrow = new Path();
            arrow.moveTo(ex - sign * sz * .15f, ey + sz * .03f);
            arrow.lineTo(ex, ey - sz * .10f);
            arrow.lineTo(ex + sign * sz * .15f, ey + sz * .03f);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .09f)); c.drawPath(arrow, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(2.5f), sz * .055f)); c.drawPath(arrow, stroke);

            if (q.type == 3) {
                // Two large warning marks flanking the red curve inside the triangle.
                txt(c, "!", cx - sz * .49f, cy + sz * .28f, Math.max(21, sz / density * .34f), Color.WHITE, Paint.Align.CENTER);
                txt(c, "!", cx + sz * .49f, cy + sz * .28f, Math.max(21, sz / density * .34f), Color.WHITE, Paint.Align.CENTER);
            } else if (q.type == 4) {
                txt(c, "!", cx, cy - sz * .40f, Math.max(22, sz / density * .32f), Color.WHITE, Paint.Align.CENTER);
            }
            txt(c, tr(q.label == null ? "CURVA" : q.label), cx, cy + sz * .91f,
                    Math.max(15, Math.min(24, sz / density * .20f)), curveColor, Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx, cy + sz * 1.14f,
                    Math.max(20, Math.min(32, sz / density * .25f)), yellow, Paint.Align.CENTER);
            txt(c, tr(left ? "SINISTRA" : "DESTRA"), cx, cy + sz * 1.34f,
                    Math.max(11, Math.min(16, sz / density * .13f)), 0xFFE0E5EA, Paint.Align.CENTER);
        }

        void drawDemo(Canvas c) {
            int w = getWidth(), h = getHeight(); boolean land = w > h;
            drawDemoHeader(c, land);
            Curve q = Curve.demo(demoType, demoDir, demoDist, demoRec, demoGrade);
            if (land) {
                drawDemoInfo(c, true);
                float sz = Math.min(h * .18f, w * .12f);
                drawCurve(c, w * .24f, h * .37f, q, sz);
                drawSpeed(c, w * .74f, h * .40f, demoSpeed, demoRec, true);
                drawGrade(c, w * .24f, h * .63f, demoGrade, true);
                drawDemoSliders(c, true, h * .68f);
            } else {
                drawDemoInfo(c, false);
                float sz = Math.min(w * .28f, h * .095f);
                drawCurve(c, w * .5f, h * .16f, q, sz);
                drawSpeed(c, w * .5f, h * .405f, demoSpeed, demoRec, false);
                drawGrade(c, w * .80f, h * .30f, demoGrade, false);
                drawDemoSliders(c, false, h * .60f);
            }
            txt(c, tr("SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA"), w / 2f, h - dp(5), 10, 0xFFB0B7BF, Paint.Align.CENTER);
        }

        void drawDemoHeader(Canvas c, boolean land) {
            float w = getWidth(), hh = dp(48), margin = dp(7);
            panel(c, new RectF(0, 0, w, hh), 0xFF141B22, 0);
            backRect.set(margin, dp(5), w * .27f, hh - dp(5));
            typeRect.set(w * .29f, dp(5), w * .64f, hh - dp(5));
            dirRect.set(w * .66f, dp(5), w - margin, hh - dp(5));
            panel(c, backRect, 0xFF414A54, dp(8)); panel(c, typeRect, 0xFF26313A, dp(8)); panel(c, dirRect, 0xFF26313A, dp(8));
            txt(c, tr("← RIDE"), backRect.centerX(), hh * .67f, Math.min(17, minDp() * .045f), Color.WHITE, Paint.Align.CENTER);
            String[] labels = {"", tr("LEGGERA"), tr("MEDIA"), tr("STRETTA"), tr("TORNANTE")};
            txt(c, labels[demoType], typeRect.centerX(), hh * .67f, Math.min(15, minDp() * .038f), yellow, Paint.Align.CENTER);
            txt(c, demoDir < 0 ? "← SINISTRA" : "DESTRA →", dirRect.centerX(), hh * .67f, Math.min(14, minDp() * .036f), Color.WHITE, Paint.Align.CENTER);
        }

        void drawDemoSliders(Canvas c, boolean land, float top) {
            sliderHits.clear();
            float w = getWidth(), h = getHeight(), bottom = h - dp(22);
            float gap = dp(5), left = dp(10), right = w - dp(10);
            String[] labels = {tr("VELOCITÀ"), tr("DISTANZA"), tr("PENDENZA"), tr("CONSIGLIATA")};
            float[] values = {demoSpeed, demoDist, demoGrade, demoRec};
            String[] valuesText = {Math.round(demoSpeed) + " km/h", Math.round(demoDist) + " m", (demoGrade > 0 ? "+" : "") + Math.round(demoGrade) + "%", Math.round(demoRec) + " km/h"};
            float[] mins = {0, 0, -12, 0}, maxs = {180, 500, 12, 180};
            if (land) {
                float colW = (w - left - dp(10) - gap) / 2f;
                float rowH = Math.max(dp(34), (bottom - top - gap) / 2f);
                for (int i = 0; i < 4; i++) {
                    int col = i % 2, row = i / 2;
                    float x1 = left + col * (colW + gap), y1 = top + row * (rowH + gap);
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(x1, y1, x1 + colW, Math.min(bottom, y1 + rowH)));
                }
            } else {
                float rowH = Math.max(dp(35), (bottom - top) / 4f);
                for (int i = 0; i < 4; i++) {
                    float y1 = top + i * rowH;
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(left, y1, right, Math.min(bottom, y1 + rowH - gap)));
                }
            }
        }

        void drawSlider(Canvas c, int id, String label, String valueText, float value, float min, float max, RectF area) {
            panel(c, area, 0xFF10161C, dp(6));
            float pad = dp(9), labelY = area.top + dp(17), trackY = area.bottom - dp(9);
            float fs = Math.max(11, Math.min(14, minDp() * .034f));
            txt(c, label, area.left + pad, labelY, fs, 0xFFE4EAF0, Paint.Align.LEFT);
            txt(c, valueText, area.right - pad, labelY, fs, yellow, Paint.Align.RIGHT);
            float tx1 = area.left + pad, tx2 = area.right - pad;
            p.setColor(0xFF3D4852); p.setStrokeWidth(dp(5)); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(tx1, trackY, tx2, trackY, p);
            float ratio = Math.max(0, Math.min(1, (value - min) / (max - min)));
            p.setColor(yellow); c.drawLine(tx1, trackY, tx1 + (tx2 - tx1) * ratio, trackY, p);
            p.setStyle(Paint.Style.FILL); c.drawCircle(tx1 + (tx2 - tx1) * ratio, trackY, dp(5), p);
            RectF hit = new RectF(area); sliderHits.add(new SliderHit(id, hit, tx1, tx2, min, max));
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = x; downY = y; downPanX = mapPanX; downPanY = mapPanY; movedMap = false;
                draggingMap = mapExpanded;
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (mapExpanded && draggingMap) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.abs(dx) + Math.abs(dy) > dp(5)) movedMap = true;
                    mapPanX = downPanX + dx; mapPanY = downPanY + dy;
                    invalidate();
                }
                return true;
            }
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            if (mapExpanded) {
                draggingMap = false;
                if (!movedMap && mapCloseBounds.contains(x, y)) { mapExpanded = false; mapPanX = 0; mapPanY = 0; invalidate(); }
                return true;
            }
            if (!demo) {
                if (weatherButtonBounds.contains(x, y)) {
                    showWeatherDetails = !showWeatherDetails;
                    if (engine.loc != null) maybeUpdateWeather(engine.loc, true);
                    invalidate(); return true;
                }
                if (mapBounds.contains(x, y)) { mapExpanded = true; mapPanX = 0; mapPanY = 0; invalidate(); return true; }
                if (demoButtonBounds.contains(x, y)) { demo = true; invalidate(); return true; }
                return true;
            }
            if (backRect.contains(x, y)) { demo = false; invalidate(); return true; }
            if (typeRect.contains(x, y)) { demoType = demoType % 4 + 1; invalidate(); return true; }
            if (dirRect.contains(x, y)) { demoDir = -demoDir; invalidate(); return true; }
            for (SliderHit hit : sliderHits) {
                if (hit.area.contains(x, y)) {
                    float ratio = Math.max(0f, Math.min(1f, (x - hit.x1) / Math.max(1f, hit.x2 - hit.x1)));
                    float value = hit.min + ratio * (hit.max - hit.min);
                    switch (hit.id) {
                        case 0: demoSpeed = value; break;
                        case 1: demoDist = value; break;
                        case 2: demoGrade = value; break;
                        case 3: demoRec = value; break;
                    }
                    invalidate(); return true;
                }
            }
            return true;
        }

        class SliderHit {
            int id; RectF area; float x1, x2, min, max;
            SliderHit(int i, RectF a, float xStart, float xEnd, float mn, float mx) { id=i; area=a; x1=xStart; x2=xEnd; min=mn; max=mx; }
        }
    }

    // Keeps typography consistent without depending on downloaded fonts.
    static class TypefaceCompat {
        static android.graphics.Typeface bold() { return android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); }
    }
}
