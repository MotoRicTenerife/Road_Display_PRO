package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int REQ_LOC = 42;
    RideView view;
    LocationManager lm;
    LocationListener listener;
    RoadDb db;
    RoadEngine engine;
    ToneGenerator tone;
    boolean audio = true;                 // Audio is enabled from launch; no activation overlay.
    boolean demo = false;
    volatile boolean downloadingRoads = false;
    volatile boolean roadDownloadAttempted = false;
    int satellitesVisible = 0;
    int satellitesUsed = 0;
    GnssStatus.Callback gnssCallback;
    long lastOnline = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Prioritise legibility in sunlight while ROAD DISPLAY PRO is in the foreground.
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL;
        getWindow().setAttributes(lp);
        immersive();
        db = new RoadDb(this);
        engine = new RoadEngine(db);
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        view = new RideView(this);
        setContentView(view);
        requestLocation();
    }

    void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        startGps();
    }

    void startGps() {
        if (lm != null) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                boolean warn = engine.update(l);
                if (warn) {
                    if (engine.current.type == 4) beep(2, true);
                    else beep(engine.current.type, false);
                }
                view.invalidate();
                if (l.getAccuracy() < 100f && System.currentTimeMillis() - lastOnline > 20000L && !downloadingRoads) {
                    lastOnline = System.currentTimeMillis();
                    downloadingRoads = true;
                    roadDownloadAttempted = true;
                    new Thread(() -> {
                        try { engine.fetchOnline(l); }
                        finally {
                            downloadingRoads = false;
                            if (view != null) view.postInvalidate();
                        }
                    }, "road-data-download").start();
                }
            }
            @Override public void onProviderEnabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onProviderDisabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onStatusChanged(String p, int s, Bundle e) { if (view != null) view.invalidate(); }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = 0, used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) {
                        if (status.usedInFix(i)) used++;
                        visible++;
                    }
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (view != null) view.invalidate();
                }
            };
            try { lm.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper())); }
            catch (Exception ignored) { }
        }
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
    }

    void beep(int n, boolean longFirst) {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                if (longFirst) { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 520); Thread.sleep(180); }
                for (int i = 0; i < n; i++) { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(160); }
            } catch (Exception ignored) { }
        }, "curve-audio").start();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_LOC && g != null && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startGps();
        else if (view != null) view.invalidate();
    }

    @Override public void onBackPressed() {
        if (demo) { demo = false; if (view != null) view.invalidate(); }
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (lm != null) {
            if (listener != null) lm.removeUpdates(listener);
            if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
                try { lm.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
            }
        }
        if (tone != null) tone.release();
        if (db != null) db.close();
        super.onDestroy();
    }

    class RideView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Curve emptyCurve = new Curve();
        float demoSpeed = 82f, demoDist = 120f, demoGrade = 4f, demoRec = 65f;
        int demoType = 1, demoDir = 1;
        final RectF backRect = new RectF(), typeRect = new RectF(), dirRect = new RectF();
        final ArrayList<SliderHit> sliderHits = new ArrayList<>();
        final int yellow = 0xFFFFD400, green = 0xFF00F080, blue = 0xFF42A5FF;
        final float density;

        RideView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            p.setTypeface(TypefaceCompat.bold());
            p.setTextAlign(Paint.Align.LEFT);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
        }

        float dp(float v) { return v * density; }
        float minDp() { return Math.min(getWidth(), getHeight()) / density; }
        void txt(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align) {
            p.setTextSize(Math.max(10f, sizeDp) * density);
            p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            c.drawText(s, x, y, p);
        }
        void panel(Canvas c, RectF r, int color, float radius) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(r, radius, radius, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.BLACK);
            if (demo) drawDemo(c); else drawRide(c);
            postInvalidateDelayed(1000); // Keep the on-screen clock current.
        }

        String now() { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); }
        String gpsSummary() {
            Location l = engine.loc;
            if (l == null) return "GPS IN RICERCA";
            String acc = l.hasAccuracy() ? " ±" + Math.round(l.getAccuracy()) + "m" : "";
            if (satellitesVisible > 0) return "GPS " + satellitesUsed + "/" + satellitesVisible + " sat" + acc;
            return engine.gpsGood() ? "GPS OK" + acc : "GPS DEBOLE" + acc;
        }
        String roadSummary() {
            if (downloadingRoads) return "SCARICO STRADE…";
            if (engine.ways != null && !engine.ways.isEmpty()) return "STRADE " + engine.ways.size();
            if (!roadDownloadAttempted) return "DATI STRADALI IN ATTESA";
            return "DATI STRADALI NON DISPONIBILI";
        }
        void drawTopStatus(Canvas c) {
            int w = getWidth(); boolean land = w > getHeight();
            float barH = dp(land ? 34 : 50);
            panel(c, new RectF(0, 0, w, barH), 0xFF111820, 0);
            float fs = Math.max(10f, Math.min(15f, minDp() * .034f));
            int gpsColor = engine.gpsGood() ? green : 0xFFFFB84D;
            int roadColor = (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D;
            if (land) {
                txt(c, now(), dp(10), dp(23), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w * .46f, dp(23), fs, gpsColor, Paint.Align.CENTER);
                String road = downloadingRoads ? "SCARICO STRADE…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : "STRADE IN ATTESA");
                txt(c, road, w - dp(10), dp(23), fs, roadColor, Paint.Align.RIGHT);
            } else {
                txt(c, now(), dp(10), dp(21), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w - dp(10), dp(21), fs, gpsColor, Paint.Align.RIGHT);
                String road = downloadingRoads ? "DOWNLOAD DATI STRADALI…" : (engine.ways != null && !engine.ways.isEmpty() ? "DATI STRADALI OK · " + engine.ways.size() + " STRADE" : "DATI STRADALI IN ATTESA");
                txt(c, road, w / 2f, dp(42), Math.max(9f, fs - 1), roadColor, Paint.Align.CENTER);
            }
        }

        void drawDemoInfo(Canvas c, boolean land) {
            float y = dp(48), h = dp(29), w = getWidth();
            panel(c, new RectF(0, y, w, y + h), 0xFF111820, 0);
            float fs = Math.max(9f, Math.min(12f, minDp() * .030f));
            txt(c, now(), dp(9), y + dp(19), fs, Color.WHITE, Paint.Align.LEFT);
            txt(c, gpsSummary(), w * .48f, y + dp(19), fs, engine.gpsGood() ? green : 0xFFFFB84D, Paint.Align.CENTER);
            String roads = downloadingRoads ? "DOWNLOAD…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : "STRADE IN ATTESA");
            txt(c, roads, w - dp(9), y + dp(19), fs, (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D, Paint.Align.RIGHT);
        }

        void drawRide(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            Location l = engine.loc;
            Curve q = engine.current == null ? emptyCurve : engine.current;
            drawTopStatus(c);
            if (land) {
                float curveSize = Math.min(h * .30f, w * .145f);
                float cx = w * .24f, cy = h * .43f;
                drawCurve(c, cx, cy, q, curveSize);
                drawSpeed(c, w * .73f, h * .46f, l == null ? 0 : speed(l), q.recommended, true);
                drawGrade(c, w * .73f, h * .89f, q.grade, true);
            } else {
                float curveSize = Math.min(w * .36f, h * .15f);
                drawCurve(c, w * .5f, h * .245f, q, curveSize);
                drawSpeed(c, w * .5f, h * .665f, l == null ? 0 : speed(l), q.recommended, false);
                drawGrade(c, w * .5f, h * .91f, q.grade, false);
            }
            float b = dp(12);
            panel(c, new RectF(w - dp(112), dp(40), w - b, dp(78)), 0xFF252A30, dp(12));
            txt(c, "DEMO", w - dp(62), dp(64), 17, yellow, Paint.Align.CENTER);
            txt(c, "AUDIO ON", dp(12), h - dp(12), 13, green, Paint.Align.LEFT);
        }

        float speed(Location l) { return l.hasSpeed() ? l.getSpeed() * 3.6f : 0f; }
        String fmtDist(float d) { return d < 1000 ? Math.round(d) + " m" : String.format(Locale.US, "%.1f km", d / 1000f); }

        void drawSpeed(Canvas c, float cx, float baseY, float s, float rec, boolean land) {
            float numberSize = Math.min(minDp() * (land ? .21f : .255f), land ? 78f : 116f);
            numberSize = Math.max(48f, numberSize);
            txt(c, String.valueOf(Math.round(s)), cx, baseY, numberSize, Color.WHITE, Paint.Align.CENTER);
            txt(c, "km/h", cx, baseY + dp(land ? 34 : 42), land ? 25 : 29, Color.WHITE, Paint.Align.CENTER);
            if (rec > 0) {
                txt(c, "CONSIGLIATA", cx, baseY + dp(land ? 62 : 82), land ? 14 : 17, yellow, Paint.Align.CENTER);
                txt(c, Math.round(rec) + " km/h", cx, baseY + dp(land ? 88 : 116), land ? 23 : 29, yellow, Paint.Align.CENTER);
            }
        }

        void drawGrade(Canvas c, float cx, float y, float g, boolean land) {
            String s = (g > 0 ? "▲ +" : g < 0 ? "▼ " : "— ") + Math.round(g) + "%";
            txt(c, s, cx, y, land ? 20 : 23, g > 0 ? green : g < 0 ? blue : Color.WHITE, Paint.Align.CENTER);
        }

        void drawCurve(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) {
                txt(c, "—", cx, cy + dp(16), Math.max(38, sz / density * .65f), 0xFF6B737B, Paint.Align.CENTER);
                txt(c, "NESSUNA CURVA RILEVATA", cx, cy + sz * .75f, 12, 0xFF9AA3AD, Paint.Align.CENTER);
                return;
            }
            boolean left = q.dir < 0;
            if (q.type >= 3) {
                Path t = new Path();
                t.moveTo(cx, cy - sz * .70f); t.lineTo(cx - sz * .68f, cy + sz * .50f); t.lineTo(cx + sz * .68f, cy + sz * .50f); t.close();
                p.setStyle(Paint.Style.FILL); p.setColor(yellow); c.drawPath(t, p);
                stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(3), sz * .055f)); c.drawPath(t, stroke);
            }
            Path path = new Path(); float sign = left ? -1f : 1f;
            path.moveTo(cx + sign * sz * .42f, cy + sz * .28f);
            path.cubicTo(cx + sign * sz * .12f, cy + sz * .28f, cx + sign * sz * .16f, cy - sz * .18f, cx + sign * sz * .40f, cy - sz * .28f);
            path.cubicTo(cx + sign * sz * .60f, cy - sz * .36f, cx + sign * sz * .64f, cy - sz * .58f, cx + sign * sz * .52f, cy - sz * .66f);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(sz * (q.type == 1 ? .17f : q.type == 2 ? .19f : .21f)); c.drawPath(path, stroke);
            stroke.setColor(q.type >= 3 ? Color.BLACK : Color.WHITE); stroke.setStrokeWidth(sz * (q.type == 1 ? .12f : q.type == 2 ? .14f : .15f)); c.drawPath(path, stroke);
            if (q.type < 3) { stroke.setColor(0xFFB8C0C8); stroke.setStrokeWidth(Math.max(dp(1), sz * .018f)); c.drawPath(path, stroke); }
            Path a = new Path(); float ax = cx + sign * sz * .12f, ay = cy + sz * .25f;
            a.moveTo(ax - sign * sz * .08f, ay); a.lineTo(ax + sign * sz * .10f, ay); a.lineTo(ax + sign * sz * .10f, ay - sz * .18f);
            a.lineTo(ax + sign * sz * .25f, ay - sz * .18f); a.lineTo(ax, ay - sz * .39f); a.lineTo(ax - sign * sz * .25f, ay - sz * .18f);
            a.lineTo(ax - sign * sz * .10f, ay - sz * .18f); a.close(); p.setColor(yellow); c.drawPath(a, p);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(2), sz * .06f)); c.drawPath(a, stroke);
            txt(c, q.label == null ? "CURVA" : q.label, cx, cy + sz * .73f, Math.max(17, Math.min(27, sz / density * .20f)), Color.WHITE, Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx, cy + sz * .98f, Math.max(22, Math.min(36, sz / density * .26f)), yellow, Paint.Align.CENTER);
            txt(c, left ? "SINISTRA" : "DESTRA", cx, cy + sz * 1.22f, Math.max(12, Math.min(18, sz / density * .14f)), 0xFFE0E5EA, Paint.Align.CENTER);
        }

        void drawDemo(Canvas c) {
            int w = getWidth(), h = getHeight(); boolean land = w > h;
            drawDemoHeader(c, land);
            Curve q = Curve.demo(demoType, demoDir, demoDist, demoRec, demoGrade);
            if (land) {
                drawDemoInfo(c, true);
                float sz = Math.min(h * .18f, w * .12f);
                drawCurve(c, w * .24f, h * .37f, q, sz);
                drawSpeed(c, w * .74f, h * .40f, demoSpeed, demoRec, true);
                drawGrade(c, w * .24f, h * .63f, demoGrade, true);
                drawDemoSliders(c, true, h * .68f);
            } else {
                drawDemoInfo(c, false);
                float sz = Math.min(w * .28f, h * .095f);
                drawCurve(c, w * .5f, h * .16f, q, sz);
                drawSpeed(c, w * .5f, h * .405f, demoSpeed, demoRec, false);
                drawGrade(c, w * .80f, h * .30f, demoGrade, false);
                drawDemoSliders(c, false, h * .60f);
            }
            txt(c, "SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA", w / 2f, h - dp(5), 10, 0xFFB0B7BF, Paint.Align.CENTER);
        }

        void drawDemoHeader(Canvas c, boolean land) {
            float w = getWidth(), hh = dp(48), margin = dp(7);
            panel(c, new RectF(0, 0, w, hh), 0xFF141B22, 0);
            backRect.set(margin, dp(5), w * .27f, hh - dp(5));
            typeRect.set(w * .29f, dp(5), w * .64f, hh - dp(5));
            dirRect.set(w * .66f, dp(5), w - margin, hh - dp(5));
            panel(c, backRect, 0xFF414A54, dp(8)); panel(c, typeRect, 0xFF26313A, dp(8)); panel(c, dirRect, 0xFF26313A, dp(8));
            txt(c, "← RIDE", backRect.centerX(), hh * .67f, Math.min(17, minDp() * .045f), Color.WHITE, Paint.Align.CENTER);
            String[] labels = {"", "LEGGERA", "MEDIA", "STRETTA", "TORNANTE"};
            txt(c, labels[demoType], typeRect.centerX(), hh * .67f, Math.min(15, minDp() * .038f), yellow, Paint.Align.CENTER);
            txt(c, demoDir < 0 ? "← SINISTRA" : "DESTRA →", dirRect.centerX(), hh * .67f, Math.min(14, minDp() * .036f), Color.WHITE, Paint.Align.CENTER);
        }

        void drawDemoSliders(Canvas c, boolean land, float top) {
            sliderHits.clear();
            float w = getWidth(), h = getHeight(), bottom = h - dp(22);
            float gap = dp(5), left = dp(10), right = w - dp(10);
            String[] labels = {"VELOCITÀ", "DISTANZA", "PENDENZA", "CONSIGLIATA"};
            float[] values = {demoSpeed, demoDist, demoGrade, demoRec};
            String[] valuesText = {Math.round(demoSpeed) + " km/h", Math.round(demoDist) + " m", (demoGrade > 0 ? "+" : "") + Math.round(demoGrade) + "%", Math.round(demoRec) + " km/h"};
            float[] mins = {0, 0, -12, 0}, maxs = {180, 500, 12, 180};
            if (land) {
                float colW = (w - left - dp(10) - gap) / 2f;
                float rowH = Math.max(dp(34), (bottom - top - gap) / 2f);
                for (int i = 0; i < 4; i++) {
                    int col = i % 2, row = i / 2;
                    float x1 = left + col * (colW + gap), y1 = top + row * (rowH + gap);
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(x1, y1, x1 + colW, Math.min(bottom, y1 + rowH)));
                }
            } else {
                float rowH = Math.max(dp(35), (bottom - top) / 4f);
                for (int i = 0; i < 4; i++) {
                    float y1 = top + i * rowH;
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(left, y1, right, Math.min(bottom, y1 + rowH - gap)));
                }
            }
        }

        void drawSlider(Canvas c, int id, String label, String valueText, float value, float min, float max, RectF area) {
            panel(c, area, 0xFF10161C, dp(6));
            float pad = dp(9), labelY = area.top + dp(17), trackY = area.bottom - dp(9);
            float fs = Math.max(11, Math.min(14, minDp() * .034f));
            txt(c, label, area.left + pad, labelY, fs, 0xFFE4EAF0, Paint.Align.LEFT);
            txt(c, valueText, area.right - pad, labelY, fs, yellow, Paint.Align.RIGHT);
            float tx1 = area.left + pad, tx2 = area.right - pad;
            p.setColor(0xFF3D4852); p.setStrokeWidth(dp(5)); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(tx1, trackY, tx2, trackY, p);
            float ratio = Math.max(0, Math.min(1, (value - min) / (max - min)));
            p.setColor(yellow); c.drawLine(tx1, trackY, tx1 + (tx2 - tx1) * ratio, trackY, p);
            p.setStyle(Paint.Style.FILL); c.drawCircle(tx1 + (tx2 - tx1) * ratio, trackY, dp(5), p);
            RectF hit = new RectF(area); sliderHits.add(new SliderHit(id, hit, tx1, tx2, min, max));
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            if (!demo) {
                if (x > getWidth() - dp(130) && y < dp(95)) { demo = true; invalidate(); return true; }
                return true;
            }
            if (backRect.contains(x, y)) { demo = false; invalidate(); return true; }
            if (typeRect.contains(x, y)) { demoType = demoType % 4 + 1; invalidate(); return true; }
            if (dirRect.contains(x, y)) { demoDir = -demoDir; invalidate(); return true; }
            for (SliderHit hit : sliderHits) {
                if (hit.area.contains(x, y)) {
                    float ratio = Math.max(0f, Math.min(1f, (x - hit.x1) / Math.max(1f, hit.x2 - hit.x1)));
                    float value = hit.min + ratio * (hit.max - hit.min);
                    switch (hit.id) {
                        case 0: demoSpeed = value; break;
                        case 1: demoDist = value; break;
                        case 2: demoGrade = value; break;
                        case 3: demoRec = value; break;
                    }
                    invalidate(); return true;
                }
            }
            return true;
        }

        class SliderHit {
            int id; RectF area; float x1, x2, min, max;
            SliderHit(int i, RectF a, float xStart, float xEnd, float mn, float mx) { id=i; area=a; x1=xStart; x2=xEnd; min=mn; max=mx; }
        }
    }

    // Keeps typography consistent without depending on downloaded fonts.
    static class TypefaceCompat {
        static android.graphics.Typeface bold() { return android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); }
    }
}
