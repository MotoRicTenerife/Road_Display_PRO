package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.location.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;

public class MainActivity extends Activity {
    static final int REQ_LOC=42;
    RideView view; LocationManager lm; LocationListener listener; RoadDb db; RoadEngine engine; ToneGenerator tone;
    boolean audio=false, demo=false; long lastOnline=0;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); immersive();
        db=new RoadDb(this); engine=new RoadEngine(db); tone=new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
        view=new RideView(this); setContentView(view); requestLocation();
    }
    void immersive(){ getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
    void requestLocation(){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOC);return;} startGps(); }
    void startGps(){ if(lm!=null)return; lm=(LocationManager)getSystemService(LOCATION_SERVICE); listener=new LocationListener(){public void onLocationChanged(Location l){ boolean warn=engine.update(l); if(warn){ if(engine.current.type==4) beep(2,true); else beep(engine.current.type,false); } view.invalidate(); if(!demo && l.getAccuracy()<80 && System.currentTimeMillis()-lastOnline>20000){ lastOnline=System.currentTimeMillis(); new Thread(()->engine.fetchOnline(l)).start(); }} public void onProviderEnabled(String p){view.invalidate();} public void onProviderDisabled(String p){view.invalidate();} public void onStatusChanged(String p,int s,Bundle e){}}; try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,1,listener,Looper.getMainLooper());}catch(Exception e){} }
    void beep(int n, boolean longFirst){ if(!audio)return; new Thread(()->{try{if(longFirst){tone.startTone(ToneGenerator.TONE_PROP_BEEP2,520);Thread.sleep(180);}for(int i=0;i<n;i++){tone.startTone(ToneGenerator.TONE_PROP_BEEP,120);Thread.sleep(130);}}catch(Exception e){}}).start(); }
    void enableAudio(){audio=true; view.invalidate();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_LOC)startGps();}
    @Override protected void onDestroy(){if(lm!=null)lm.removeUpdates(listener);tone.release();db.close();super.onDestroy();}

    class RideView extends View {
        Paint p=new Paint(3); Paint stroke=new Paint(3); Curve c=new Curve(); float demoSpeed=82, demoDist=120, demoGrade=4, demoRec=65; int demoType=1, demoDir=1; boolean demoArmed=true; RectF r=new RectF();
        RideView(Context x){super(x);p.setTypeface(Typeface.create("sans",Typeface.BOLD));stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);setBackgroundColor(Color.BLACK);}
        void txt(Canvas x,String s,float xx,float yy,float size,int col,Paint.Align a){p.setTextSize(size);p.setColor(col);p.setTextAlign(a);p.setStyle(Paint.Style.FILL);x.drawText(s,xx,yy,p);}
        @Override protected void onDraw(Canvas x){super.onDraw(x); if(demo)drawDemo(x); else drawRide(x);}
        void drawRide(Canvas x){int w=getWidth(),h=getHeight(); boolean land=w>h; Location l=engine.loc; Curve q=engine.current;
            if(!land){ drawCurve(x,w/2f,Math.min(h*.31f,w*.44f),q); txt(x,q.valid?q.label:"—",w/2,h*.50f,36,Color.WHITE,Paint.Align.CENTER); txt(x,q.valid?fmtDist(q.distance):"—",w/2,h*.56f,54,Color.WHITE,Paint.Align.CENTER); drawSpeed(x,w/2f,h*.78f,l==null?0:speed(l),q.recommended); drawGrade(x,w/2f,h*.91f,q.grade); drawStatus(x); }
            else { float mid=w*.50f; drawCurve(x,w*.25f,h*.43f, q); drawSpeed(x,w*.75f,h*.56f,l==null?0:speed(l),q.recommended); drawGrade(x,w*.75f,h*.83f,q.grade); drawStatus(x); }
            if(!audio){p.setColor(0xEE000000);x.drawRect(0,0,w,h,p);txt(x,"ATTIVA AUDIO",w/2,h*.46f,42,Color.YELLOW,Paint.Align.CENTER);txt(x,"Tocca lo schermo una volta",w/2,h*.54f,24,Color.WHITE,Paint.Align.CENTER);}
            else {txt(x,"AUDIO ON",12,28,16,0xFF77FF77,Paint.Align.LEFT);txt(x,"DEMO",w-90,28,16,Color.YELLOW,Paint.Align.CENTER);}
        }
        float speed(Location l){return l.hasSpeed()?l.getSpeed()*3.6f:0;}
        String fmtDist(float d){return d<1000?Math.round(d)+" m":String.format(Locale.US,"%.1f km",d/1000f);}
        void drawSpeed(Canvas x,float cx,float base,float s,float rec){txt(x,String.valueOf(Math.round(s)),cx,base,Math.min(getWidth(),getHeight())*.20f,Color.WHITE,Paint.Align.CENTER);txt(x,"km/h",cx,base+38,27,Color.WHITE,Paint.Align.CENTER);if(rec>0){txt(x,"CONSIGLIATA",cx,base+78,16,0xFFFFD400,Paint.Align.CENTER);txt(x,String.valueOf(Math.round(rec))+" km/h",cx,base+112,31,0xFFFFD400,Paint.Align.CENTER);} }
        void drawGrade(Canvas x,float cx,float y,float g){ if(g==0){txt(x,"— 0%",cx,y,22,Color.WHITE,Paint.Align.CENTER);return;} String s=(g>0?"▲ +":"▼ ")+Math.round(g)+"%"; txt(x,s,cx,y,24,g>0?0xFF66FF66:0xFF4DA6FF,Paint.Align.CENTER); }
        void drawStatus(Canvas x){int col=engine.gpsGood()?0xFF66FF66:0xFFFF4040;String s=engine.gpsGood()?"GPS OK":engine.loc==null?"GPS IN ATTESA":"GPS INSUFFICIENTE";txt(x,s,12,getHeight()-14,17,col,Paint.Align.LEFT); if(engine.noRoad)txt(x,"DATI STRADALI NON DISPONIBILI",getWidth()-12,getHeight()-14,17,Color.RED,Paint.Align.RIGHT);}
        void drawCurve(Canvas x,float cx,float cy,Curve q){float sz=Math.min(getWidth(),getHeight())*.34f; boolean left=q.dir<0; if(!q.valid){txt(x,"—",cx,cy+20,110,0xFF666666,Paint.Align.CENTER);return;} if(q.type>=3){p.setStyle(Paint.Style.FILL);p.setColor(Color.YELLOW);Path t=new Path();t.moveTo(cx,cy-sz*.55f);t.lineTo(cx-sz*.62f,cy+sz*.48f);t.lineTo(cx+sz*.62f,cy+sz*.48f);t.close();x.drawPath(t,p);stroke.setColor(Color.BLACK);stroke.setStrokeWidth(sz*.07f);x.drawPath(t,stroke);}
            Path path=new Path();float sign=left?-1:1;path.moveTo(cx+sign*sz*.42f,cy+sz*.28f);path.cubicTo(cx+sign*sz*.12f,cy+sz*.28f,cx+sign*sz*.16f,cy-sz*.18f,cx+sign*sz*.40f,cy-sz*.28f);path.cubicTo(cx+sign*sz*.60f,cy-sz*.36f,cx+sign*sz*.64f,cy-sz*.58f,cx+sign*sz*.52f,cy-sz*.66f);stroke.setColor(q.type>=3?Color.BLACK:Color.WHITE);stroke.setStrokeWidth(sz*(q.type==1?.045f:q.type==2?.065f:.085f));stroke.setStyle(Paint.Style.STROKE);x.drawPath(path,stroke);
            // professional arrow: black outline + yellow core, separated from road symbol
            Path a=new Path();float ax=cx+sign*sz*.12f, ay=cy+sz*.25f; a.moveTo(ax-sign*sz*.08f,ay);a.lineTo(ax+sign*sz*.10f,ay);a.lineTo(ax+sign*sz*.10f,ay-sz*.18f);a.lineTo(ax+sign*sz*.25f,ay-sz*.18f);a.lineTo(ax,ay-sz*.39f);a.lineTo(ax-sign*sz*.25f,ay-sz*.18f);a.lineTo(ax-sign*sz*.10f,ay-sz*.18f);a.close();stroke.setColor(Color.BLACK);stroke.setStrokeWidth(sz*.045f);stroke.setStyle(Paint.Style.STROKE);x.drawPath(a,stroke);p.setColor(Color.YELLOW);p.setStyle(Paint.Style.FILL);x.drawPath(a,p);
            txt(x,q.label,cx,cy+sz*.72f,26,Color.WHITE,Paint.Align.CENTER);txt(x,fmtDist(q.distance),cx,cy+sz*.90f,38,Color.WHITE,Paint.Align.CENTER);
        }
        void drawDemo(Canvas x){int w=getWidth(),h=getHeight();txt(x,"DEMO / SIMULATA",w/2,34,22,Color.YELLOW,Paint.Align.CENTER);Curve q=Curve.demo(demoType,demoDir,demoDist,demoRec,demoGrade);drawCurve(x,w/2f,h*.27f,q);drawSpeed(x,w/2f,h*.70f,demoSpeed,demoRec); drawGrade(x,w/2f,h*.86f,demoGrade);txt(x,"TIPO",20,h-145,17,Color.GRAY,Paint.Align.LEFT);String[] ts={"LEGGERA","MEDIA","STRETTA","TORNANTE"};txt(x,ts[demoType-1],20,h-115,25,Color.WHITE,Paint.Align.LEFT);txt(x,"DIREZIONE",220,h-145,17,Color.GRAY,Paint.Align.LEFT);txt(x,demoDir<0?"SINISTRA":"DESTRA",220,h-115,25,Color.WHITE,Paint.Align.LEFT);txt(x,"VELOCITÀ 0–180",20,h-245,14,Color.GRAY,Paint.Align.LEFT);txt(x,"DISTANZA 0–500 m",20,h-190,14,Color.GRAY,Paint.Align.LEFT);txt(x,"PENDENZA −12…+12%",20,h-135,14,Color.GRAY,Paint.Align.LEFT);txt(x,"CONSIGLIATA 0–180",20,h-80,14,Color.GRAY,Paint.Align.LEFT);txt(x,"Tocca qui per cambiare tipo/direzione",20,h-20,13,Color.GRAY,Paint.Align.LEFT);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float xx=e.getX(),yy=e.getY(); if(!audio){enableAudio();return true;} if(!demo && xx>getWidth()-150 && yy<70){demo=true;invalidate();return true;} if(demo){ if(yy<75){demoType=demoType%4+1;invalidate();return true;} if(yy<125){demoDir=-demoDir;invalidate();return true;} float left=30,right=getWidth()-30; if(yy>getHeight()-260&&yy<getHeight()-205){demoSpeed=180f*(xx-left)/(right-left);invalidate();return true;} if(yy>getHeight()-200&&yy<getHeight()-145){demoDist=500f*(xx-left)/(right-left);invalidate();return true;} if(yy>getHeight()-140&&yy<getHeight()-85){demoGrade=-12f+24f*(xx-left)/(right-left);invalidate();return true;} if(yy>getHeight()-80){demoRec=180f*(xx-left)/(right-left);invalidate();return true;} } return true;}
    }
}
