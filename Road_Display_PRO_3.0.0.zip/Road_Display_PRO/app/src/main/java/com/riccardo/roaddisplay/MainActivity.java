package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int REQ_LOC = 42;
    RideView view;
    LocationManager lm;
    LocationListener listener;
    RoadDb db;
    RoadEngine engine;
    ToneGenerator tone;
    boolean audio = true;                 // Audio is enabled from launch; no activation overlay.
    boolean demo = false;
    volatile boolean downloadingRoads = false;
    volatile boolean roadDownloadAttempted = false;
    int satellitesVisible = 0;
    int satellitesUsed = 0;
    GnssStatus.Callback gnssCallback;
    long lastOnline = 0;
    Location previousMapLocation;
    float mapBearing = 0f;
    boolean hasMapBearing = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Prioritise legibility in sunlight while ROAD DISPLAY PRO is in the foreground.
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL;
        getWindow().setAttributes(lp);
        immersive();
        db = new RoadDb(this);
        engine = new RoadEngine(db);
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        view = new RideView(this);
        setContentView(view);
        requestLocation();
    }

    void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        startGps();
    }

    void startGps() {
        if (lm != null) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                updateMapBearing(l);
                boolean warn = engine.update(l);
                if (warn) {
                    if (engine.current.type == 4) beep(2, true);
                    else beep(engine.current.type, false);
                }
                view.invalidate();
                if (l.getAccuracy() < 100f && System.currentTimeMillis() - lastOnline > 20000L && !downloadingRoads) {
                    lastOnline = System.currentTimeMillis();
                    downloadingRoads = true;
                    roadDownloadAttempted = true;
                    new Thread(() -> {
                        try { engine.fetchOnline(l); }
                        finally {
                            downloadingRoads = false;
                            if (view != null) view.postInvalidate();
                        }
                    }, "road-data-download").start();
                }
            }
            @Override public void onProviderEnabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onProviderDisabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onStatusChanged(String p, int s, Bundle e) { if (view != null) view.invalidate(); }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = 0, used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) {
                        if (status.usedInFix(i)) used++;
                        visible++;
                    }
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (view != null) view.invalidate();
                }
            };
            try { lm.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper())); }
            catch (Exception ignored) { }
        }
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
    }

    void updateMapBearing(Location location) {
        if (location == null) return;
        if (location.hasBearing() && (!location.hasSpeed() || location.getSpeed() > 0.8f)) {
            mapBearing = location.getBearing();
            hasMapBearing = true;
        } else if (previousMapLocation != null) {
            float moved = previousMapLocation.distanceTo(location);
            if (moved >= 3.0f) {
                mapBearing = previousMapLocation.bearingTo(location);
                hasMapBearing = true;
            }
        }
        previousMapLocation = new Location(location);
    }

    void beep(int n, boolean longFirst) {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                if (longFirst) { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 520); Thread.sleep(180); }
                for (int i = 0; i < n; i++) { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(160); }
            } catch (Exception ignored) { }
        }, "curve-audio").start();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_LOC && g != null && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startGps();
        else if (view != null) view.invalidate();
    }

    @Override public void onBackPressed() {
        if (demo) { demo = false; if (view != null) view.invalidate(); }
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (lm != null) {
            if (listener != null) lm.removeUpdates(listener);
            if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
                try { lm.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
            }
        }
        if (tone != null) tone.release();
        if (db != null) db.close();
        super.onDestroy();
    }

    class RideView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Curve emptyCurve = new Curve();
        float demoSpeed = 82f, demoDist = 120f, demoGrade = 4f, demoRec = 65f;
        int demoType = 1, demoDir = 1;
        final RectF backRect = new RectF(), typeRect = new RectF(), dirRect = new RectF();
        final ArrayList<SliderHit> sliderHits = new ArrayList<>();
        final int yellow = 0xFFFFD400, green = 0xFF00F080, blue = 0xFF42A5FF;
        final float density;

        RideView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            p.setTypeface(TypefaceCompat.bold());
            p.setTextAlign(Paint.Align.LEFT);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
        }

        float dp(float v) { return v * density; }
        float minDp() { return Math.min(getWidth(), getHeight()) / density; }
        void txt(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align) {
            p.setTextSize(Math.max(10f, sizeDp) * density);
            p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            c.drawText(s, x, y, p);
        }
        void panel(Canvas c, RectF r, int color, float radius) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(r, radius, radius, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.BLACK);
            if (demo) drawDemo(c); else drawRide(c);
            postInvalidateDelayed(1000); // Keep the on-screen clock current.
        }

        String now() { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); }
        String gpsSummary() {
            Location l = engine.loc;
            if (l == null) return "GPS IN RICERCA";
            String acc = l.hasAccuracy() ? " ±" + Math.round(l.getAccuracy()) + "m" : "";
            if (satellitesVisible > 0) return "GPS " + satellitesUsed + "/" + satellitesVisible + " sat" + acc;
            return engine.gpsGood() ? "GPS OK" + acc : "GPS DEBOLE" + acc;
        }
        String roadSummary() {
            if (downloadingRoads) return "SCARICO STRADE…";
            if (engine.ways != null && !engine.ways.isEmpty()) return "STRADE " + engine.ways.size();
            if (!roadDownloadAttempted) return "DATI STRADALI IN ATTESA";
            return "DATI STRADALI NON DISPONIBILI";
        }
        void drawTopStatus(Canvas c) {
            int w = getWidth(); boolean land = w > getHeight();
            float barH = dp(land ? 34 : 50);
            panel(c, new RectF(0, 0, w, barH), 0xFF111820, 0);
            float fs = Math.max(10f, Math.min(15f, minDp() * .034f));
            int gpsColor = engine.gpsGood() ? green : 0xFFFFB84D;
            int roadColor = (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D;
            if (land) {
                txt(c, now(), dp(10), dp(23), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w * .46f, dp(23), fs, gpsColor, Paint.Align.CENTER);
                String road = downloadingRoads ? "SCARICO STRADE…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : "STRADE IN ATTESA");
                txt(c, road, w - dp(10), dp(23), fs, roadColor, Paint.Align.RIGHT);
            } else {
                txt(c, now(), dp(10), dp(21), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w - dp(10), dp(21), fs, gpsColor, Paint.Align.RIGHT);
                String road = downloadingRoads ? "DOWNLOAD DATI STRADALI…" : (engine.ways != null && !engine.ways.isEmpty() ? "DATI STRADALI OK · " + engine.ways.size() + " STRADE" : "DATI STRADALI IN ATTESA");
                txt(c, road, w / 2f, dp(42), Math.max(9f, fs - 1), roadColor, Paint.Align.CENTER);
            }
        }

        void drawDemoInfo(Canvas c, boolean land) {
            float y = dp(48), h = dp(29), w = getWidth();
            panel(c, new RectF(0, y, w, y + h), 0xFF111820, 0);
            float fs = Math.max(9f, Math.min(12f, minDp() * .030f));
            txt(c, now(), dp(9), y + dp(19), fs, Color.WHITE, Paint.Align.LEFT);
            txt(c, gpsSummary(), w * .48f, y + dp(19), fs, engine.gpsGood() ? green : 0xFFFFB84D, Paint.Align.CENTER);
            String roads = downloadingRoads ? "DOWNLOAD…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : "STRADE IN ATTESA");
            txt(c, roads, w - dp(9), y + dp(19), fs, (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D, Paint.Align.RIGHT);
        }

        void drawRide(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            Location l = engine.loc;
            Curve q = engine.current == null ? emptyCurve : engine.current;
            drawTopStatus(c);
            if (land) {
                float curveSize = Math.min(h * .235f, w * .12f);
                drawCurve(c, w * .19f, h * .34f, q, curveSize);
                float mapSize = Math.min(h * .44f, w * .22f);
                RectF map = new RectF(w * .50f - mapSize / 2f, h * .51f - mapSize / 2f,
                        w * .50f + mapSize / 2f, h * .51f + mapSize / 2f);
                drawRoadMap(c, map, l);
                drawSpeed(c, w * .82f, h * .43f, l == null ? 0 : speed(l), q.recommended, true);
                drawGrade(c, w * .82f, h * .90f, q.grade, true);
            } else {
                float curveSize = Math.min(w * .30f, h * .095f);
                drawCurve(c, w * .5f, h * .145f, q, curveSize);
                float mapSize = Math.min(w * .70f, h * .30f);
                RectF map = new RectF(w / 2f - mapSize / 2f, h * .48f - mapSize / 2f,
                        w / 2f + mapSize / 2f, h * .48f + mapSize / 2f);
                drawRoadMap(c, map, l);
                drawSpeed(c, w * .5f, h * .765f, l == null ? 0 : speed(l), q.recommended, false);
                drawGrade(c, w * .5f, h * .955f, q.grade, false);
            }
            float b = dp(10);
            float buttonTop = dp(land ? 39 : 54);
            RectF demoButton = new RectF(w - dp(78), buttonTop, w - b, buttonTop + dp(30));
            panel(c, demoButton, 0xFF252A30, dp(8));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(demoButton, dp(8), dp(8), stroke); stroke.setStyle(Paint.Style.STROKE);
            txt(c, "DEMO", demoButton.centerX(), demoButton.centerY() + dp(5), 12, yellow, Paint.Align.CENTER);
            txt(c, "AUDIO ON", dp(12), h - dp(10), 11, green, Paint.Align.LEFT);
        }

        void drawRoadMap(Canvas c, RectF bounds, Location location) {
            float radius = dp(7);
            panel(c, bounds, 0xFF080C10, radius);
            c.save();
            Path clip = new Path(); clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
            c.clipPath(clip);

            // Faint high-contrast grid; the map covers 1 km x 1 km (500 m radius).
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(0.6f)); p.setColor(0xFF202A33);
            for (int i = 1; i < 4; i++) {
                float x = bounds.left + bounds.width() * i / 4f;
                float y = bounds.top + bounds.height() * i / 4f;
                c.drawLine(x, bounds.top, x, bounds.bottom, p);
                c.drawLine(bounds.left, y, bounds.right, y, p);
            }

            if (location != null && engine.ways != null && !engine.ways.isEmpty()) {
                double lat0 = location.getLatitude(), lon0 = location.getLongitude();
                double cosLat = Math.cos(Math.toRadians(lat0));
                float bearing = hasMapBearing ? mapBearing : 0f;
                double theta = Math.toRadians(bearing);
                float scaleX = bounds.width() / 1000f;
                float scaleY = bounds.height() / 1000f;
                for (RoadWay way : engine.ways) {
                    if (way == null || way.pts == null || way.pts.size() < 2) continue;
                    Path road = new Path(); boolean started = false;
                    for (Geo point : way.pts) {
                        double east = (point.lon - lon0) * 111320.0 * cosLat;
                        double north = (point.lat - lat0) * 110540.0;
                        // Rotate the map so the current direction of travel points upward.
                        double eastRot = east * Math.cos(theta) - north * Math.sin(theta);
                        double northRot = east * Math.sin(theta) + north * Math.cos(theta);
                        float x = bounds.centerX() + (float)eastRot * scaleX;
                        float y = bounds.centerY() - (float)northRot * scaleY;
                        if (x < bounds.left - dp(10) || x > bounds.right + dp(10)
                                || y < bounds.top - dp(10) || y > bounds.bottom + dp(10)) {
                            started = false;
                            continue;
                        }
                        if (!started) { road.moveTo(x, y); started = true; }
                        else road.lineTo(x, y);
                    }
                    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
                    p.setStrokeWidth(dp(3.0f)); p.setColor(0xFF59636D); c.drawPath(road, p);
                    p.setStrokeWidth(dp(1.1f)); p.setColor(0xFFD5DDE4); c.drawPath(road, p);
                }
            } else {
                txt(c, location == null ? "GPS IN RICERCA" : "MAPPA IN ATTESA", bounds.centerX(), bounds.centerY(),
                        Math.max(10, Math.min(14, minDp() * .034f)), 0xFFB8C2CC, Paint.Align.CENTER);
            }

            // Fixed centered motorcycle marker inside a thin white frame.
            float markerSize = Math.min(bounds.width(), bounds.height()) * 0.19f;
            RectF marker = new RectF(bounds.centerX() - markerSize / 2f, bounds.centerY() - markerSize / 2f,
                    bounds.centerX() + markerSize / 2f, bounds.centerY() + markerSize / 2f);
            p.setStyle(Paint.Style.FILL); p.setColor(0xE6080A0D); c.drawRoundRect(marker, dp(3), dp(3), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(Color.WHITE); c.drawRoundRect(marker, dp(3), dp(3), p);
            Path bike = new Path();
            bike.moveTo(bounds.centerX(), marker.top + marker.height() * .18f);
            bike.lineTo(marker.left + marker.width() * .23f, marker.bottom - marker.height() * .20f);
            bike.lineTo(marker.centerX(), marker.bottom - marker.height() * .35f);
            bike.lineTo(marker.right - marker.width() * .23f, marker.bottom - marker.height() * .20f);
            bike.close(); p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFD400); c.drawPath(bike, p);
            c.restore();

            // Border and scale label remain outside the clipped map content.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(Color.WHITE);
            c.drawRoundRect(bounds, radius, radius, p); p.setStyle(Paint.Style.FILL);
            txt(c, "MAPPA · RAGGIO 500 m", bounds.centerX(), bounds.top + dp(15),
                    Math.max(9, Math.min(12, minDp() * .028f)), Color.WHITE, Paint.Align.CENTER);
            if (location != null && !hasMapBearing) {
                txt(c, "DIREZIONE IN ATTESA", bounds.centerX(), bounds.bottom - dp(8),
                        Math.max(8, Math.min(10, minDp() * .024f)), 0xFFFFD400, Paint.Align.CENTER);
            }
        }

        float speed(Location l) { return l.hasSpeed() ? l.getSpeed() * 3.6f : 0f; }
        String fmtDist(float d) { return d < 1000 ? Math.round(d) + " m" : String.format(Locale.US, "%.1f km", d / 1000f); }

        void drawSpeed(Canvas c, float cx, float baseY, float s, float rec, boolean land) {
            float numberSize = Math.min(minDp() * (land ? .21f : .255f), land ? 78f : 116f);
            numberSize = Math.max(48f, numberSize);
            txt(c, String.valueOf(Math.round(s)), cx, baseY, numberSize, Color.WHITE, Paint.Align.CENTER);
            txt(c, "km/h", cx, baseY + dp(land ? 34 : 42), land ? 25 : 29, Color.WHITE, Paint.Align.CENTER);
            if (rec > 0) {
                txt(c, "CONSIGLIATA", cx, baseY + dp(land ? 62 : 82), land ? 14 : 17, yellow, Paint.Align.CENTER);
                txt(c, Math.round(rec) + " km/h", cx, baseY + dp(land ? 88 : 116), land ? 23 : 29, yellow, Paint.Align.CENTER);
            }
        }

        void drawGrade(Canvas c, float cx, float y, float g, boolean land) {
            String s = (g > 0 ? "▲ +" : g < 0 ? "▼ " : "— ") + Math.round(g) + "%";
            txt(c, s, cx, y, land ? 20 : 23, g > 0 ? green : g < 0 ? blue : Color.WHITE, Paint.Align.CENTER);
        }

        void drawCurve(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) {
                txt(c, "—", cx, cy + dp(12), Math.max(32, sz / density * .62f), 0xFF6B737B, Paint.Align.CENTER);
                txt(c, "NESSUNA CURVA RILEVATA", cx, cy + sz * .82f, 11, 0xFF9AA3AD, Paint.Align.CENTER);
                return;
            }
            boolean left = q.dir < 0;
            int curveColor = q.type == 1 ? 0xFF35D66F : q.type == 2 ? 0xFFFFD400 : 0xFFF04438;
            if (q.type >= 3) {
                Path triangle = new Path();
                triangle.moveTo(cx, cy - sz * .76f);
                triangle.lineTo(cx - sz * .72f, cy + sz * .53f);
                triangle.lineTo(cx + sz * .72f, cy + sz * .53f);
                triangle.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF050608); c.drawPath(triangle, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
                stroke.setColor(yellow); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f)); c.drawPath(triangle, stroke);
                Path inner = new Path();
                inner.moveTo(cx, cy - sz * .69f);
                inner.lineTo(cx - sz * .64f, cy + sz * .47f);
                inner.lineTo(cx + sz * .64f, cy + sz * .47f);
                inner.close();
                stroke.setColor(0xFFF04438); stroke.setStrokeWidth(Math.max(dp(1.6f), sz * .027f)); c.drawPath(inner, stroke);
            }

            float sign = left ? -1f : 1f;
            Path path = new Path();
            if (q.type == 4) {
                // A much tighter U-turn profile for hairpins.
                path.moveTo(cx + sign * sz * .32f, cy + sz * .30f);
                path.cubicTo(cx + sign * sz * .62f, cy + sz * .02f, cx + sign * sz * .48f, cy - sz * .40f, cx, cy - sz * .38f);
                path.cubicTo(cx - sign * sz * .44f, cy - sz * .36f, cx - sign * sz * .43f, cy + sz * .05f, cx - sign * sz * .18f, cy + sz * .13f);
            } else {
                path.moveTo(cx + sign * sz * .34f, cy + sz * .30f);
                path.cubicTo(cx + sign * sz * .10f, cy + sz * .26f, cx + sign * sz * .10f, cy - sz * .16f, cx + sign * sz * .35f, cy - sz * .27f);
                path.cubicTo(cx + sign * sz * .56f, cy - sz * .36f, cx + sign * sz * .58f, cy - sz * .53f, cx + sign * sz * .47f, cy - sz * .62f);
            }
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .19f)); c.drawPath(path, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * (q.type == 1 ? .13f : q.type == 2 ? .145f : .15f))); c.drawPath(path, stroke);

            // Arrowhead follows the travel direction at the end of the curve.
            float ex = cx + sign * sz * (q.type == 4 ? -.18f : .47f);
            float ey = cy - sz * (q.type == 4 ? -.13f : .62f);
            Path arrow = new Path();
            arrow.moveTo(ex - sign * sz * .18f, ey + sz * .04f);
            arrow.lineTo(ex, ey - sz * .13f);
            arrow.lineTo(ex + sign * sz * .18f, ey + sz * .04f);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .11f)); c.drawPath(arrow, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f)); c.drawPath(arrow, stroke);

            if (q.type == 4) {
                float exMarkX = cx + sz * .38f, exMarkY = cy + sz * .25f;
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFF04438); c.drawCircle(exMarkX, exMarkY, sz * .17f, p);
                txt(c, "!", exMarkX, exMarkY + sz * .105f, Math.max(18, sz / density * .30f), Color.WHITE, Paint.Align.CENTER);
            }
            txt(c, q.label == null ? "CURVA" : q.label, cx, cy + sz * .77f,
                    Math.max(15, Math.min(24, sz / density * .20f)), curveColor, Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx, cy + sz * .99f,
                    Math.max(20, Math.min(32, sz / density * .25f)), yellow, Paint.Align.CENTER);
            txt(c, left ? "SINISTRA" : "DESTRA", cx, cy + sz * 1.20f,
                    Math.max(11, Math.min(16, sz / density * .13f)), 0xFFE0E5EA, Paint.Align.CENTER);
        }

        void drawDemo(Canvas c) {
            int w = getWidth(), h = getHeight(); boolean land = w > h;
            drawDemoHeader(c, land);
            Curve q = Curve.demo(demoType, demoDir, demoDist, demoRec, demoGrade);
            if (land) {
                drawDemoInfo(c, true);
                float sz = Math.min(h * .18f, w * .12f);
                drawCurve(c, w * .24f, h * .37f, q, sz);
                drawSpeed(c, w * .74f, h * .40f, demoSpeed, demoRec, true);
                drawGrade(c, w * .24f, h * .63f, demoGrade, true);
                drawDemoSliders(c, true, h * .68f);
            } else {
                drawDemoInfo(c, false);
                float sz = Math.min(w * .28f, h * .095f);
                drawCurve(c, w * .5f, h * .16f, q, sz);
                drawSpeed(c, w * .5f, h * .405f, demoSpeed, demoRec, false);
                drawGrade(c, w * .80f, h * .30f, demoGrade, false);
                drawDemoSliders(c, false, h * .60f);
            }
            txt(c, "SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA", w / 2f, h - dp(5), 10, 0xFFB0B7BF, Paint.Align.CENTER);
        }

        void drawDemoHeader(Canvas c, boolean land) {
            float w = getWidth(), hh = dp(48), margin = dp(7);
            panel(c, new RectF(0, 0, w, hh), 0xFF141B22, 0);
            backRect.set(margin, dp(5), w * .27f, hh - dp(5));
            typeRect.set(w * .29f, dp(5), w * .64f, hh - dp(5));
            dirRect.set(w * .66f, dp(5), w - margin, hh - dp(5));
            panel(c, backRect, 0xFF414A54, dp(8)); panel(c, typeRect, 0xFF26313A, dp(8)); panel(c, dirRect, 0xFF26313A, dp(8));
            txt(c, "← RIDE", backRect.centerX(), hh * .67f, Math.min(17, minDp() * .045f), Color.WHITE, Paint.Align.CENTER);
            String[] labels = {"", "LEGGERA", "MEDIA", "STRETTA", "TORNANTE"};
            txt(c, labels[demoType], typeRect.centerX(), hh * .67f, Math.min(15, minDp() * .038f), yellow, Paint.Align.CENTER);
            txt(c, demoDir < 0 ? "← SINISTRA" : "DESTRA →", dirRect.centerX(), hh * .67f, Math.min(14, minDp() * .036f), Color.WHITE, Paint.Align.CENTER);
        }

        void drawDemoSliders(Canvas c, boolean land, float top) {
            sliderHits.clear();
            float w = getWidth(), h = getHeight(), bottom = h - dp(22);
            float gap = dp(5), left = dp(10), right = w - dp(10);
            String[] labels = {"VELOCITÀ", "DISTANZA", "PENDENZA", "CONSIGLIATA"};
            float[] values = {demoSpeed, demoDist, demoGrade, demoRec};
            String[] valuesText = {Math.round(demoSpeed) + " km/h", Math.round(demoDist) + " m", (demoGrade > 0 ? "+" : "") + Math.round(demoGrade) + "%", Math.round(demoRec) + " km/h"};
            float[] mins = {0, 0, -12, 0}, maxs = {180, 500, 12, 180};
            if (land) {
                float colW = (w - left - dp(10) - gap) / 2f;
                float rowH = Math.max(dp(34), (bottom - top - gap) / 2f);
                for (int i = 0; i < 4; i++) {
                    int col = i % 2, row = i / 2;
                    float x1 = left + col * (colW + gap), y1 = top + row * (rowH + gap);
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(x1, y1, x1 + colW, Math.min(bottom, y1 + rowH)));
                }
            } else {
                float rowH = Math.max(dp(35), (bottom - top) / 4f);
                for (int i = 0; i < 4; i++) {
                    float y1 = top + i * rowH;
                    drawSlider(c, i, labels[i], valuesText[i], values[i], mins[i], maxs[i], new RectF(left, y1, right, Math.min(bottom, y1 + rowH - gap)));
                }
            }
        }

        void drawSlider(Canvas c, int id, String label, String valueText, float value, float min, float max, RectF area) {
            panel(c, area, 0xFF10161C, dp(6));
            float pad = dp(9), labelY = area.top + dp(17), trackY = area.bottom - dp(9);
            float fs = Math.max(11, Math.min(14, minDp() * .034f));
            txt(c, label, area.left + pad, labelY, fs, 0xFFE4EAF0, Paint.Align.LEFT);
            txt(c, valueText, area.right - pad, labelY, fs, yellow, Paint.Align.RIGHT);
            float tx1 = area.left + pad, tx2 = area.right - pad;
            p.setColor(0xFF3D4852); p.setStrokeWidth(dp(5)); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(tx1, trackY, tx2, trackY, p);
            float ratio = Math.max(0, Math.min(1, (value - min) / (max - min)));
            p.setColor(yellow); c.drawLine(tx1, trackY, tx1 + (tx2 - tx1) * ratio, trackY, p);
            p.setStyle(Paint.Style.FILL); c.drawCircle(tx1 + (tx2 - tx1) * ratio, trackY, dp(5), p);
            RectF hit = new RectF(area); sliderHits.add(new SliderHit(id, hit, tx1, tx2, min, max));
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            if (!demo) {
                boolean land = getWidth() > getHeight();
                float buttonTop = dp(land ? 39 : 54);
                RectF demoButton = new RectF(getWidth() - dp(78), buttonTop, getWidth() - dp(10), buttonTop + dp(30));
                if (demoButton.contains(x, y)) { demo = true; invalidate(); return true; }
                return true;
            }
            if (backRect.contains(x, y)) { demo = false; invalidate(); return true; }
            if (typeRect.contains(x, y)) { demoType = demoType % 4 + 1; invalidate(); return true; }
            if (dirRect.contains(x, y)) { demoDir = -demoDir; invalidate(); return true; }
            for (SliderHit hit : sliderHits) {
                if (hit.area.contains(x, y)) {
                    float ratio = Math.max(0f, Math.min(1f, (x - hit.x1) / Math.max(1f, hit.x2 - hit.x1)));
                    float value = hit.min + ratio * (hit.max - hit.min);
                    switch (hit.id) {
                        case 0: demoSpeed = value; break;
                        case 1: demoDist = value; break;
                        case 2: demoGrade = value; break;
                        case 3: demoRec = value; break;
                    }
                    invalidate(); return true;
                }
            }
            return true;
        }

        class SliderHit {
            int id; RectF area; float x1, x2, min, max;
            SliderHit(int i, RectF a, float xStart, float xEnd, float mn, float mx) { id=i; area=a; x1=xStart; x2=xEnd; min=mn; max=mx; }
        }
    }

    // Keeps typography consistent without depending on downloaded fonts.
    static class TypefaceCompat {
        static android.graphics.Typeface bold() { return android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); }
    }
}
