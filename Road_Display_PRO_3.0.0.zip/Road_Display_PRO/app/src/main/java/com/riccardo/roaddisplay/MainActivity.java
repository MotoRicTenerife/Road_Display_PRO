package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.GnssStatus;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    static final int REQ_LOC = 42;
    RideView view;
    LocationManager lm;
    LocationListener listener;
    RoadDb db;
    RoadEngine engine;
    ToneGenerator tone;
    boolean audio = true;                 // Audio is enabled from launch; no activation overlay.
    boolean tripsScreen = false;
    String installDate = "";
    volatile boolean downloadingRoads = false;
    volatile boolean roadDownloadAttempted = false;
    int satellitesVisible = 0;
    int satellitesUsed = 0;
    GnssStatus.Callback gnssCallback;
    long lastOnline = 0;
    Location previousMapLocation;
    double lastRoadDownloadLat = Double.NaN, lastRoadDownloadLon = Double.NaN;
    float mapBearing = 0f;
    boolean hasMapBearing = false;
    volatile long lastWeatherAt = 0L;
    volatile double lastWeatherLat = Double.NaN, lastWeatherLon = Double.NaN;
    volatile boolean weatherLoading = false;
    volatile String weatherSummary = "METEO IN ATTESA";
    volatile String weatherDetail = "";
    volatile boolean weatherAdverse = false;
    volatile boolean showWeatherDetails = false;
    volatile boolean approximateLocation = false;
    volatile boolean ipFallbackStarted = false;
    volatile String roadDataStatus = "";
    volatile String airTemperature = "--°";
    double dailyKm = 0.0;
    volatile int currentSpeedLimitKmh = 0;
    boolean speedLimitAlerted = false;
    boolean radarAlerted = false;
    volatile long radarAlertUntil = 0L;
    volatile int radarFlashToggles = 0;
    Location lastDistanceLocation;
    String dailyDistanceDate = "";
    SensorManager lightSensorManager;
    Sensor lightSensor;
    SensorEventListener lightSensorListener;
    float originalWindowBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
    boolean brightnessCaptured = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Adjust only this Activity's window brightness using the ambient-light sensor;
        // restore the previous window setting when the app leaves the foreground.
        originalWindowBrightness = getWindow().getAttributes().screenBrightness;
        brightnessCaptured = true;
        lightSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (lightSensorManager != null) lightSensor = lightSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        lightSensorListener = new SensorEventListener() {
            @Override public void onSensorChanged(SensorEvent event) {
                if (event == null || event.values == null || event.values.length == 0) return;
                float lux = Math.max(0f, event.values[0]);
                final float target = lux < 3f ? 0.25f : lux < 20f ? 0.40f : lux < 80f ? 0.65f : lux < 400f ? 0.88f : 1.0f;
                runOnUiThread(() -> setWindowBrightness(target));
            }
            @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
        };
        immersive();
        android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
        installDate = prefs.getString("install_date", "");
        if (installDate.isEmpty()) {
            long firstInstall = System.currentTimeMillis();
            try { firstInstall = getPackageManager().getPackageInfo(getPackageName(), 0).firstInstallTime; } catch (Exception ignored) { }
            installDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(firstInstall));
            prefs.edit().putString("install_date", installDate).apply();
        }
        db = new RoadDb(this);
        engine = new RoadEngine(db);
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        view = new RideView(this);
        setContentView(view);
        requestLocation();
    }

    void immersive() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        startGps();
    }

    void startGps() {
        if (lm != null) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) { processLocation(l); }
            @Override public void onProviderEnabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onProviderDisabled(String p) { if (view != null) view.invalidate(); }
            @Override public void onStatusChanged(String p, int s, Bundle e) { if (view != null) view.invalidate(); }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = 0, used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) {
                        if (status.usedInFix(i)) used++;
                        visible++;
                    }
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (view != null) view.invalidate();
                }
            };
            try { lm.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper())); }
            catch (Exception ignored) { }
        }
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 250, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }
        try { lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 15000, 500, listener, Looper.getMainLooper()); }
        catch (SecurityException ignored) { }
        catch (Exception ignored) { }

        // Use a recent system last-known position immediately, even before a fresh GPS fix arrives.
        Location best = null;
        String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String provider : providers) {
            try {
                Location candidate = lm.getLastKnownLocation(provider);
                if (candidate != null && (best == null ||
                        (candidate.hasAccuracy() && (!best.hasAccuracy() || candidate.getAccuracy() < best.getAccuracy())) ||
                        candidate.getTime() > best.getTime() + 120000L)) best = candidate;
            } catch (SecurityException ignored) { }
            catch (Exception ignored) { }
        }
        if (best != null) processLocation(best);
        else {
            Location saved = loadSavedLocation();
            if (saved != null) processLocation(saved);
            if (engine.loc == null) startIpLocationFallback();
        }
    }

    void processLocation(Location l) {
        if (l == null) return;
        boolean accurateGps = LocationManager.GPS_PROVIDER.equals(l.getProvider()) && l.hasAccuracy() && l.getAccuracy() <= 50f;
        approximateLocation = !accurateGps;
        updateMapBearing(l);
        if (accurateGps) {
            updateDailyDistance(l);
            boolean warn = engine.update(l);
            if (warn) {
                if (engine.current.type == 4) beep(2, true);
                else beep(engine.current.type, false);
            }
            currentSpeedLimitKmh = engine.speedLimitKmh(l);
            double radarDistance = engine.nearestRadarMeters(l);
            if (radarDistance <= 300.0 && radarDistance >= 5.0) {
                if (!radarAlerted) { triggerRadarAlert(); radarAlerted = true; }
            } else if (radarDistance > 360.0 || Double.isInfinite(radarDistance)) {
                radarAlerted = false;
            }
            float actualKmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            if (currentSpeedLimitKmh > 0 && actualKmh > currentSpeedLimitKmh + 3f) {
                if (!speedLimitAlerted) { beepSpeedLimit(); speedLimitAlerted = true; }
            } else if (currentSpeedLimitKmh <= 0 || actualKmh <= currentSpeedLimitKmh - 3f) {
                speedLimitAlerted = false;
            }
        } else {
            // Approximate/network locations are for map loading only, never curve or speed advice.
            engine.loc = new Location(l);
            engine.current = new Curve();
            engine.noRoad = true;
            engine.reloadRoads(l);
        }
        if (!"ip-approx".equals(l.getProvider())) saveLocation(l);
        if (view != null) view.invalidate();
        long now = System.currentTimeMillis();
        boolean firstRoadLoad = !roadDownloadAttempted;
        boolean movedFar = !Double.isNaN(lastRoadDownloadLat) &&
                distanceMeters(lastRoadDownloadLat, lastRoadDownloadLon, l.getLatitude(), l.getLongitude()) >= 8000.0;
        boolean retryFailed = roadDownloadAttempted && (engine.mapWays == null || engine.mapWays.isEmpty()) && now - lastOnline >= 120000L;
        boolean cacheExpired = now - lastOnline >= 6L * 60L * 60L * 1000L;
        // A coarse or network-derived fix is still enough to fetch/display a regional map.
        if (!downloadingRoads && (firstRoadLoad || movedFar || retryFailed || cacheExpired)) {
            lastOnline = now;
            lastRoadDownloadLat = l.getLatitude(); lastRoadDownloadLon = l.getLongitude();
            downloadingRoads = true;
            roadDownloadAttempted = true;
            roadDataStatus = tr("SCARICO STRADE…");
            Location requestLocation = new Location(l);
            new Thread(() -> {
                boolean ok = false;
                try {
                    ok = engine.fetchOnline(requestLocation);
                    engine.reloadRoads(requestLocation);
                    roadDataStatus = ok || (engine.mapWays != null && !engine.mapWays.isEmpty())
                            ? "" : tr("DATI STRADALI NON DISPONIBILI");
                } finally {
                    downloadingRoads = false;
                    if (view != null) view.postInvalidate();
                }
            }, "road-data-download").start();
        }
        // Weather can use a coarse network/IP location when GPS reception is poor.
        maybeUpdateWeather(l, false);
    }

    void updateDailyDistance(Location l) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
        if (!today.equals(dailyDistanceDate)) {
            if (!dailyDistanceDate.isEmpty()) prefs.edit().putLong("trip_" + dailyDistanceDate, Double.doubleToLongBits(dailyKm)).apply();
            dailyDistanceDate = today;
            dailyKm = Double.longBitsToDouble(prefs.getLong("trip_" + today, Double.doubleToLongBits(0.0)));
            lastDistanceLocation = null;
        }
        if (lastDistanceLocation != null) {
            float delta = lastDistanceLocation.distanceTo(l);
            long age = Math.abs(l.getTime() - lastDistanceLocation.getTime());
            // Ignore GPS jumps and stale fixes; count only plausible movement between fresh fixes.
            if (delta >= 2f && delta <= 2000f && age <= 120000L) {
                dailyKm += delta / 1000.0;
                prefs.edit().putString("daily_date", today).putLong("daily_km_bits", Double.doubleToLongBits(dailyKm)).putLong("trip_" + today, Double.doubleToLongBits(dailyKm)).apply();
            }
        }
        lastDistanceLocation = new Location(l);
    }

    void saveLocation(Location l) {
        try {
            getSharedPreferences("road_display", MODE_PRIVATE).edit()
                    .putString("last_lat", Double.toString(l.getLatitude()))
                    .putString("last_lon", Double.toString(l.getLongitude()))
                    .putLong("last_time", System.currentTimeMillis()).apply();
        } catch (Exception ignored) { }
    }

    Location loadSavedLocation() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("road_display", MODE_PRIVATE);
            String lat = prefs.getString("last_lat", null), lon = prefs.getString("last_lon", null);
            if (lat == null || lon == null) return null;
            Location saved = new Location("saved-network");
            saved.setLatitude(Double.parseDouble(lat)); saved.setLongitude(Double.parseDouble(lon));
            saved.setAccuracy(5000f); saved.setTime(prefs.getLong("last_time", System.currentTimeMillis()));
            return saved;
        } catch (Exception ignored) { return null; }
    }

    void startIpLocationFallback() {
        if (ipFallbackStarted) return;
        ipFallbackStarted = true;
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL("https://ipwho.is/").openConnection();
                connection.setConnectTimeout(7000); connection.setReadTimeout(9000);
                connection.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.7.2 Android");
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) return;
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject json = new JSONObject(body.toString());
                if (!json.optBoolean("success", false)) return;
                double lat = json.optDouble("latitude", Double.NaN), lon = json.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
                runOnUiThread(() -> {
                    if (engine.loc != null) return; // A real system location arrived while IP lookup was running.
                    Location approximate = new Location("ip-approx");
                    approximate.setLatitude(lat); approximate.setLongitude(lon); approximate.setAccuracy(15000f);
                    approximate.setTime(System.currentTimeMillis());
                    processLocation(approximate);
                });
            } catch (Exception ignored) {
                roadDataStatus = tr("DATI STRADALI NON DISPONIBILI");
                if (view != null) view.postInvalidate();
            } finally { if (connection != null) connection.disconnect(); }
        }, "ip-location-fallback").start();
    }

    String tr(String it) {
        String lang = Locale.getDefault().getLanguage();
        if ("it".equals(lang) || lang == null) return it;
        String es = "es".equals(lang) ? "es" : "en";
        String[][] rows = {
            {"GPS IN RICERCA","GPS BUSCANDO","GPS SEARCHING"}, {"GPS DEBOLE","GPS DÉBIL","WEAK GPS"},
            {"GPS OK","GPS OK","GPS OK"}, {"DATI STRADALI IN ATTESA","ESPERANDO DATOS DE CARRETERA","WAITING FOR ROAD DATA"},
            {"DATI STRADALI NON DISPONIBILI","DATOS DE CARRETERA NO DISPONIBLES","ROAD DATA UNAVAILABLE"},
            {"SCARICO STRADE…","DESCARGANDO CARRETERAS…","DOWNLOADING ROADS…"},
            {"DOWNLOAD DATI STRADALI…","DESCARGANDO DATOS…","DOWNLOADING ROAD DATA…"},
            {"STRADE IN ATTESA","ESPERANDO CARRETERAS","WAITING FOR ROADS"}, {"DIREZIONE IN ATTESA","ESPERANDO DIRECCIÓN","WAITING FOR HEADING"},
            {"NESSUNA CURVA RILEVATA","NO SE DETECTA CURVA","NO CURVE DETECTED"}, {"LEGGERA","SUAVE","MILD"},
            {"MEDIA","MEDIA","MEDIUM"}, {"STRETTA","CERRADA","SHARP"}, {"TORNANTE","HORQUILLA","HAIRPIN"},
            {"SINISTRA","IZQUIERDA","LEFT"}, {"DESTRA","DERECHA","RIGHT"}, {"CONSIGLIATA","RECOMENDADA","RECOMMENDED"},
            {"VELOCITÀ","VELOCIDAD","SPEED"}, {"DISTANZA","DISTANCIA","DISTANCE"}, {"PENDENZA","PENDIENTE","GRADE"},
            {"SIMULAZIONE: NON USARE COME INDICAZIONE DI SICUREZZA","SIMULACIÓN: NO USAR COMO INDICACIÓN DE SEGURIDAD","SIMULATION: NOT A SAFETY RECOMMENDATION"},
            {"AUDIO ON","AUDIO ACTIVADO","AUDIO ON"}, {"METEO IN ATTESA","METEO PENDIENTE","WEATHER PENDING"},
            {"METEO NON DISPONIBILE","METEO NO DISPONIBLE","WEATHER UNAVAILABLE"}, {"SERENO","DESPEJADO","CLEAR"},
            {"NUVOLOSO","NUBLADO","CLOUDY"}, {"NEBBIA","NIEBLA","FOG"}, {"PIOVIGGINE","LLOVIZNA","DRIZZLE"},
            {"PIOVIGGINE GELATA","LLUVIA ENGELANTE","FREEZING DRIZZLE"}, {"PIOGGIA","LLUVIA","RAIN"},
            {"PIOGGIA GELATA","LLUVIA ENGELANTE","FREEZING RAIN"}, {"NEVE","NIEVE","SNOW"}, {"ROVESCI","CHUBASCOS","SHOWERS"},
            {"ROVESCI DI NEVE","CHUBASCOS DE NIEVE","SNOW SHOWERS"}, {"TEMPORALE","TORMENTA","THUNDERSTORM"},
            {"ATTENZIONE METEO","ALERTA METEOROLÓGICA","WEATHER ALERT"}, {"MAPPA · RAGGIO 500 m","MAPA · RADIO 500 m","MAP · 500 m RADIUS"},
            {"MAPPA · RAGGIO 500 m · TRASCINA PER SCORRERE","MAPA · RADIO 500 m · ARRASTRA PARA MOVER","MAP · 500 m RADIUS · DRAG TO PAN"},
            {"CHIUDI ✕","CERRAR ✕","CLOSE ✕"}, {"← RIDE","← CONDUCCIÓN","← RIDE"}, {"METEO ↻","METEO ↻","WEATHER ↻"},
            {"METEO…","METEO…","WEATHER…"}, {"ATTIVA AUDIO","ACTIVAR AUDIO","ENABLE AUDIO"},
            {"MAPPA IN ATTESA","MAPA PENDIENTE","MAP WAITING"},
            {"POSIZIONE APPROSSIMATIVA","POSICIÓN APROXIMADA","APPROXIMATE LOCATION"},
            {"POSIZIONE RETE","POSICIÓN DE RED","NETWORK LOCATION"},
            {"CARICAMENTO MAPPA…","CARGANDO MAPA…","LOADING MAP…"},
            {"MAPPA NON DISPONIBILE","MAPA NO DISPONIBLE","MAP UNAVAILABLE"},
            {"TEMPERATURA","TEMPERATURA","TEMPERATURE"}, {"TEMP","TEMP","TEMP"}
        };
        for (String[] row : rows) if (row[0].equals(it)) return row["es".equals(es) ? 1 : 2];
        return it;
    }

    void maybeUpdateWeather(Location location, boolean manual) {
        if (location == null || weatherLoading) return;
        long now = System.currentTimeMillis();
        boolean timeDue = lastWeatherAt == 0L || now - lastWeatherAt >= 30L * 60L * 1000L;
        boolean distanceDue = !Double.isNaN(lastWeatherLat) &&
                distanceMeters(lastWeatherLat, lastWeatherLon, location.getLatitude(), location.getLongitude()) >= 15000.0;
        if (!manual && !timeDue && !distanceDue) return;
        weatherLoading = true;
        Location at = new Location(location);
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String urlText = "https://api.open-meteo.com/v1/forecast?latitude=" + at.getLatitude()
                        + "&longitude=" + at.getLongitude()
                        + "&current=temperature_2m,apparent_temperature,precipitation,rain,showers,weather_code,wind_speed_10m,wind_gusts_10m"
                        + "&timezone=auto";
                connection = (HttpURLConnection) new URL(urlText).openConnection();
                connection.setConnectTimeout(10000); connection.setReadTimeout(15000);
                connection.setRequestMethod("GET");
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) throw new IllegalStateException("HTTP " + connection.getResponseCode());
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line; while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject root = new JSONObject(body.toString()).getJSONObject("current");
                int code = root.optInt("weather_code", -1);
                double temp = root.optDouble("temperature_2m", Double.NaN);
                double rain = root.optDouble("precipitation", 0.0);
                double wind = root.optDouble("wind_speed_10m", 0.0);
                double gust = root.optDouble("wind_gusts_10m", wind);
                String condition = weatherCodeLabel(code);
                weatherSummary = condition + (Double.isNaN(temp) ? "" : " · " + Math.round(temp) + "°C");
                airTemperature = Double.isNaN(temp) ? "--°" : Math.round(temp) + "°";
                String windLabel = "es".equals(Locale.getDefault().getLanguage()) ? "viento" : "en".equals(Locale.getDefault().getLanguage()) ? "wind" : "vento";
                String gustLabel = "es".equals(Locale.getDefault().getLanguage()) ? "rachas" : "en".equals(Locale.getDefault().getLanguage()) ? "gusts" : "raffiche";
                String rainLabel = "es".equals(Locale.getDefault().getLanguage()) ? "lluvia" : "en".equals(Locale.getDefault().getLanguage()) ? "rain" : "pioggia";
                weatherDetail = condition + " · " + Math.round(temp) + "°C · " + windLabel + " " + Math.round(wind) + " km/h · " + gustLabel + " " + Math.round(gust) + " km/h · " + rainLabel + " " + String.format(Locale.getDefault(), "%.1f", rain) + " mm";
                weatherAdverse = code >= 95 || code == 65 || code == 67 || code == 82 || code == 86 || rain >= 2.0 || gust >= 60.0;
                lastWeatherAt = System.currentTimeMillis();
                lastWeatherLat = at.getLatitude(); lastWeatherLon = at.getLongitude();
            } catch (Exception ex) {
                if (lastWeatherAt == 0L) weatherSummary = tr("METEO NON DISPONIBILE");
                weatherDetail = tr("METEO NON DISPONIBILE") + " · " + ("es".equals(Locale.getDefault().getLanguage()) ? "comprueba la conexión" : "en".equals(Locale.getDefault().getLanguage()) ? "check connection" : "verifica connessione");
                lastWeatherAt = System.currentTimeMillis();
            } finally {
                if (connection != null) connection.disconnect();
                weatherLoading = false;
                if (view != null) view.postInvalidate();
            }
        }, "weather-update").start();
    }

    double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }

    String weatherIcon() {
        String s = weatherSummary.toLowerCase(Locale.ROOT);
        if (s.contains("tempor") || s.contains("tempest")) return "⚡";
        if (s.contains("piogg") || s.contains("rain") || s.contains("lluv")) return "☂";
        if (s.contains("nuvol") || s.contains("cloud") || s.contains("nube")) return "☁";
        if (s.contains("vento") || s.contains("wind")) return "≋";
        if (s.contains("neve") || s.contains("snow")) return "❄";
        return "☀";
    }

    String weatherCodeLabel(int code) {
        switch (code) {
            case 0: return tr("SERENO");
            case 1: case 2: case 3: return tr("NUVOLOSO");
            case 45: case 48: return tr("NEBBIA");
            case 51: case 53: case 55: return tr("PIOVIGGINE");
            case 56: case 57: return tr("PIOVIGGINE GELATA");
            case 61: case 63: case 65: return tr("PIOGGIA");
            case 66: case 67: return tr("PIOGGIA GELATA");
            case 71: case 73: case 75: case 77: return tr("NEVE");
            case 80: case 81: case 82: return tr("ROVESCI");
            case 85: case 86: return tr("ROVESCI DI NEVE");
            case 95: case 96: case 99: return tr("TEMPORALE");
            default: return "METEO";
        }
    }

    void updateMapBearing(Location location) {
        if (location == null) return;
        if (location.hasBearing() && (!location.hasSpeed() || location.getSpeed() > 0.8f)) {
            mapBearing = location.getBearing();
            hasMapBearing = true;
        } else if (previousMapLocation != null) {
            float moved = previousMapLocation.distanceTo(location);
            if (moved >= 3.0f) {
                mapBearing = previousMapLocation.bearingTo(location);
                hasMapBearing = true;
            }
        }
        previousMapLocation = new Location(location);
    }

    void beep(int n, boolean longFirst) {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                if (longFirst) { tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 520); Thread.sleep(180); }
                for (int i = 0; i < n; i++) { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150); Thread.sleep(160); }
            } catch (Exception ignored) { }
        }, "curve-audio").start();
    }

    void triggerRadarAlert() {
        radarAlertUntil = System.currentTimeMillis() + 5000L;
        radarFlashToggles = 0;
        new Thread(() -> {
            try {
                if (audio && tone != null) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 2000);
                    Thread.sleep(2350);
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 2000);
                }
            } catch (Exception ignored) { }
        }, "radar-audio").start();
        final long until = radarAlertUntil;
        new Thread(() -> {
            while (System.currentTimeMillis() < until) {
                if (view != null) view.postInvalidate();
                try { Thread.sleep(250); } catch (InterruptedException ignored) { break; }
            }
            if (view != null) view.postInvalidate();
        }, "radar-flash").start();
    }

    void beepSpeedLimit() {
        if (!audio || tone == null) return;
        new Thread(() -> {
            try {
                for (int i = 0; i < 3; i++) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP, 85);
                    Thread.sleep(115);
                }
            } catch (Exception ignored) { }
        }, "speed-limit-audio").start();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_LOC && g != null) {
            boolean granted = false;
            for (int grant : g) if (grant == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) startGps(); else { startIpLocationFallback(); if (view != null) view.invalidate(); }
        } else if (view != null) view.invalidate();
    }

    @Override public void onBackPressed() {
        if (view != null && view.mapExpanded) { view.mapExpanded = false; view.mapPanX = 0; view.mapPanY = 0; view.invalidate(); }
        else if (tripsScreen) { tripsScreen = false; if (view != null) view.invalidate(); }
        else super.onBackPressed();
    }

    void setWindowBrightness(float brightness) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = Math.max(0.15f, Math.min(1f, brightness));
        getWindow().setAttributes(lp);
    }

    void restoreWindowBrightness() {
        if (!brightnessCaptured) return;
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = originalWindowBrightness;
        getWindow().setAttributes(lp);
    }

    @Override protected void onResume() {
        super.onResume();
        if (lightSensorManager != null && lightSensor != null && lightSensorListener != null) {
            try { lightSensorManager.registerListener(lightSensorListener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL); }
            catch (Exception ignored) { }
        }
    }

    @Override protected void onPause() {
        if (lightSensorManager != null && lightSensorListener != null) lightSensorManager.unregisterListener(lightSensorListener);
        restoreWindowBrightness();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (lm != null) {
            if (listener != null) lm.removeUpdates(listener);
            if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
                try { lm.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
            }
        }
        if (view != null) view.releaseTiles();
        if (tone != null) tone.release();
        if (db != null) db.close();
        super.onDestroy();
    }

    class RideView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Curve emptyCurve = new Curve();
        final RectF mapBounds = new RectF(), tripsButtonBounds = new RectF(), weatherButtonBounds = new RectF(), mapCloseBounds = new RectF(), mapRecenterBounds = new RectF(), tripsCloseBounds = new RectF();
        boolean mapExpanded = false, draggingMap = false, movedMap = false;
        float mapZoom = 1.0f, pinchStartDistance = 0f, pinchStartZoom = 1.0f;
        float mapZoomCompact = 1.0f;
        final RectF speedBounds = new RectF();
        double mapAnchorLat = Double.NaN, mapAnchorLon = Double.NaN;
        Location mapAnchorLocation;
        long lastTileAnchorUpdate = 0L;
        boolean pinching = false, pinchCompact = false;
        float tripsScroll = 0f;
        float downX, downY, downPanX, downPanY, mapPanX = 0f, mapPanY = 0f;
        final int yellow = 0xFFFFD400, green = 0xFF00F080, blue = 0xFF42A5FF;
        final float density;
        final LruCache<String, Bitmap> tileBitmaps = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
            @Override protected int sizeOf(String key, Bitmap value) { return value == null ? 0 : value.getByteCount(); }
        };
        final Set<String> tilesLoading = ConcurrentHashMap.newKeySet();
        final ConcurrentHashMap<String, Long> tileRetryAfter = new ConcurrentHashMap<>();
        final ConcurrentHashMap<String, Long> tileExpiries = new ConcurrentHashMap<>();
        final ExecutorService tileExecutor = Executors.newFixedThreadPool(3);
        volatile boolean cartoTilesUsed = false;
        volatile int tileFailures = 0;

        RideView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            p.setTypeface(TypefaceCompat.bold());
            p.setTextAlign(Paint.Align.LEFT);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
        }

        float dp(float v) { return v * density; }
        float minDp() { return Math.min(getWidth(), getHeight()) / density; }
        void txt(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align) {
            p.setTextSize(Math.max(10f, sizeDp) * density);
            p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
            c.drawText(s, x, y, p);
        }
        void panel(Canvas c, RectF r, int color, float radius) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(r, radius, radius, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.BLACK);
            if (mapExpanded) drawExpandedMap(c);
            else if (tripsScreen) drawTrips(c); else drawRide(c);
            postInvalidateDelayed(1000); // Keep the on-screen clock current.
        }

        String now() { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); }
        String gpsSummary() {
            Location l = engine.loc;
            if (l == null) return tr("GPS IN RICERCA");
            String acc = l.hasAccuracy() ? " ±" + Math.round(l.getAccuracy()) + "m" : "";
            if ("ip-approx".equals(l.getProvider()) || "saved-network".equals(l.getProvider())) return tr("POSIZIONE APPROSSIMATIVA") + acc;
            if (satellitesVisible > 0 && LocationManager.GPS_PROVIDER.equals(l.getProvider())) return "GPS " + satellitesUsed + "/" + satellitesVisible + " sat" + acc;
            if (!LocationManager.GPS_PROVIDER.equals(l.getProvider())) return tr("POSIZIONE RETE") + acc;
            return engine.gpsGood() ? tr("GPS OK") + acc : tr("GPS DEBOLE") + acc;
        }
        String roadSummary() {
            if (downloadingRoads) return tr("SCARICO STRADE…");
            if (engine.ways != null && !engine.ways.isEmpty()) return "STRADE " + engine.ways.size();
            if (!roadDownloadAttempted) return tr("DATI STRADALI IN ATTESA");
            return tr("DATI STRADALI NON DISPONIBILI");
        }
        void drawTopStatus(Canvas c) {
            int w = getWidth(); boolean land = w > getHeight();
            float barH = dp(land ? 34 : 50);
            panel(c, new RectF(0, 0, w, barH), 0xFF111820, 0);
            float fs = Math.max(10f, Math.min(15f, minDp() * .034f));
            int gpsColor = engine.gpsGood() ? green : 0xFFFFB84D;
            int roadColor = (downloadingRoads || (engine.mapWays != null && !engine.mapWays.isEmpty())) ? green : 0xFFFFB84D;
            if (land) {
                txt(c, now(), dp(10), dp(23), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w * .46f, dp(23), fs, gpsColor, Paint.Align.CENTER);
                String road = downloadingRoads ? tr("SCARICO STRADE…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "STRADE " + engine.mapWays.size() : tr("STRADE IN ATTESA"));
                txt(c, road, w - dp(10), dp(23), fs, roadColor, Paint.Align.RIGHT);
            } else {
                txt(c, now(), dp(10), dp(21), fs + 1, Color.WHITE, Paint.Align.LEFT);
                txt(c, gpsSummary(), w - dp(10), dp(21), fs, gpsColor, Paint.Align.RIGHT);
                String road = downloadingRoads ? tr("DOWNLOAD DATI STRADALI…") : (engine.mapWays != null && !engine.mapWays.isEmpty() ? "DATI STRADALI OK · " + engine.mapWays.size() + " STRADE" : tr("DATI STRADALI IN ATTESA"));
                txt(c, road, w / 2f, dp(42), Math.max(9f, fs - 1), roadColor, Paint.Align.CENTER);
            }
        }

        void drawDemoInfo(Canvas c, boolean land) {
            float y = dp(48), h = dp(29), w = getWidth();
            panel(c, new RectF(0, y, w, y + h), 0xFF111820, 0);
            float fs = Math.max(9f, Math.min(12f, minDp() * .030f));
            txt(c, now(), dp(9), y + dp(19), fs, Color.WHITE, Paint.Align.LEFT);
            txt(c, gpsSummary(), w * .48f, y + dp(19), fs, engine.gpsGood() ? green : 0xFFFFB84D, Paint.Align.CENTER);
            String roads = downloadingRoads ? "DOWNLOAD…" : (engine.ways != null && !engine.ways.isEmpty() ? "STRADE " + engine.ways.size() : tr("STRADE IN ATTESA"));
            txt(c, roads, w - dp(9), y + dp(19), fs, (downloadingRoads || (engine.ways != null && !engine.ways.isEmpty())) ? green : 0xFFFFB84D, Paint.Align.RIGHT);
        }

        void drawRide(Canvas c) {
            int w = getWidth(), h = getHeight();
            boolean land = w > h;
            Location l = engine.loc;
            Curve q = engine.current == null ? emptyCurve : engine.current;
            drawTopStatus(c);
            if (land) {
                float curveSize = Math.min(h * .22f, w * .105f);
                drawCurve(c, w * .15f, h * .32f, q, curveSize);
                drawSpeed(c, w * .49f, h * .58f, l == null ? 0 : speed(l), q.recommended, currentSpeedLimitKmh, true);
                drawRadarAlert(c, w * .15f, h * .18f, true);
                txt(c, String.format(Locale.US, "%.1f Km", dailyKm), w * .49f, h * .91f, 15, 0xFFB8C2CC, Paint.Align.CENTER);
                float mapW = Math.min(w * .31f, h * .78f);
                float mapH = Math.min(h * .70f, w * .29f);
                float mapCx = w * .82f, mapCy = h * .53f;
                mapBounds.set(mapCx - mapW / 2f, mapCy - mapH / 2f, mapCx + mapW / 2f, mapCy + mapH / 2f);
                drawRoadMap(c, mapBounds, l, false);
                drawGrade(c, w * .15f, h * .86f, q.grade, true);
            } else {
                float curveSize = Math.min(w * .30f, h * .092f);
                drawCurve(c, w * .5f, h * .125f, q, curveSize);
                drawSpeed(c, w * .5f, h * .48f, l == null ? 0 : speed(l), q.recommended, currentSpeedLimitKmh, false);
                drawRadarAlert(c, w * .82f, h * .125f, false);
                txt(c, String.format(Locale.US, "%.1f Km", dailyKm), w * .5f, h * .765f, 14, 0xFFB8C2CC, Paint.Align.CENTER);
                drawGrade(c, w * .15f, h * .62f, q.grade, false);
                float mapW = w * .88f;
                float mapH = h * .135f;
                float mapCy = h * .905f;
                mapBounds.set((w - mapW) / 2f, mapCy - mapH / 2f, (w + mapW) / 2f, mapCy + mapH / 2f);
                drawRoadMap(c, mapBounds, l, false);
            }
            float b = dp(10);
            float buttonTop = dp(land ? 39 : 54);
            tripsButtonBounds.set(w - dp(82), buttonTop, w - b, buttonTop + dp(26));
            panel(c, tripsButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); stroke.setStyle(Paint.Style.STROKE);
            c.drawRoundRect(tripsButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, "VIAGGI", tripsButtonBounds.centerX(), tripsButtonBounds.centerY() + dp(4), 10, yellow, Paint.Align.CENTER);
            weatherButtonBounds.set(dp(10), buttonTop, dp(78), buttonTop + dp(26));
            panel(c, weatherButtonBounds, 0xFF252A30, dp(7));
            stroke.setColor(0xFF7E8994); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(weatherButtonBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, weatherLoading ? tr("METEO…") : tr("METEO ↻"), weatherButtonBounds.centerX(), weatherButtonBounds.centerY() + dp(4), 10, 0xFF8ED7FF, Paint.Align.CENTER);
            txt(c, airTemperature, weatherButtonBounds.centerX(), weatherButtonBounds.bottom + dp(34), 64, 0xFFFFD66B, Paint.Align.CENTER);
            txt(c, weatherIcon(), weatherButtonBounds.right + dp(38), weatherButtonBounds.bottom + dp(34), 60, 0xFFFFD66B, Paint.Align.CENTER);
            if (weatherAdverse || (showWeatherDetails && !weatherDetail.isEmpty())) {
                float stripBottom = buttonTop + dp(land ? 26 : 38);
                float weatherInfoRight = weatherButtonBounds.right + dp(48);
                RectF weatherStrip = new RectF(weatherInfoRight, buttonTop,
                        Math.max(weatherInfoRight + dp(12), tripsButtonBounds.left - dp(5)), stripBottom);
                panel(c, weatherStrip, weatherAdverse ? 0xFFE00020 : 0xFF17212B, dp(4));
                String line1 = weatherAdverse ? "ATTENZIONE METEO" : weatherSummary;
                String line2 = weatherAdverse ? weatherDetail : weatherDetail;
                float bannerSize = Math.max(7f, Math.min(9f, minDp() * .021f));
                p.setTextSize(bannerSize * density);
                float maxText = Math.max(dp(20), weatherStrip.width() - dp(8));
                while (p.measureText(line1) > maxText && bannerSize > 7f) { bannerSize -= .5f; p.setTextSize(bannerSize * density); }
                if (p.measureText(line1) > maxText) line1 = "METEO";
                if (p.measureText(line2) > maxText) { while (line2.length() > 8 && p.measureText(line2) > maxText) line2 = line2.substring(0, line2.length()-2) + "…"; }
                if (land) txt(c, line1 + " · " + line2, weatherStrip.centerX(), weatherStrip.centerY() + dp(3), bannerSize, Color.WHITE, Paint.Align.CENTER);
                else {
                    float mid = weatherStrip.centerY();
                    txt(c, line1, weatherStrip.centerX(), mid - dp(3), bannerSize, Color.WHITE, Paint.Align.CENTER);
                    txt(c, line2, weatherStrip.centerX(), mid + dp(10), bannerSize, Color.WHITE, Paint.Align.CENTER);
                }
            }
            txt(c, tr("AUDIO ON"), dp(12), h - dp(10), 11, green, Paint.Align.LEFT);
        }

        void drawRoadMap(Canvas c, RectF bounds, Location location, boolean expanded) {
            float radius = dp(7);
            panel(c, bounds, 0xFF080C10, radius);
            c.save();
            Path clip = new Path(); clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
            c.clipPath(clip);
            boolean raster = drawRasterTiles(c, bounds, location, expanded);
            if (!raster) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(0.6f)); p.setColor(0xFF202A33);
                for (int i = 1; i < 4; i++) {
                    float x = bounds.left + bounds.width() * i / 4f;
                    float y = bounds.top + bounds.height() * i / 4f;
                    c.drawLine(x, bounds.top, x, bounds.bottom, p);
                    c.drawLine(bounds.left, y, bounds.right, y, p);
                }
                if (location != null && engine.mapWays != null && !engine.mapWays.isEmpty()) {
                    double lat0 = location.getLatitude(), lon0 = location.getLongitude();
                    double cosLat = Math.cos(Math.toRadians(lat0));
                    float bearing = hasMapBearing ? mapBearing : 0f;
                    double theta = Math.toRadians(bearing);
                    float scaleX = bounds.width() / 1000f, scaleY = bounds.height() / 1000f;
                    for (RoadWay way : engine.mapWays) {
                        if (way == null || way.pts == null || way.pts.size() < 2) continue;
                        Path road = new Path(); boolean started = false;
                        for (Geo point : way.pts) {
                            double east = (point.lon - lon0) * 111320.0 * cosLat;
                            double north = (point.lat - lat0) * 110540.0;
                            double eastRot = east * Math.cos(theta) - north * Math.sin(theta);
                            double northRot = east * Math.sin(theta) + north * Math.cos(theta);
                            float x = bounds.centerX() + (float)eastRot * scaleX + mapPanX;
                            float y = bounds.centerY() - (float)northRot * scaleY + mapPanY;
                            if (x < bounds.left - dp(10) || x > bounds.right + dp(10) || y < bounds.top - dp(10) || y > bounds.bottom + dp(10)) { started = false; continue; }
                            if (!started) { road.moveTo(x, y); started = true; } else road.lineTo(x, y);
                        }
                        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
                        p.setStrokeWidth(dp(3)); p.setColor(0xFF59636D); c.drawPath(road, p);
                        p.setStrokeWidth(dp(1.1f)); p.setColor(0xFFD5DDE4); c.drawPath(road, p);
                    }
                }
                String status = downloadingRoads ? tr("SCARICO STRADE…") :
                        (location == null ? tr("GPS IN RICERCA") : (!tilesLoading.isEmpty() ? tr("CARICAMENTO MAPPA…") :
                        (tileFailures > 0 ? tr("MAPPA NON DISPONIBILE") : (roadDataStatus.isEmpty() ? tr("MAPPA IN ATTESA") : roadDataStatus))));
                float statusSize = Math.max(8, Math.min(expanded ? 14 : 10, minDp() * .026f));
                txt(c, status, bounds.centerX(), bounds.bottom - dp(expanded ? 30 : 5), statusSize, 0xFFB8C2CC, Paint.Align.CENTER);
            }
            // Attribution is kept visible in both compact and expanded map views.
            String attribution = cartoTilesUsed ? "© OpenStreetMap contributors · © CARTO" : "© OpenStreetMap contributors";
            float attribSize = expanded ? 9f : 6.5f;
            p.setTextSize(attribSize * density);
            float attribWidth = p.measureText(attribution) + dp(6);
            RectF attrib = new RectF(bounds.right - attribWidth - dp(2), bounds.bottom - dp(expanded ? 21 : 13), bounds.right - dp(2), bounds.bottom - dp(2));
            panel(c, attrib, 0xD9000000, dp(2));
            txt(c, attribution, attrib.right - dp(3), attrib.bottom - dp(2), attribSize, Color.WHITE, Paint.Align.RIGHT);
            c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(Color.WHITE);
            c.drawRoundRect(bounds, radius, radius, p); p.setStyle(Paint.Style.FILL);
            // Fixed motorcycle marker: the map moves underneath it while panning.
            float markerSize = Math.min(bounds.width(), bounds.height()) * (expanded ? 0.045f : 0.10f);
            float bearingForMarker = hasMapBearing ? mapBearing : 0f;
            float panX = expanded ? mapPanX : 0f, panY = expanded ? mapPanY : 0f;
            float markerCx = bounds.centerX() + (float)(panX * Math.cos(Math.toRadians(bearingForMarker)) + panY * Math.sin(Math.toRadians(bearingForMarker)));
            float markerCy = bounds.centerY() + (float)(-panX * Math.sin(Math.toRadians(bearingForMarker)) + panY * Math.cos(Math.toRadians(bearingForMarker)));
            // GPS marker is a clean, outlined direction arrow without a square backing.
            c.save(); c.clipRect(bounds);
            Path bike = new Path(); bike.moveTo(markerCx, markerCy - markerSize * .72f);
            bike.lineTo(markerCx - markerSize * .46f, markerCy + markerSize * .48f);
            bike.lineTo(markerCx, markerCy + markerSize * .20f);
            bike.lineTo(markerCx + markerSize * .46f, markerCy + markerSize * .48f); bike.close();
            stroke.setStyle(Paint.Style.STROKE); stroke.setColor(Color.BLACK); stroke.setStrokeWidth(dp(expanded ? 3 : 2)); c.drawPath(bike, stroke);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFD400); c.drawPath(bike, p);
            c.restore();
            txt(c, expanded ? tr("MAPPA · TRASCINA PER SCORRERE") : tr("MAPPA"), bounds.centerX(), bounds.top + dp(expanded ? 23 : 13),
                    Math.max(8, Math.min(expanded ? 14 : 10, minDp() * .026f)), Color.WHITE, Paint.Align.CENTER);
            // Map zoom controls are deliberately small and kept inside the map frame.
            float zbtn = dp(expanded ? 42 : 28);
            RectF zin = new RectF(bounds.right-zbtn-dp(6), bounds.bottom-zbtn*2-dp(10), bounds.right-dp(6), bounds.bottom-zbtn-dp(10));
            RectF zout = new RectF(bounds.right-zbtn-dp(6), bounds.bottom-zbtn-dp(6), bounds.right-dp(6), bounds.bottom-dp(6));
            panel(c, zin, 0xCC18212A, dp(6)); panel(c, zout, 0xCC18212A, dp(6));
            txt(c, "+", zin.centerX(), zin.centerY()+dp(expanded?8:6), expanded?24:17, Color.WHITE, Paint.Align.CENTER);
            txt(c, "−", zout.centerX(), zout.centerY()+dp(expanded?6:5), expanded?24:17, Color.WHITE, Paint.Align.CENTER);
            if (location != null && !hasMapBearing) txt(c, tr("DIREZIONE IN ATTESA"), bounds.centerX(), bounds.bottom - dp(expanded ? 28 : 15),
                    Math.max(8, Math.min(10, minDp() * .024f)), 0xFFFFD400, Paint.Align.CENTER);
        }

        boolean drawRasterTiles(Canvas c, RectF bounds, Location location, boolean expanded) {
            if (location == null) return false;
            final int zoom = expanded ? Math.max(15, Math.min(19, 17 + Math.round((mapZoom - 1.0f) * 3f))) : Math.max(16, Math.min(19, 18 + Math.round((mapZoomCompact - 1.0f) * 2f)));
            double lat = Math.max(-85.0, Math.min(85.0, location.getLatitude()));
            double lon = location.getLongitude();
            // Re-anchor raster tiles only after meaningful movement. The marker remains GPS-driven,
            // while the tile grid is stable between anchors to prevent visible tile flicker.
            if (Double.isNaN(mapAnchorLat) || mapAnchorLocation == null || mapAnchorLocation.distanceTo(location) >= 40f || System.currentTimeMillis() - lastTileAnchorUpdate > 30000L) {
                mapAnchorLat = lat; mapAnchorLon = lon; mapAnchorLocation = new Location(location); lastTileAnchorUpdate = System.currentTimeMillis();
            }
            lat = mapAnchorLat; lon = mapAnchorLon;
            double world = 256.0 * (1 << zoom);
            double centerX = (lon + 180.0) / 360.0 * world;
            double sin = Math.sin(Math.toRadians(lat));
            double centerY = (0.5 - Math.log((1.0 + sin) / (1.0 - sin)) / (4.0 * Math.PI)) * world;
            double metersPerWorldPixel = Math.cos(Math.toRadians(lat)) * 2.0 * Math.PI * 6378137.0 / world;
            float scale = expanded ? 1.0f : 1.15f;
            if (scale <= 0f) return false;
            double targetX = centerX - mapPanX / scale;
            double targetY = centerY + mapPanY / scale;
            double halfX = bounds.width() / (2.0 * scale), halfY = bounds.height() / (2.0 * scale);
            int tileCount = 1 << zoom;
            int minX = (int)Math.floor((targetX - halfX) / 256.0) - 1;
            int maxX = (int)Math.floor((targetX + halfX) / 256.0) + 1;
            int minY = Math.max(0, (int)Math.floor((targetY - halfY) / 256.0) - 1);
            int maxY = Math.min(tileCount - 1, (int)Math.floor((targetY + halfY) / 256.0) + 1);
            boolean any = false;
            c.save();
            c.translate(bounds.centerX(), bounds.centerY());
            c.rotate(-(hasMapBearing ? mapBearing : 0f));
            c.translate(mapPanX, mapPanY);
            p.setStyle(Paint.Style.FILL);
            for (int tx = minX; tx <= maxX; tx++) {
                int wrappedX = ((tx % tileCount) + tileCount) % tileCount;
                for (int ty = minY; ty <= maxY; ty++) {
                    String key = zoom + "/" + wrappedX + "/" + ty;
                    Bitmap bitmap = tileBitmaps.get(key);
                    if (bitmap == null || bitmap.isRecycled()) {
                        float missingLeft = (float)(tx * 256.0 - centerX) * scale;
                        float missingTop = (float)(ty * 256.0 - centerY) * scale;
                        RectF missingRect = new RectF(missingLeft, missingTop, missingLeft + 256f * scale, missingTop + 256f * scale);
                        // Never flash a black tile while a sharper tile is downloading.
                        // Request the child and draw the best cached ancestor instead.
                        requestTile(zoom, wrappedX, ty, key);
                        bitmap = drawParentTile(c, zoom, wrappedX, ty, tx, centerX, centerY, scale);
                        if (bitmap != null) any = true;
                        continue;
                    }
                    if (isTileStale(zoom, wrappedX, ty)) {
                        Long retryAt = tileRetryAfter.get(key);
                        if (retryAt == null || System.currentTimeMillis() >= retryAt) requestTile(zoom, wrappedX, ty, key);
                    }
                    float left = (float)(tx * 256.0 - centerX) * scale;
                    float top = (float)(ty * 256.0 - centerY) * scale;
                    RectF dest = new RectF(left, top, left + 256f * scale, top + 256f * scale);
                    c.drawBitmap(bitmap, null, dest, p); any = true;
                }
            }
            c.restore();
            return any;
        }

        File tileDirectory() {
            File dir = new File(getContext().getFilesDir(), "maptiles");
            if (!dir.exists()) dir.mkdirs();
            return dir;
        }

        File tileImageFile(int z, int x, int y) { return new File(tileDirectory(), z + "_" + x + "_" + y + ".png"); }
        File tileExpiryFile(int z, int x, int y) { return new File(tileDirectory(), z + "_" + x + "_" + y + ".exp"); }

        boolean isTileStale(int z, int x, int y) {
            Long expiry = tileExpiries.get(z + "/" + x + "/" + y);
            return expiry != null && expiry <= System.currentTimeMillis();
        }

        // Draw a parent tile quadrant while the sharper child tile downloads, avoiding black squares.
        Bitmap drawParentTile(Canvas c, int z, int x, int y, int wrappedX, double centerX, double centerY, float scale) {
            for (int level = z - 1; level >= Math.max(1, z - 4); level--) {
                int shift = z - level;
                int px = x >> shift, py = y >> shift;
                int parentCount = 1 << level;
                px = ((px % parentCount) + parentCount) % parentCount;
                if (py < 0 || py >= parentCount) continue;
                String parentKey = level + "/" + px + "/" + py;
                Bitmap parent = tileBitmaps.get(parentKey);
                if (parent == null || parent.isRecycled()) { requestTile(level, px, py, parentKey); continue; }
                int quadrant = 1 << shift;
                int srcSize = 256 / quadrant;
                int sx = (x & (quadrant - 1)) * srcSize, sy = (y & (quadrant - 1)) * srcSize;
                android.graphics.Rect src = new android.graphics.Rect(sx, sy, sx + srcSize, sy + srcSize);
                float left = (float)(wrappedX * 256.0 - centerX) * scale;
                float top = (float)(y * 256.0 - centerY) * scale;
                RectF dest = new RectF(left, top, left + 256f * scale, top + 256f * scale);
                c.drawBitmap(parent, src, dest, p);
                return parent;
            }
            return null;
        }

        void requestTile(int z, int x, int y, String key) {
            if (!tilesLoading.add(key)) return;
            Long retry = tileRetryAfter.get(key);
            if (retry != null && System.currentTimeMillis() < retry && tileBitmaps.get(key) != null) { tilesLoading.remove(key); return; }
            tileExecutor.execute(() -> {
                try {
                    File dir = tileDirectory();
                    String safe = z + "_" + x + "_" + y;
                    File imageFile = new File(dir, safe + ".png"), expiryFile = new File(dir, safe + ".exp");
                    // Migrate a previously cached tile lazily on the worker thread, never during drawing.
                    File legacyImage = new File(new File(getContext().getCacheDir(), "maptiles"), safe + ".png");
                    File legacyExpiry = new File(new File(getContext().getCacheDir(), "maptiles"), safe + ".exp");
                    if (!imageFile.exists() && legacyImage.isFile()) {
                        try (InputStream in = new java.io.FileInputStream(legacyImage); FileOutputStream out = new FileOutputStream(imageFile)) {
                            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                            if (legacyExpiry.isFile()) try (InputStream ei = new java.io.FileInputStream(legacyExpiry); FileOutputStream eo = new FileOutputStream(expiryFile)) { while ((n = ei.read(buffer)) > 0) eo.write(buffer, 0, n); }
                        } catch (Exception ignored) { }
                    }
                    long expiry = 0L;
                    if (expiryFile.exists()) try { expiry = Long.parseLong(new String(java.nio.file.Files.readAllBytes(expiryFile.toPath()), "UTF-8").trim()); } catch (Exception ignored) { }
                    if (imageFile.exists() && expiry == 0L) expiry = imageFile.lastModified() + 7L * 86400000L;
                    if (imageFile.exists()) tileExpiries.put(key, expiry);
                    boolean fresh = imageFile.exists() && expiry > System.currentTimeMillis();
                    if (imageFile.exists()) {
                        Bitmap cached = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                        if (cached != null) tileBitmaps.put(key, cached);
                    }
                    if (fresh) return; // Keep the on-disk tile and avoid needless requests.
                    String[] urls = {
                        "https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png",
                        "https://basemaps.cartocdn.com/dark_all/" + z + "/" + x + "/" + y + ".png",
                        "https://basemaps.cartocdn.com/rastertiles/voyager/" + z + "/" + x + "/" + y + ".png"
                    };
                    for (int provider = 0; provider < urls.length; provider++) {
                        HttpURLConnection conn = null;
                        try {
                            conn = (HttpURLConnection)new URL(urls[provider]).openConnection();
                            conn.setConnectTimeout(7000); conn.setReadTimeout(10000);
                            conn.setRequestMethod("GET");
                            conn.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.9.0 (Android map display)");
                            conn.setRequestProperty("Accept", "image/png,image/*;q=0.8,*/*;q=0.5");
                            int code = conn.getResponseCode();
                            if (code != HttpURLConnection.HTTP_OK) continue;
                            byte[] bytes;
                            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                                byte[] buffer = new byte[8192]; int n;
                                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                                bytes = out.toByteArray();
                            }
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            if (bitmap == null) continue;
                            try (FileOutputStream out = new FileOutputStream(imageFile)) { out.write(bytes); }
                            long maxAge = 7L * 86400L;
                            String cacheControl = conn.getHeaderField("Cache-Control");
                            if (cacheControl != null) {
                                Matcher matcher = Pattern.compile("max-age\\s*=\\s*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(cacheControl);
                                if (matcher.find()) try { maxAge = Math.max(60L, Long.parseLong(matcher.group(1))); } catch (Exception ignored) { }
                            }
                            long tileExpiry = System.currentTimeMillis() + maxAge * 1000L;
                            try (FileOutputStream out = new FileOutputStream(expiryFile)) { out.write(Long.toString(tileExpiry).getBytes("UTF-8")); }
                            tileExpiries.put(key, tileExpiry);
                            tileBitmaps.put(key, bitmap);
                            if (provider == 1) cartoTilesUsed = true;
                            tileFailures = Math.max(0, tileFailures - 1);
                            tileRetryAfter.remove(key);
                            return;
                        } catch (Exception ignored) { }
                        finally { if (conn != null) conn.disconnect(); }
                    }
                    tileFailures++;
                    tileRetryAfter.put(key, System.currentTimeMillis() + 60000L);
                } finally {
                    tilesLoading.remove(key);
                    postInvalidate();
                }
            });
        }

        void releaseTiles() {
            tileExecutor.shutdownNow();
            tileBitmaps.evictAll();
        }


        void drawTrips(Canvas c) {
            int w=getWidth(), h=getHeight(); c.drawColor(0xFF070A0D);
            panel(c, new RectF(0,0,w,dp(56)), 0xFF141B22, 0);
            txt(c, "VIAGGI", dp(16), dp(35), 22, yellow, Paint.Align.LEFT);
            tripsCloseBounds.set(w-dp(92),dp(8),w-dp(8),dp(46)); panel(c,tripsCloseBounds,0xFF26313A,dp(8));
            txt(c,"← RIDE",tripsCloseBounds.centerX(),tripsCloseBounds.centerY()+dp(5),13,Color.WHITE,Paint.Align.CENTER);
            java.text.SimpleDateFormat monthFmt=new java.text.SimpleDateFormat("MMMM yyyy",Locale.getDefault());
            String monthTitle=monthFmt.format(new Date());
            android.content.SharedPreferences prefs=getSharedPreferences("road_display",MODE_PRIVATE);
            double month=0,year=0; java.util.TreeMap<String,Double> days=new java.util.TreeMap<>();
            java.text.SimpleDateFormat iso=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);
            String today=iso.format(new Date());
            try { java.util.Calendar cursor=java.util.Calendar.getInstance(); cursor.setTime(iso.parse(today)); java.util.Calendar first=java.util.Calendar.getInstance(); first.setTime(iso.parse(installDate));
                while(!cursor.before(first)) { String date=iso.format(cursor.getTime()); double km=Double.longBitsToDouble(prefs.getLong("trip_"+date,Double.doubleToLongBits(0.0))); days.put(date,km); if(date.startsWith(new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date())))month+=km; if(date.startsWith(new SimpleDateFormat("yyyy",Locale.US).format(new Date())))year+=km; cursor.add(java.util.Calendar.DAY_OF_MONTH,-1); }
            } catch(Exception ignored) {}
            float y=dp(82); txt(c,monthTitle,dp(16),y,20,Color.WHITE,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"MESE  %.1f Km",month),dp(16),y+dp(29),16,yellow,Paint.Align.LEFT);
            txt(c,String.format(Locale.getDefault(),"ANNO  %.1f Km",year),w-dp(16),y+dp(29),16,0xFF65D7FF,Paint.Align.RIGHT);
            txt(c,"Dal " + installDate,dp(16),y+dp(52),12,0xFF9AA3AD,Paint.Align.LEFT);
            java.util.TreeMap<String,Double> monthTotals=new java.util.TreeMap<>(), yearTotals=new java.util.TreeMap<>();
            for(java.util.Map.Entry<String,Double> e:days.entrySet()) { String d=e.getKey(); String ym=d.substring(0,7), yr=d.substring(0,4); monthTotals.put(ym,monthTotals.getOrDefault(ym,0.0)+e.getValue()); yearTotals.put(yr,yearTotals.getOrDefault(yr,0.0)+e.getValue()); }
            ArrayList<String> rows=new ArrayList<>(); String previousYear="", previousMonth="";
            for(String date:days.descendingKeySet()) { String yr=date.substring(0,4), ym=date.substring(0,7); if(!yr.equals(previousYear)){rows.add("Y|"+yr);previousYear=yr;previousMonth="";} if(!ym.equals(previousMonth)){rows.add("M|"+ym);previousMonth=ym;} rows.add("D|"+date); }
            float listTop=y+dp(72), rowH=dp(31), bottom=h-dp(12);
            c.save(); c.clipRect(0,listTop,w,bottom);
            for(int i=0;i<rows.size();i++) { String row=rows.get(i); float yy=listTop+i*rowH-tripsScroll; if(yy<listTop-rowH||yy>bottom)continue;
                boolean header=!row.startsWith("D|"); int bg=row.startsWith("Y|")?0xFF26313A:row.startsWith("M|")?0xFF1B2731:0xFF10161C;
                panel(c,new RectF(dp(10),yy,w-dp(10),yy+rowH-dp(2)),bg,dp(5));
                if(row.startsWith("Y|")){String yr=row.substring(2);txt(c,"ANNO "+yr,dp(20),yy+dp(20),13,0xFF65D7FF,Paint.Align.LEFT);txt(c,String.format(Locale.getDefault(),"%.1f Km",yearTotals.getOrDefault(yr,0.0)),w-dp(20),yy+dp(20),14,0xFF65D7FF,Paint.Align.RIGHT);}
                else if(row.startsWith("M|")){String ym=row.substring(2);String label=ym;try{label=new java.text.SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(new java.text.SimpleDateFormat("yyyy-MM",Locale.US).parse(ym));}catch(Exception ignored){}txt(c,label,dp(20),yy+dp(20),13,yellow,Paint.Align.LEFT);txt(c,String.format(Locale.getDefault(),"%.1f Km",monthTotals.getOrDefault(ym,0.0)),w-dp(20),yy+dp(20),14,yellow,Paint.Align.RIGHT);}
                else {String date=row.substring(2);txt(c,date,dp(20),yy+dp(20),13,Color.WHITE,Paint.Align.LEFT);txt(c,String.format(Locale.getDefault(),"%.1f Km",days.get(date)),w-dp(20),yy+dp(20),14,Color.WHITE,Paint.Align.RIGHT);}
            }
            c.restore();
            if(rows.isEmpty()) txt(c,"I chilometri appariranno qui durante i viaggi con GPS attivo.",w/2f,h*.58f,14,0xFF9AA3AD,Paint.Align.CENTER);
            txt(c,"Scorri l’elenco per consultare i giorni precedenti",w/2f,h-dp(8),10,0xFF7E8994,Paint.Align.CENTER);
        }

        void drawExpandedMap(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(0xFF05080B);
            RectF full = new RectF(dp(8), dp(8), w - dp(8), h - dp(8));
            mapBounds.set(full);
            drawRoadMap(c, full, engine.loc, true);
            mapCloseBounds.set(w - dp(76), dp(8), w - dp(8), dp(42));
            panel(c, mapCloseBounds, 0xFF202A33, dp(7));
            stroke.setColor(Color.WHITE); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            c.drawRoundRect(mapCloseBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, tr("CHIUDI ✕"), mapCloseBounds.centerX(), mapCloseBounds.centerY() + dp(5), 12, Color.WHITE, Paint.Align.CENTER);
            mapRecenterBounds.set(dp(8), dp(8), dp(116), dp(42));
            panel(c, mapRecenterBounds, 0xFF202A33, dp(7));
            stroke.setColor(Color.WHITE); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(mapRecenterBounds, dp(7), dp(7), stroke); stroke.setStyle(Paint.Style.FILL);
            txt(c, tr("RICENTRA GPS"), mapRecenterBounds.centerX(), mapRecenterBounds.centerY() + dp(5), 11, yellow, Paint.Align.CENTER);
        }

        float speed(Location l) { return l.hasSpeed() ? l.getSpeed() * 3.6f : 0f; }
        String fmtDist(float d) { return d < 1000 ? Math.round(d) + " m" : String.format(Locale.US, "%.1f km", d / 1000f); }

        void drawSpeed(Canvas c, float cx, float baseY, float s, float rec, int speedLimit, boolean land) {
            float numberHeight = land ? Math.min(118f, minDp()*.30f) : Math.min(142f, minDp()*.36f);
            String digits = Integer.toString(Math.max(0,Math.round(s)));
            android.content.SharedPreferences prefs=getSharedPreferences("road_display",MODE_PRIVATE);
            int yellowAt=prefs.getInt("speed_yellow",90), redAt=prefs.getInt("speed_red",120);
            boolean overLimit=speedLimit>0 && s>speedLimit;
            int fill=overLimit?Color.RED:(s>=redAt?Color.RED:(s>=yellowAt?0xFFFFD400:Color.WHITE));
            int border=overLimit?Color.WHITE:(s>=redAt?Color.WHITE:(s>=yellowAt?0xFFFF8A00:0xFF101010));
            float digitWidth=numberHeight*.58f, gap=numberHeight*.11f;
            float total=digits.length()*digitWidth+(digits.length()-1)*gap;
            float left=cx-total/2f;
            for(int i=0;i<digits.length();i++) drawSevenDigit(c,left+i*(digitWidth+gap)+digitWidth/2f,baseY,numberHeight,digits.charAt(i),fill,border);
            float unitY=baseY+numberHeight*.53f;
            txt(c,"km/h",cx,unitY,land?18:19,Color.WHITE,Paint.Align.CENTER);
            if(speedLimit>0){String lt=Integer.toString(speedLimit);txtOutlined(c,"LIMITE "+lt,cx,baseY-numberHeight*.72f,land?17:18,Color.RED,Color.WHITE,dp(2));}
            if(rec>0){txt(c,tr("CONSIGLIATA"),cx,baseY+numberHeight*.70f,land?11:12,yellow,Paint.Align.CENTER);txt(c,Math.round(rec)+" km/h",cx,baseY+numberHeight*.86f,land?17:18,yellow,Paint.Align.CENTER);}
            speedBounds.set(cx-total/2f-dp(18),baseY-numberHeight*.92f,cx+total/2f+dp(18),baseY+numberHeight*.92f);
        }

        void drawSevenDigit(Canvas c,float cx,float baseline,float h,char digit,int fill,int border){
            int mask; switch(digit){case '0':mask=0x3F;break;case '1':mask=0x06;break;case '2':mask=0x5B;break;case '3':mask=0x4F;break;case '4':mask=0x66;break;case '5':mask=0x6D;break;case '6':mask=0x7D;break;case '7':mask=0x07;break;case '8':mask=0x7F;break;case '9':mask=0x6F;break;default:mask=0;break;}
            float w=h*.58f, t=Math.max(dp(4),h*.085f), x=cx-w/2f, top=baseline-h*.78f, bottom=baseline+h*.12f, mid=(top+bottom)/2f, inset=t*.8f;
            float[][] seg={{x+inset,top,x+w-inset,top},{x+w-inset,top+inset,x+w-inset,mid-inset},{x+w-inset,mid+inset,x+w-inset,bottom-inset},{x+inset,bottom,x+w-inset,bottom},{x+inset,mid+inset,x+inset,bottom-inset},{x+inset,top+inset,x+inset,mid-inset},{x+inset,mid,x+w-inset,mid}};
            for(int i=0;i<7;i++)if((mask&(1<<i))!=0){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);stroke.setStrokeWidth(t+dp(2));stroke.setColor(border);c.drawLine(seg[i][0],seg[i][1],seg[i][2],seg[i][3],stroke);stroke.setStrokeWidth(t);stroke.setColor(fill);c.drawLine(seg[i][0],seg[i][1],seg[i][2],seg[i][3],stroke);}
        }

        void txtOutlined(Canvas c,String text,float x,float y,float size,int fill,int outline,float ow){p.setTypeface(TypefaceCompat.bold());p.setTextSize(size*density);p.setTextAlign(Paint.Align.CENTER);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(ow);p.setColor(outline);c.drawText(text,x,y,p);p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawText(text,x,y,p);}

        void drawGrade(Canvas c, float cx, float y, float g, boolean land) {
            String s = (g > 0 ? "▲ +" : g < 0 ? "▼ " : "— ") + Math.round(g) + "%";
            txt(c, s, cx, y, land ? 20 : 23, g > 0 ? green : g < 0 ? blue : Color.WHITE, Paint.Align.CENTER);
        }

        void drawCurve(Canvas c, float cx, float cy, Curve q, float sz) {
            if (q == null || !q.valid) {
                txt(c, "—", cx, cy + dp(12), Math.max(32, sz / density * .62f), 0xFF6B737B, Paint.Align.CENTER);
                txt(c, tr("NESSUNA CURVA RILEVATA"), cx, cy + sz * .82f,
                        Math.max(11, Math.min(15, sz / density * .13f)), 0xFF9AA3AD, Paint.Align.CENTER);
                return;
            }
            boolean left = q.dir < 0;
            int curveColor = q.type == 1 ? 0xFF35D66F : q.type == 2 ? 0xFFFFD400 : 0xFFF04438;
            float sign = left ? -1f : 1f;
            float half = sz * .70f;
            if (q.type == 1) {
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF07130B);
                c.drawCircle(cx, cy, half, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawCircle(cx, cy, half, stroke);
            } else if (q.type == 2) {
                RectF square = new RectF(cx - half, cy - half, cx + half, cy + half);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF171300); c.drawRoundRect(square, dp(5), dp(5), p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .075f));
                c.drawRoundRect(square, dp(5), dp(5), stroke);
            } else {
                Path triangle = new Path();
                triangle.moveTo(cx, cy - sz * .86f);
                triangle.lineTo(cx - sz * .88f, cy + sz * .68f);
                triangle.lineTo(cx + sz * .88f, cy + sz * .68f);
                triangle.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF050608); c.drawPath(triangle, p);
                stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeJoin(Paint.Join.ROUND);
                stroke.setColor(yellow); stroke.setStrokeWidth(Math.max(dp(3), sz * .085f)); c.drawPath(triangle, stroke);
                Path inner = new Path();
                inner.moveTo(cx, cy - sz * .76f);
                inner.lineTo(cx - sz * .76f, cy + sz * .61f);
                inner.lineTo(cx + sz * .76f, cy + sz * .61f);
                inner.close();
                stroke.setColor(0xFFF04438); stroke.setStrokeWidth(Math.max(dp(1.8f), sz * .028f)); c.drawPath(inner, stroke);
            }

            Path path = new Path();
            if (q.type == 4) {
                // Compact U-turn entirely inside the warning triangle.
                path.moveTo(cx + sign * sz * .27f, cy + sz * .37f);
                path.cubicTo(cx + sign * sz * .48f, cy + sz * .14f, cx + sign * sz * .42f, cy - sz * .22f, cx, cy - sz * .25f);
                path.cubicTo(cx - sign * sz * .42f, cy - sz * .26f, cx - sign * sz * .39f, cy + sz * .10f, cx - sign * sz * .17f, cy + sz * .15f);
            } else {
                path.moveTo(cx + sign * sz * .30f, cy + sz * .36f);
                path.cubicTo(cx + sign * sz * .08f, cy + sz * .26f, cx + sign * sz * .07f, cy - sz * .08f, cx + sign * sz * .31f, cy - sz * .20f);
                path.cubicTo(cx + sign * sz * .47f, cy - sz * .28f, cx + sign * sz * .47f, cy - sz * .39f, cx + sign * sz * .36f, cy - sz * .46f);
            }
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .16f)); c.drawPath(path, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(3), sz * .105f)); c.drawPath(path, stroke);
            // Arrowhead at the end of the path, kept inside each category's frame.
            float ex = cx + sign * sz * (q.type == 4 ? -.17f : .36f);
            float ey = cy - sz * (q.type == 4 ? -.15f : .46f);
            Path arrow = new Path();
            arrow.moveTo(ex - sign * sz * .15f, ey + sz * .03f);
            arrow.lineTo(ex, ey - sz * .10f);
            arrow.lineTo(ex + sign * sz * .15f, ey + sz * .03f);
            stroke.setColor(Color.BLACK); stroke.setStrokeWidth(Math.max(dp(4), sz * .09f)); c.drawPath(arrow, stroke);
            stroke.setColor(curveColor); stroke.setStrokeWidth(Math.max(dp(2.5f), sz * .055f)); c.drawPath(arrow, stroke);

            if (q.type == 3) {
                // Two large warning marks flanking the red curve inside the triangle.
                txt(c, "!", cx - sz * .49f, cy + sz * .28f, Math.max(30, sz / density * .48f), Color.WHITE, Paint.Align.CENTER);
                txt(c, "!", cx + sz * .49f, cy + sz * .28f, Math.max(30, sz / density * .48f), Color.WHITE, Paint.Align.CENTER);
            } else if (q.type == 4) {
                txt(c, "!", cx, cy - sz * .40f, Math.max(34, sz / density * .52f), Color.WHITE, Paint.Align.CENTER);
            }
            txt(c, tr(q.label == null ? "CURVA" : q.label), cx, cy + sz * 1.02f,
                    Math.max(13, Math.min(21, sz / density * .18f)), curveColor, Paint.Align.CENTER);
            txt(c, fmtDist(q.distance), cx, cy + sz * 1.24f,
                    Math.max(18, Math.min(29, sz / density * .23f)), yellow, Paint.Align.CENTER);
            txt(c, tr(left ? "SINISTRA" : "DESTRA"), cx, cy + sz * 1.43f,
                    Math.max(10, Math.min(15, sz / density * .12f)), 0xFFE0E5EA, Paint.Align.CENTER);
        }

        RectF boundsForZoom(boolean expanded, boolean plus) {
            float zbtn = dp(expanded ? 42 : 28);
            if (plus) return new RectF(mapBounds.right-zbtn-dp(6), mapBounds.bottom-zbtn*2-dp(10), mapBounds.right-dp(6), mapBounds.bottom-zbtn-dp(10));
            return new RectF(mapBounds.right-zbtn-dp(6), mapBounds.bottom-zbtn-dp(6), mapBounds.right-dp(6), mapBounds.bottom-dp(6));
        }
        boolean mapZoomButton(RectF r,float x,float y){return r.contains(x,y);}

        void showSpeedSettings() {
            android.content.SharedPreferences prefs=getSharedPreferences("road_display",MODE_PRIVATE);
            final android.widget.LinearLayout box=new android.widget.LinearLayout(MainActivity.this); box.setOrientation(android.widget.LinearLayout.VERTICAL); box.setPadding((int)dp(20),(int)dp(8),(int)dp(20),0);
            final android.widget.EditText e1=new android.widget.EditText(MainActivity.this); e1.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e1.setHint("Giallo da km/h"); e1.setText(Integer.toString(prefs.getInt("speed_yellow",90)));
            final android.widget.EditText e2=new android.widget.EditText(MainActivity.this); e2.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e2.setHint("Rosso da km/h"); e2.setText(Integer.toString(prefs.getInt("speed_red",120)));
            box.addView(e1); box.addView(e2);
            new android.app.AlertDialog.Builder(MainActivity.this).setTitle("COLORI VELOCITÀ").setMessage("Imposta le soglie del display. Il limite stradale, quando disponibile, ha sempre priorità.").setView(box).setNegativeButton("ANNULLA",null).setPositiveButton("SALVA",(d,w)->{try{int y=Integer.parseInt(e1.getText().toString());int r=Integer.parseInt(e2.getText().toString());if(y<1)y=90;if(r<=y)r=y+1;if(r>250)r=250;prefs.edit().putInt("speed_yellow",y).putInt("speed_red",r).apply();invalidate();}catch(Exception ignored){}}).show();
        }

        void drawRadarAlert(Canvas c,float cx,float cy,boolean land){
            long left=radarAlertUntil-System.currentTimeMillis(); if(left<=0) return;
            boolean flash=((System.currentTimeMillis()/500L)&1L)==0L;
            if (flash) {
                float sz=land?dp(54):dp(50); Path t=new Path();t.moveTo(cx,cy-sz*.5f);t.lineTo(cx-sz*.5f,cy+sz*.4f);t.lineTo(cx+sz*.5f,cy+sz*.4f);t.close();p.setStyle(Paint.Style.FILL);p.setColor(Color.RED);c.drawPath(t,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(dp(2));stroke.setColor(Color.WHITE);c.drawPath(t,stroke);txt(c,"RADAR",cx,cy+dp(6),land?10:9,Color.WHITE,Paint.Align.CENTER);
            }
            postInvalidateDelayed(250);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            if (e.getPointerCount() >= 2 && mapBounds.contains(e.getX(), e.getY())) {
                float dx=e.getX(0)-e.getX(1), dy=e.getY(0)-e.getY(1);
                float distance=(float)Math.hypot(dx,dy);
                if (e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN || pinchStartDistance==0f) { pinchStartDistance=distance; pinchCompact=!mapExpanded; pinchStartZoom=pinchCompact?mapZoomCompact:mapZoom; pinching=true; }
                else if (e.getActionMasked()==MotionEvent.ACTION_MOVE && pinchStartDistance>0f) { float z=pinchStartZoom*distance/pinchStartDistance; if(pinchCompact) mapZoomCompact=Math.max(0.8f,Math.min(1.5f,z)); else mapZoom=Math.max(0.5f,Math.min(1.7f,z)); invalidate(); }
                return true;
            }
            if (e.getActionMasked()==MotionEvent.ACTION_POINTER_UP) { pinchStartDistance=0f; pinching=false; pinchCompact=false; return true; }
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = x; downY = y; downPanX = mapPanX; downPanY = mapPanY; movedMap = false;
                draggingMap = mapExpanded; pinchStartDistance=0f; pinching=false; pinchCompact=false;
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (mapExpanded && draggingMap) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.abs(dx) + Math.abs(dy) > dp(5)) movedMap = true;
                    mapPanX = downPanX + dx; mapPanY = downPanY + dy;
                    invalidate();
                }
                return true;
            }
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            if (tripsScreen) { if (tripsCloseBounds.contains(x,y)) { tripsScreen=false; invalidate(); } else if (Math.abs(y-downY)>dp(8)) { tripsScroll=Math.max(0f,tripsScroll+(downY-y)); invalidate(); } return true; }
            if (mapExpanded) {
                draggingMap = false;
                if (!movedMap && mapCloseBounds.contains(x, y)) { mapExpanded = false; mapPanX = 0; mapPanY = 0; invalidate(); }
                else if (!movedMap && mapRecenterBounds.contains(x, y)) { mapPanX = 0; mapPanY = 0; mapAnchorLat = Double.NaN; mapAnchorLocation = null; invalidate(); }
                else if (!movedMap && mapZoomButton(boundsForZoom(true, true), x, y)) { mapZoom = Math.min(1.7f, mapZoom + 0.2f); invalidate(); }
                else if (!movedMap && mapZoomButton(boundsForZoom(true, false), x, y)) { mapZoom = Math.max(0.5f, mapZoom - 0.2f); invalidate(); }
                return true;
            }
            {
                if (speedBounds.contains(x, y)) { showSpeedSettings(); return true; }
                if (weatherButtonBounds.contains(x, y)) {
                    showWeatherDetails = !showWeatherDetails;
                    if (engine.loc != null) maybeUpdateWeather(engine.loc, true);
                    invalidate(); return true;
                }
                if (mapBounds.contains(x, y)) {
                    if (mapZoomButton(boundsForZoom(false, true), x, y)) { mapZoomCompact = Math.min(1.5f, mapZoomCompact + 0.2f); invalidate(); return true; }
                    if (mapZoomButton(boundsForZoom(false, false), x, y)) { mapZoomCompact = Math.max(0.8f, mapZoomCompact - 0.2f); invalidate(); return true; }
                    mapExpanded = true; mapPanX = 0; mapPanY = 0; mapAnchorLat = Double.NaN; mapAnchorLocation = null; invalidate(); return true;
                }
                if (tripsButtonBounds.contains(x, y)) { tripsScreen=true; tripsScroll=0f; invalidate(); return true; }
                return true;
            }
        }


    }

    // Keeps typography consistent without depending on downloaded fonts.
    static class TypefaceCompat {
        static android.graphics.Typeface bold() { return android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); }
    }
}
