package com.riccardo.roaddisplay;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.location.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;

public class MainActivity extends Activity {
    static final int REQ_LOC=42;
    RideView view; LocationManager lm; LocationListener listener; RoadDb db; RoadEngine engine; ToneGenerator tone;
    boolean audio=false, demo=false; long lastOnline=0;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); immersive();
        db=new RoadDb(this); engine=new RoadEngine(db); tone=new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
        view=new RideView(this); setContentView(view); requestLocation();
    }
    void immersive(){ getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
    void requestLocation(){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOC);return;} startGps(); }
    void startGps(){ if(lm!=null)return; lm=(LocationManager)getSystemService(LOCATION_SERVICE); listener=new LocationListener(){public void onLocationChanged(Location l){ boolean warn=engine.update(l); if(warn){ if(engine.current.type==4) beep(2,true); else beep(engine.current.type,false); } view.invalidate(); if(!demo && l.getAccuracy()<80 && System.currentTimeMillis()-lastOnline>20000){ lastOnline=System.currentTimeMillis(); new Thread(()->engine.fetchOnline(l)).start(); }} public void onProviderEnabled(String p){view.invalidate();} public void onProviderDisabled(String p){view.invalidate();} public void onStatusChanged(String p,int s,Bundle e){}}; try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,1,listener,Looper.getMainLooper());}catch(Exception e){} }
    void beep(int n, boolean longFirst){ if(!audio)return; new Thread(()->{try{if(longFirst){tone.startTone(ToneGenerator.TONE_PROP_BEEP2,520);Thread.sleep(180);}for(int i=0;i<n;i++){tone.startTone(ToneGenerator.TONE_PROP_BEEP,120);Thread.sleep(130);}}catch(Exception e){}}).start(); }
    void enableAudio(){audio=true; view.invalidate();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_LOC && g!=null && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED)startGps();}
    @Override public void onBackPressed(){
        if(demo){ demo=false; if(view!=null)view.invalidate(); }
        else { super.onBackPressed(); }
    }
    @Override protected void onDestroy(){if(lm!=null)lm.removeUpdates(listener);tone.release();db.close();super.onDestroy();}

    class RideView extends View {
        Paint p=new Paint(3); Paint stroke=new Paint(3); Curve c=new Curve(); float demoSpeed=82, demoDist=120, demoGrade=4, demoRec=65; int demoType=1, demoDir=1; boolean demoArmed=true; RectF r=new RectF();
        RideView(Context x){super(x);p.setTypeface(Typeface.create("sans",Typeface.BOLD));stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);setBackgroundColor(Color.BLACK);}
        float dp(float v){return v*getResources().getDisplayMetrics().density;}
        void txt(Canvas x,String s,float xx,float yy,float size,int col,Paint.Align a){p.setTextSize(size*getResources().getDisplayMetrics().density);p.setColor(col);p.setTextAlign(a);p.setStyle(Paint.Style.FILL);p.setSubpixelText(true);x.drawText(s,xx,yy,p);}
        @Override protected void onDraw(Canvas x){super.onDraw(x); if(demo)drawDemo(x); else drawRide(x);}
        void drawRide(Canvas x){int w=getWidth(),h=getHeight(); boolean land=w>h; Location l=engine.loc; Curve q=engine.current;
            if(!land){ drawCurve(x,w/2f,Math.min(h*.31f,w*.44f),q); txt(x,q.valid?q.label:"—",w/2,h*.49f,27,Color.WHITE,Paint.Align.CENTER); txt(x,q.valid?fmtDist(q.distance):"—",w/2,h*.555f,40,Color.WHITE,Paint.Align.CENTER); drawSpeed(x,w/2f,h*.68f,l==null?0:speed(l),q.recommended); drawGrade(x,w/2f,h*.92f,q.grade); drawStatus(x); }
            else { drawCurve(x,w*.25f,h*.40f, q); drawSpeed(x,w*.75f,h*.34f,l==null?0:speed(l),q.recommended); drawGrade(x,w*.75f,h*.88f,q.grade); drawStatus(x); }
            if(!audio){p.setColor(0xEE000000);x.drawRect(0,0,w,h,p);txt(x,"ATTIVA AUDIO",w/2,h*.46f,42,Color.YELLOW,Paint.Align.CENTER);txt(x,"Tocca lo schermo una volta",w/2,h*.54f,24,Color.WHITE,Paint.Align.CENTER);}
            else {txt(x,"AUDIO ON",dp(14),dp(30),18,0xFF77FF77,Paint.Align.LEFT);txt(x,"DEMO",w-dp(58),dp(30),18,Color.YELLOW,Paint.Align.CENTER);}
        }
        float speed(Location l){return l.hasSpeed()?l.getSpeed()*3.6f:0;}
        String fmtDist(float d){return d<1000?Math.round(d)+" m":String.format(Locale.US,"%.1f km",d/1000f);}
        void drawSpeed(Canvas x,float cx,float base,float s,float rec){boolean land=getWidth()>getHeight();float k=land?.55f:1f;float fontK=land?.82f:1f;float d=getResources().getDisplayMetrics().density;txt(x,String.valueOf(Math.round(s)),cx,base,Math.min(getWidth(),getHeight())*.225f/d,Color.WHITE,Paint.Align.CENTER);txt(x,"km/h",cx,base+dp(42)*k,30*fontK,Color.WHITE,Paint.Align.CENTER);if(rec>0){txt(x,"VELOCITÀ CONSIGLIATA",cx,base+dp(86)*k,18*fontK,0xFFFFD400,Paint.Align.CENTER);txt(x,String.valueOf(Math.round(rec))+" km/h",cx,base+dp(126)*k,34*fontK,0xFFFFD400,Paint.Align.CENTER);} }
        void drawGrade(Canvas x,float cx,float y,float g){ if(g==0){txt(x,"— 0%",cx,y,25,Color.WHITE,Paint.Align.CENTER);return;} String s=(g>0?"▲ +":"▼ ")+Math.round(g)+"%"; txt(x,s,cx,y,27,g>0?0xFF66FF66:0xFF4DA6FF,Paint.Align.CENTER); }
        void drawStatus(Canvas x){int col=engine.gpsGood()?0xFF66FF66:0xFFFF4040;String s=engine.gpsGood()?"GPS OK":engine.loc==null?"GPS IN ATTESA":"GPS INSUFFICIENTE";txt(x,s,dp(14),getHeight()-dp(18),18,col,Paint.Align.LEFT); if(engine.noRoad)txt(x,"DATI STRADALI NON DISPONIBILI",getWidth()-dp(14),getHeight()-dp(18),18,Color.RED,Paint.Align.RIGHT);}
        void drawCurve(Canvas x,float cx,float cy,Curve q){float sz=Math.min(getWidth(),getHeight())*.34f; boolean left=q.dir<0; if(!q.valid){txt(x,"—",cx,cy+20,72,0xFF666666,Paint.Align.CENTER);return;} if(q.type>=3){p.setStyle(Paint.Style.FILL);p.setColor(Color.YELLOW);Path t=new Path();t.moveTo(cx,cy-sz*.55f);t.lineTo(cx-sz*.62f,cy+sz*.48f);t.lineTo(cx+sz*.62f,cy+sz*.48f);t.close();x.drawPath(t,p);stroke.setColor(Color.BLACK);stroke.setStrokeWidth(sz*.07f);x.drawPath(t,stroke);}
            Path path=new Path();float sign=left?-1:1;path.moveTo(cx+sign*sz*.42f,cy+sz*.28f);path.cubicTo(cx+sign*sz*.12f,cy+sz*.28f,cx+sign*sz*.16f,cy-sz*.18f,cx+sign*sz*.40f,cy-sz*.28f);path.cubicTo(cx+sign*sz*.60f,cy-sz*.36f,cx+sign*sz*.64f,cy-sz*.58f,cx+sign*sz*.52f,cy-sz*.66f);
            // High-contrast road glyph: dark outline plus bright inner road line.
            stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeCap(Paint.Cap.ROUND);stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(Color.BLACK);stroke.setStrokeWidth(sz*(q.type==1?.135f:q.type==2?.155f:.17f));x.drawPath(path,stroke);
            stroke.setColor(q.type>=3?Color.BLACK:Color.WHITE);stroke.setStrokeWidth(sz*(q.type==1?.095f:q.type==2?.112f:.125f));x.drawPath(path,stroke);
            if(q.type<3){stroke.setColor(0xFFB8C0C8);stroke.setStrokeWidth(sz*.018f);x.drawPath(path,stroke);}
            // Direction arrow: bold yellow fill with a thick black outline.
            Path a=new Path();float ax=cx+sign*sz*.12f, ay=cy+sz*.25f; a.moveTo(ax-sign*sz*.08f,ay);a.lineTo(ax+sign*sz*.10f,ay);a.lineTo(ax+sign*sz*.10f,ay-sz*.18f);a.lineTo(ax+sign*sz*.25f,ay-sz*.18f);a.lineTo(ax,ay-sz*.39f);a.lineTo(ax-sign*sz*.25f,ay-sz*.18f);a.lineTo(ax-sign*sz*.10f,ay-sz*.18f);a.close();p.setColor(0xFFFFD400);p.setStyle(Paint.Style.FILL);x.drawPath(a,p);stroke.setColor(Color.BLACK);stroke.setStrokeWidth(sz*.065f);stroke.setStyle(Paint.Style.STROKE);x.drawPath(a,stroke);
            txt(x,q.label,cx,cy+sz*.72f,29,Color.WHITE,Paint.Align.CENTER);txt(x,fmtDist(q.distance),cx,cy+sz*.90f,42,Color.WHITE,Paint.Align.CENTER);
        }
        void drawDemo(Canvas x){
            int w=getWidth(),h=getHeight();
            // Persistent, high-contrast exit control: the left-top area always returns to RIDE.
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF303030);
            r.set(dp(8),dp(8),dp(112),dp(52)); x.drawRoundRect(r,dp(10),dp(10),p);
            txt(x,"← RIDE",dp(18),dp(36),18,Color.WHITE,Paint.Align.LEFT);
            txt(x,"DEMO / SIMULATA",w/2f,dp(36),24,Color.YELLOW,Paint.Align.CENTER);
            Curve q=Curve.demo(demoType,demoDir,demoDist,demoRec,demoGrade);
            drawCurve(x,w/2f,h*.235f,q); drawSpeed(x,w/2f,h*.53f,demoSpeed,demoRec); drawGrade(x,w/2f,h*.79f,demoGrade);
            String[] ts={"LEGGERA","MEDIA","STRETTA","TORNANTE"};
            txt(x,"TIPO: "+ts[demoType-1]+"   •   DIREZIONE: "+(demoDir<0?"SINISTRA":"DESTRA"),w/2f,dp(78),18,Color.WHITE,Paint.Align.CENTER);
            txt(x,"VELOCITÀ 0–180 km/h",dp(20),h-dp(245),16,Color.GRAY,Paint.Align.LEFT);
            txt(x,"DISTANZA 0–500 m",dp(20),h-dp(190),16,Color.GRAY,Paint.Align.LEFT);
            txt(x,"PENDENZA −12…+12%",dp(20),h-dp(135),16,Color.GRAY,Paint.Align.LEFT);
            txt(x,"CONSIGLIATA 0–180 km/h",dp(20),h-dp(80),16,Color.GRAY,Paint.Align.LEFT);
            txt(x,"← RIDE per uscire · Tocca in alto per tipo/direzione",dp(20),h-dp(20),15,Color.GRAY,Paint.Align.LEFT);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float xx=e.getX(),yy=e.getY();
            if(!audio){enableAudio();return true;}
            // Check the DEMO exit before the other top-row controls.
            if(demo && xx<dp(120) && yy<dp(62)){demo=false;invalidate();return true;}
            if(!demo && xx>getWidth()-dp(110) && yy<dp(70)){demo=true;invalidate();return true;}
            if(demo){
                if(yy<dp(75)){demoType=demoType%4+1;invalidate();return true;}
                if(yy<dp(125)){demoDir=-demoDir;invalidate();return true;}
                float left=dp(30),right=getWidth()-dp(30);
                if(yy>getHeight()-dp(260)&&yy<getHeight()-dp(205)){demoSpeed=Math.max(0f,Math.min(180f,180f*(xx-left)/(right-left)));invalidate();return true;}
                if(yy>getHeight()-dp(200)&&yy<getHeight()-dp(145)){demoDist=Math.max(0f,Math.min(500f,500f*(xx-left)/(right-left)));invalidate();return true;}
                if(yy>getHeight()-dp(140)&&yy<getHeight()-dp(85)){demoGrade=Math.max(-12f,Math.min(12f,-12f+24f*(xx-left)/(right-left)));invalidate();return true;}
                if(yy>getHeight()-dp(80)){demoRec=Math.max(0f,Math.min(180f,180f*(xx-left)/(right-left)));invalidate();return true;}
            }
            return true;
        }
    }
}
