package com.riccardo.roaddisplay;

import android.location.Location;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class RoadEngine {
    RoadDb db;
    Location loc;
    Curve current = new Curve();
    boolean noRoad = true;
    ArrayList<RoadWay> ways = new ArrayList<>();
    ArrayList<RoadWay> mapWays = new ArrayList<>();
    Location lastRoadQueryLocation;
    long lastRoadQueryAt = 0L;

    RoadEngine(RoadDb d) { db = d; }

    void reloadRoads(Location l) {
        if (l == null) return;
        // Curve engine uses nearby roads; map cache keeps the wider preloaded area for panning.
        ways = db.near(l.getLatitude(), l.getLongitude(), 0.006);
        mapWays = db.near(l.getLatitude(), l.getLongitude(), 0.12);
        lastRoadQueryLocation = new Location(l);
        lastRoadQueryAt = System.currentTimeMillis();
    }

    boolean update(Location l) {
        loc = l;
        float oldDistance = current.valid ? current.distance : 99999f;
        boolean refresh = lastRoadQueryLocation == null
                || lastRoadQueryLocation.distanceTo(l) >= 100.0f
                || System.currentTimeMillis() - lastRoadQueryAt >= 10000L;
        if (refresh) reloadRoads(l);
        Curve best = findCurve(l, ways);
        if (best.valid) {
            current = best;
            noRoad = false;
        } else {
            current = new Curve();
            noRoad = ways.isEmpty();
        }
        return oldDistance > 150f && current.valid && current.distance <= 150f;
    }

    boolean gpsGood() {
        return loc != null && loc.getAccuracy() <= 50f;
    }

    Curve findCurve(Location l, ArrayList<RoadWay> roadWays) {
        Curve best = new Curve();
        double bestDistance = Double.MAX_VALUE;
        if (l == null || roadWays == null) return best;
        float travelBearing = l.hasBearing() ? l.getBearing() : 0f;
        for (RoadWay way : roadWays) {
            ArrayList<Geo> points = way.pts;
            if (points == null || points.size() < 6) continue;
            int nearest = nearestIndex(l, points);
            double lateral = dist(l.getLatitude(), l.getLongitude(), points.get(nearest).lat, points.get(nearest).lon);
            if (lateral > 90.0) continue;
            // OSM ways may be stored in either direction. Follow the segment that best
            // matches the current GPS heading instead of blindly walking array-forward.
            int step = 1;
            if (nearest < points.size() - 1 && nearest > 0 && l.hasBearing()) {
                double fwd = Math.abs(normalizeAngle(bearing(points.get(nearest), points.get(nearest + 1)) - travelBearing));
                double rev = Math.abs(normalizeAngle(bearing(points.get(nearest), points.get(nearest - 1)) - travelBearing));
                if (rev < fwd) step = -1;
            } else if (nearest >= points.size() - 1) step = -1;
            ArrayList<Geo> ahead = new ArrayList<>();
            ahead.add(points.get(nearest));
            double along = 0.0;
            int idx = nearest;
            while (ahead.size() < 45) {
                int next = idx + step;
                if (next < 0 || next >= points.size()) break;
                Geo a = points.get(idx), b = points.get(next);
                along += dist(a.lat, a.lon, b.lat, b.lon);
                if (along > 650.0) break;
                ahead.add(b); idx = next;
            }
            if (ahead.size() < 6) continue;
            double cumulative = 0.0;
            for (int i = 1; i + 4 < ahead.size(); i++) {
                Geo prev = ahead.get(i - 1), here = ahead.get(i), next = ahead.get(i + 1);
                cumulative += dist(prev.lat, prev.lon, here.lat, here.lon);
                if (cumulative < 12.0 || cumulative > 500.0) continue;
                int end = Math.min(ahead.size() - 1, i + 5);
                double turn = turnSum(ahead, i - 1, end);
                if (Math.abs(turn) < 14.0) continue;
                double radius = radius(prev, here, next);
                if (radius > 1200.0 && Math.abs(turn) < 28.0) continue;
                double distance = lateral + cumulative;
                if (distance <= 8.0 || distance >= bestDistance) continue;
                Curve candidate = new Curve();
                candidate.valid = true;
                candidate.distance = (float) distance;
                candidate.dir = turn < 0 ? -1 : 1;
                candidate.radius = radius;
                candidate.type = classify(Math.abs(turn), radius);
                candidate.label = new String[]{"", "LEGGERA", "MEDIA", "STRETTA", "TORNANTE"}[candidate.type];
                candidate.recommended = recommend(candidate);
                best = candidate; bestDistance = distance;
            }
        }
        return best;
    }

    int nearestIndex(Location l, ArrayList<Geo> points) {
        int nearest = 0;
        double best = Double.MAX_VALUE;
        for (int i = 0; i < points.size(); i++) {
            Geo point = points.get(i);
            double distance = dist(l.getLatitude(), l.getLongitude(), point.lat, point.lon);
            if (distance < best) {
                best = distance;
                nearest = i;
            }
        }
        return nearest;
    }

    // endIndex is inclusive; calculate heading changes only where all three points exist.
    double turnSum(ArrayList<Geo> points, int startIndex, int endIndex) {
        double sum = 0.0;
        for (int k = startIndex; k + 2 <= endIndex; k++) {
            double h1 = bearing(points.get(k), points.get(k + 1));
            double h2 = bearing(points.get(k + 1), points.get(k + 2));
            sum += normalizeAngle(h2 - h1);
        }
        return sum;
    }

    double normalizeAngle(double angle) {
        while (angle > 180.0) angle -= 360.0;
        while (angle < -180.0) angle += 360.0;
        return angle;
    }

    double radius(Geo a, Geo b, Geo c) {
        // Local metric coordinates correct for longitude compression at the current latitude.
        double cosLat = Math.cos(Math.toRadians(b.lat));
        double ax = (a.lon - b.lon) * 111320.0 * cosLat;
        double ay = (a.lat - b.lat) * 110540.0;
        double cx = (c.lon - b.lon) * 111320.0 * cosLat;
        double cy = (c.lat - b.lat) * 110540.0;
        double ab = Math.hypot(ax, ay);
        double bc = Math.hypot(cx, cy);
        double ac = dist(a.lat, a.lon, c.lat, c.lon);
        double area = Math.abs(ax * cy - ay * cx) / 2.0;
        if (area < 0.01) return 9999.0;
        return (ab * bc * ac) / (4.0 * area);
    }

    int classify(double turn, double radius) {
        if (turn >= 125.0 || radius < 18.0) return 4;
        if (turn >= 55.0 || radius < 45.0) return 3;
        if (turn >= 25.0 || radius < 100.0) return 2;
        return 1;
    }

    float recommend(Curve curve) {
        // Informational only: this is not a validated road-safety speed model.
        if (curve.radius > 5000.0 || curve.radius <= 0.0) return 0f;
        double speed = Math.sqrt(Math.max(1.0, curve.radius) * 9.0);
        float kmh = (float) (speed * 3.6);
        return Math.max(15f, Math.min(100f, kmh));
    }

    double bearing(Geo a, Geo b) {
        double y = Math.sin(Math.toRadians(b.lon - a.lon)) * Math.cos(Math.toRadians(b.lat));
        double x = Math.cos(Math.toRadians(a.lat)) * Math.sin(Math.toRadians(b.lat))
                - Math.sin(Math.toRadians(a.lat)) * Math.cos(Math.toRadians(b.lat))
                * Math.cos(Math.toRadians(b.lon - a.lon));
        return Math.toDegrees(Math.atan2(y, x));
    }

    double dist(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }

    boolean fetchOnline(Location location) {
        if (location == null) return false;
        // Public Overpass servers can be busy. Use one sequential request per server,
        // reducing the radius on fallback rather than flooding any single endpoint.
        int[] radii = {10000, 5000, 2500};
        String[] endpoints = {
                "https://overpass-api.de/api/interpreter",
                "https://overpass.kumi.systems/api/interpreter",
                "https://overpass.private.coffee/api/interpreter"
        };
        for (int attempt = 0; attempt < endpoints.length; attempt++) {
            int radius = radii[attempt];
            String query = "[out:xml][timeout:35];way(around:" + radius + "," + location.getLatitude() + "," + location.getLongitude()
                    + ")[highway~\"^(motorway|motorway_link|trunk|trunk_link|primary|primary_link|secondary|secondary_link|tertiary|tertiary_link|unclassified|residential|living_street|service|road)$\"];out tags geom;";
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(endpoints[attempt]).openConnection();
                connection.setConnectTimeout(9000);
                connection.setReadTimeout(40000);
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("User-Agent", "ROAD-DISPLAY-PRO/3.6.0 (Android; OpenStreetMap data client)");
                connection.setRequestProperty("Accept", "application/xml,text/xml;q=0.9,*/*;q=0.5");
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                byte[] payload = ("data=" + URLEncoder.encode(query, "UTF-8")).getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = connection.getOutputStream()) { output.write(payload); }
                int response = connection.getResponseCode();
                if (response != HttpURLConnection.HTTP_OK) continue;
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
                factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                factory.setXIncludeAware(false); factory.setExpandEntityReferences(false);
                int savedWays = 0;
                try (InputStream input = connection.getInputStream()) {
                    Document document = factory.newDocumentBuilder().parse(input);
                    NodeList nodes = document.getElementsByTagName("way");
                    for (int i = 0; i < nodes.getLength(); i++) {
                        Element way = (Element) nodes.item(i);
                        String id = way.getAttribute("id"), name = "";
                        NodeList tags = way.getElementsByTagName("tag");
                        for (int j = 0; j < tags.getLength(); j++) {
                            Element tag = (Element) tags.item(j);
                            if ("name".equals(tag.getAttribute("k"))) { name = tag.getAttribute("v"); break; }
                        }
                        NodeList geometry = way.getElementsByTagName("nd");
                        if (geometry.getLength() < 2) continue;
                        StringBuilder encodedPoints = new StringBuilder();
                        double minLat = 90, minLon = 180, maxLat = -90, maxLon = -180;
                        for (int j = 0; j < geometry.getLength(); j++) {
                            Element point = (Element) geometry.item(j);
                            double lat = Double.parseDouble(point.getAttribute("lat"));
                            double lon = Double.parseDouble(point.getAttribute("lon"));
                            if (j > 0) encodedPoints.append(';');
                            encodedPoints.append(lat).append(',').append(lon);
                            minLat = Math.min(minLat, lat); minLon = Math.min(minLon, lon);
                            maxLat = Math.max(maxLat, lat); maxLon = Math.max(maxLon, lon);
                        }
                        db.put(id, name, minLat, minLon, maxLat, maxLon, encodedPoints.toString());
                        savedWays++;
                    }
                }
                // An HTTP 200 with an Overpass error/empty result is not a successful map load.
                if (savedWays > 0) return true;
            } catch (Exception ignored) {
                // Try the next independent endpoint with a smaller fallback radius.
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
        return false;
    }
}
