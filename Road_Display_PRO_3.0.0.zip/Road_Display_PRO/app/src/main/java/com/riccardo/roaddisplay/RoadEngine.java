package com.riccardo.roaddisplay;

import android.location.Location;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class RoadEngine {
    RoadDb db;
    Location loc;
    Curve current = new Curve();
    boolean noRoad = true;
    ArrayList<RoadWay> ways = new ArrayList<>();

    RoadEngine(RoadDb d) { db = d; }

    boolean update(Location l) {
        loc = l;
        float oldDistance = current.valid ? current.distance : 99999f;
        ways = db.near(l.getLatitude(), l.getLongitude(), 0.006);
        Curve best = findCurve(l, ways);
        if (best.valid) {
            current = best;
            noRoad = false;
        } else {
            current = new Curve();
            noRoad = ways.isEmpty();
        }
        return oldDistance > 150f && current.valid && current.distance <= 150f;
    }

    boolean gpsGood() {
        return loc != null && loc.getAccuracy() <= 50f;
    }

    Curve findCurve(Location l, ArrayList<RoadWay> roadWays) {
        Curve best = new Curve();
        double bestAlongDistance = Double.MAX_VALUE;

        for (RoadWay way : roadWays) {
            ArrayList<Geo> points = way.pts;
            if (points == null || points.size() < 5) continue;

            int nearest = nearestIndex(l, points);
            double distanceAlong = dist(l.getLatitude(), l.getLongitude(),
                    points.get(nearest).lat, points.get(nearest).lon);

            for (int i = Math.max(1, nearest); i < points.size() - 2; i++) {
                if (i > nearest) {
                    Geo previous = points.get(i - 1);
                    Geo here = points.get(i);
                    distanceAlong += dist(previous.lat, previous.lon, here.lat, here.lon);
                }

                // Avoid expensive curve calculations for geometry far beyond the look-ahead.
                if (distanceAlong > 500.0) break;

                int end = Math.min(points.size() - 1, i + 5);
                double turn = turnSum(points, i, end);
                if (Math.abs(turn) < 10.0) continue;

                double radius = radius(points.get(i - 1), points.get(i), points.get(i + 1));
                Curve candidate = new Curve();
                candidate.valid = true;
                candidate.distance = (float) distanceAlong;
                candidate.dir = turn < 0 ? -1 : 1;
                candidate.radius = radius;
                candidate.type = classify(Math.abs(turn), radius);
                candidate.label = new String[]{"", "LEGGERA", "MEDIA", "STRETTA", "TORNANTE"}[candidate.type];
                candidate.recommended = recommend(candidate);

                if (distanceAlong > 8.0 && distanceAlong < bestAlongDistance) {
                    best = candidate;
                    bestAlongDistance = distanceAlong;
                }
            }
        }
        return best;
    }

    int nearestIndex(Location l, ArrayList<Geo> points) {
        int nearest = 0;
        double best = Double.MAX_VALUE;
        for (int i = 0; i < points.size(); i++) {
            Geo point = points.get(i);
            double distance = dist(l.getLatitude(), l.getLongitude(), point.lat, point.lon);
            if (distance < best) {
                best = distance;
                nearest = i;
            }
        }
        return nearest;
    }

    // endIndex is inclusive; calculate heading changes only where all three points exist.
    double turnSum(ArrayList<Geo> points, int startIndex, int endIndex) {
        double sum = 0.0;
        for (int k = startIndex; k + 2 <= endIndex; k++) {
            double h1 = bearing(points.get(k), points.get(k + 1));
            double h2 = bearing(points.get(k + 1), points.get(k + 2));
            sum += normalizeAngle(h2 - h1);
        }
        return sum;
    }

    double normalizeAngle(double angle) {
        while (angle > 180.0) angle -= 360.0;
        while (angle < -180.0) angle += 360.0;
        return angle;
    }

    double radius(Geo a, Geo b, Geo c) {
        // Local metric coordinates correct for longitude compression at the current latitude.
        double cosLat = Math.cos(Math.toRadians(b.lat));
        double ax = (a.lon - b.lon) * 111320.0 * cosLat;
        double ay = (a.lat - b.lat) * 110540.0;
        double cx = (c.lon - b.lon) * 111320.0 * cosLat;
        double cy = (c.lat - b.lat) * 110540.0;
        double ab = Math.hypot(ax, ay);
        double bc = Math.hypot(cx, cy);
        double ac = dist(a.lat, a.lon, c.lat, c.lon);
        double area = Math.abs(ax * cy - ay * cx) / 2.0;
        if (area < 0.01) return 9999.0;
        return (ab * bc * ac) / (4.0 * area);
    }

    int classify(double turn, double radius) {
        if (turn >= 125.0 || radius < 18.0) return 4;
        if (turn >= 55.0 || radius < 45.0) return 3;
        if (turn >= 25.0 || radius < 100.0) return 2;
        return 1;
    }

    float recommend(Curve curve) {
        // Informational only: this is not a validated road-safety speed model.
        if (curve.radius > 5000.0 || curve.radius <= 0.0) return 0f;
        double speed = Math.sqrt(Math.max(1.0, curve.radius) * 9.0);
        float kmh = (float) (speed * 3.6);
        return Math.max(15f, Math.min(100f, kmh));
    }

    double bearing(Geo a, Geo b) {
        double y = Math.sin(Math.toRadians(b.lon - a.lon)) * Math.cos(Math.toRadians(b.lat));
        double x = Math.cos(Math.toRadians(a.lat)) * Math.sin(Math.toRadians(b.lat))
                - Math.sin(Math.toRadians(a.lat)) * Math.cos(Math.toRadians(b.lat))
                * Math.cos(Math.toRadians(b.lon - a.lon));
        return Math.toDegrees(Math.atan2(y, x));
    }

    double dist(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }

    void fetchOnline(Location location) {
        HttpURLConnection connection = null;
        try {
            double delta = 0.0045;
            String bbox = (location.getLatitude() - delta) + ","
                    + (location.getLongitude() - delta) + ","
                    + (location.getLatitude() + delta) + ","
                    + (location.getLongitude() + delta);
            String query = "[out:xml][timeout:25];way[highway~\"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|service)$\"]("
                    + bbox + ");out tags geom;";
            URL url = new URL("https://overpass-api.de/api/interpreter?data="
                    + URLEncoder.encode(query, "UTF-8"));
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            connection.setRequestMethod("GET");
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) return;

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // OSM response is data only; disallow DTDs and external entity resolution.
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);

            try (InputStream input = connection.getInputStream()) {
                Document document = factory.newDocumentBuilder().parse(input);
                NodeList nodes = document.getElementsByTagName("way");
                for (int i = 0; i < nodes.getLength(); i++) {
                    Element way = (Element) nodes.item(i);
                    String id = way.getAttribute("id");
                    String name = "";
                    NodeList tags = way.getElementsByTagName("tag");
                    for (int j = 0; j < tags.getLength(); j++) {
                        Element tag = (Element) tags.item(j);
                        if ("name".equals(tag.getAttribute("k"))) {
                            name = tag.getAttribute("v");
                            break;
                        }
                    }

                    NodeList geometry = way.getElementsByTagName("nd");
                    StringBuilder encodedPoints = new StringBuilder();
                    double minLat = 90, minLon = 180, maxLat = -90, maxLon = -180;
                    for (int j = 0; j < geometry.getLength(); j++) {
                        Element point = (Element) geometry.item(j);
                        double lat = Double.parseDouble(point.getAttribute("lat"));
                        double lon = Double.parseDouble(point.getAttribute("lon"));
                        if (j > 0) encodedPoints.append(';');
                        encodedPoints.append(lat).append(',').append(lon);
                        minLat = Math.min(minLat, lat);
                        minLon = Math.min(minLon, lon);
                        maxLat = Math.max(maxLat, lat);
                        maxLon = Math.max(maxLon, lon);
                    }
                    if (geometry.getLength() > 1) {
                        db.put(id, name, minLat, minLon, maxLat, maxLon, encodedPoints.toString());
                    }
                }
            }
        } catch (Exception ignored) {
            // Network/provider failures should not crash the ride screen.
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
