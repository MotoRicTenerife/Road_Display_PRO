# ROAD DISPLAY PRO — Radar system notes (3.41.0)

## Implemented in this build

- Fixed-point radar nodes from OpenStreetMap (`highway=speed_camera`) are stored in the existing SQLite road database.
- Successful regional refreshes replace only radar points inside the successfully queried radius; cached points outside that area remain untouched. The replacement and freshness metadata are committed in one SQLite transaction, so a failed request does not wipe the last known-good points.
- Radar freshness is tracked by small geographic cells (about 5 km, varying with latitude), not by one global flag. A cell becomes due after 24 hours. The app checks this when it has a location and is running; a failed attempt is throttled before retrying. The current implementation does not run a background location service while the app is closed.
- The map draws each cached radar marker at its stored latitude/longitude, using the same map projection, zoom, scale and rotation as the road tiles.
- Spoken alerts are enabled only when GPS is in the strong/accurate processing path and a real speed limit is known. The first alert is speed-adaptive (400–1000 m, based on current speed) and only starts at least 3 km/h above the known limit. Follow-up announcements are at 100 m, 50 m and 10 m (“Attenzione Radar”). Once the sequence starts, it continues as the vehicle approaches even if speed drops, so braking does not cancel the remaining proximity cues.
- No legal speed limit is invented when the road database does not provide one. In that case the radar icon can still appear, but the overspeed-triggered spoken sequence is not armed.

## Data sources and coverage

1. **OpenStreetMap speed-camera nodes**: https://wiki.openstreetmap.org/wiki/Tag:highway%3Dspeed_camera
   - OSM documents a fixed roadside/overhead speed camera as a node tagged `highway=speed_camera`; `direction=*` and `maxspeed=*` may be present but are not consistently populated.
   - The app currently consumes the point nodes around the current location. It does not yet ingest all OSM enforcement relations, all radar-tramo endpoint pairs, or a complete country-wide OSM extract.
2. **DGT official speed-control information**: https://www.dgt.es/conoce-el-estado-del-trafico/vigilancia-y-control/equipos-y-tramos-de-vigilancia/
   - DGT publishes fixed and section-control information. The NAP dataset describes fixed radar locations for DGT-managed roads, excluding Catalonia and the Basque Country: https://nap.dgt.es/en/dataset/radares-fijos-dgt
   - The official DGT data is a reference for future ingestion and cross-validation, but this build does not yet parse the DGT downloadable dataset automatically.
3. **Radar de tramo**: https://www.dgt.es/comunicacion/noticias/que-es-un-radar-de-tramo
   - Section control measures average speed between two ends. It should be modeled as a segment with entry/exit points and a speed-limit rule, not as a single ordinary fixed-radar point. That full feature is not included in 3.41.0.
4. **Spanish legal context**: DGT explains that GPS/app warnings are distinct from radar detectors and inhibitors: https://www-pr.dgt.es/es/reportajes/2019/08AGOSTO/0806-Avisar-legal-detectar-no.shtml
   - This app implements location-based warnings only; it does not use detector or jammer hardware.

## Important limits

- This is a robust first implementation for fixed radar points, not a guarantee of perfect nationwide completeness. OSM coverage and coordinate quality depend on the map data. DGT and regional-authority feeds should be imported and reconciled before claiming national completeness.
- The daily check is per local geographic cell while the app has a usable location. It does not refresh every region of Spain each day, and it does not run a background-location worker while the app is closed.
- The current nearest-radar selection uses GPS distance and a tolerant heading filter. Dense parallel carriageways and complex junctions still require real-world validation. The displayed icon is at the database coordinate; that does not guarantee the source coordinate itself is surveyed perfectly.
- A missing/unknown speed limit intentionally suppresses the overspeed-triggered voice sequence rather than guessing a legal limit.

## Verification

`roadtools/radar_system_regression_test.py` checks source integration and exercises 100,000 randomized speed/threshold cases. All existing `roadtools/*_test.py` scripts should be run before packaging. ZIP integrity and source-balance checks are separate from an Android Gradle build; a successful Android build must still be confirmed by the project's CI workflow.
