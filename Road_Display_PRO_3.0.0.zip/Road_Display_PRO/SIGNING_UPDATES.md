# Install updates without uninstalling ROAD DISPLAY PRO

Android permits an in-place update when all three conditions are true:

1. `applicationId` stays `com.riccardo.roaddisplay`.
2. The new APK has a higher `versionCode`.
3. The new APK is signed with the same signing certificate as the installed APK.

Version 3.41.2 keeps the same application ID and raises `versionCode` to 532.

## Keep the signing key stable in GitHub Actions

The workflow supports the GitHub Actions secret `ANDROID_DEBUG_KEYSTORE_BASE64`. Configure it once so future CI builds use the same debug signing certificate:

1. On a trusted computer with Java's `keytool`, create a debug keystore (do this only once):

   ```bash
   keytool -genkeypair -v -keystore debug.keystore -storepass android \
     -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
     -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
   ```

2. Encode the keystore as one base64 string. On Linux/macOS:

   ```bash
   base64 -w 0 debug.keystore
   ```

   On macOS, if `-w 0` is unsupported, use `base64 debug.keystore | tr -d '\n'`.

3. In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret**. Name it `ANDROID_DEBUG_KEYSTORE_BASE64` and paste the complete base64 string as the value.
4. Keep the original `debug.keystore` in a secure backup. Do not commit it to the repository or share it publicly.

If the secret is absent, CI warns and falls back to the runner's temporary debug key; that build may not update an installed APK in place.

**Transition note:** an APK already installed from an earlier GitHub-hosted build may have been signed with a different temporary key. Android cannot change an installed app's signing certificate during an update. If that is the case, uninstall that older installation once, install the first APK built with the persistent key, and subsequent versions signed with that same key can be installed as updates without uninstalling.
