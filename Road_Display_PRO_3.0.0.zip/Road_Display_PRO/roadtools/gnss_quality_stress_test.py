"""GNSS quality classification stress tests for ROAD DISPLAY PRO.

Mirrors the 3.34.3 thresholds in MainActivity.java without Android runtime:
- strong: GPS provider, accuracy <= 50 m, age <= 3 s
- usable: GPS provider, accuracy <= 80 m, age <= 8 s
- GNSS loss only after >10 s without a usable fix
"""

STRONG_ACC = 50.0
USABLE_ACC = 80.0
STRONG_AGE = 3000
USABLE_AGE = 8000
LOSS_TIMEOUT = 10000


def classify(provider, accuracy, age_ms):
    is_gnss = provider == "gps"
    strong = is_gnss and accuracy is not None and accuracy <= STRONG_ACC and age_ms <= STRONG_AGE
    usable = is_gnss and accuracy is not None and accuracy <= USABLE_ACC and age_ms <= USABLE_AGE
    return strong, usable


def expect(name, actual, expected):
    if actual != expected:
        raise AssertionError(f"{name}: expected {expected}, got {actual}")


def main():
    # Exact boundaries and just-over-boundary cases.
    expect("50m/3s strong", classify("gps", 50, 3000), (True, True))
    expect("50.01m/3s usable", classify("gps", 50.01, 3000), (False, True))
    expect("80m/8s usable", classify("gps", 80, 8000), (False, True))
    expect("80.01m/8s lost", classify("gps", 80.01, 8000), (False, False))
    expect("50m/3.001s usable", classify("gps", 50, 3001), (False, True))
    expect("80m/8.001s lost", classify("gps", 80, 8001), (False, False))

    # Network/passive locations never masquerade as GNSS, even when very precise.
    for provider in ("network", "passive", "fused", "ip-approx"):
        expect(f"{provider} precise is not GNSS", classify(provider, 1, 100), (False, False))

    # Deterministic sweep around both boundaries.
    for acc in [0.5, 1, 5, 10, 25, 49.9, 50, 50.1, 60, 70, 79.9, 80, 80.1, 100, 250]:
        for age in [0, 100, 1000, 2999, 3000, 3001, 5000, 7999, 8000, 8001, 12000]:
            strong, usable = classify("gps", acc, age)
            if strong and not usable:
                raise AssertionError(f"strong must imply usable: acc={acc}, age={age}")
            if strong != (acc <= 50 and age <= 3000):
                raise AssertionError(f"strong boundary error: acc={acc}, age={age}")
            if usable != (acc <= 80 and age <= 8000):
                raise AssertionError(f"usable boundary error: acc={acc}, age={age}")

    # Health timeout semantics: a usable fix keeps GNSS alive through 10 s;
    # loss starts only strictly after the configured timeout.
    for elapsed in [0, 1000, 3000, 7999, 8000, 9999, 10000]:
        lost = elapsed > LOSS_TIMEOUT
        if lost:
            raise AssertionError(f"GNSS should not be lost at {elapsed}ms")
    for elapsed in [10001, 11000, 30000]:
        if not elapsed > LOSS_TIMEOUT:
            raise AssertionError(f"GNSS should be lost at {elapsed}ms")

    print("GNSS QUALITY STRESS: PASS")
    print("Thresholds: strong <=50m/3s; usable <=80m/8s; loss >10s")
    print("Boundary cases + provider discrimination + deterministic sweep: PASS")


if __name__ == "__main__":
    main()
