import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT/"app/src/main/java/com/riccardo/roaddisplay/MainActivity.java"
s=MAIN.read_text(encoding="utf-8")
checks=[
("landscape GPS centered", "w * .50f, dp(23)" in s),
("data screen", "void drawData(Canvas c)" in s and "GESTIONE DATI" in s),
("offline manager", "OfflineManager.getInstance" in s),
("Tenerife offline region", "createTenerifeOfflineRegion" in s and "8.0,13.0" in s),
("offline deletion", "r.delete(new OfflineRegion.OfflineRegionDeleteCallback" in s),
("cache deletion", "clearAmbientCache" in s),
("GPX document picker", "ActivityResultContracts.CreateDocument" in s and "application/gpx+xml" in s),
("GPX timestamps", "<time>%s</time>" in s and "isoUtc" in s),
("GPX elevation", "<ele>%.2f</ele>" in s),
("GPX export async", '"gpx-export"' in s),
("modern activity result API", "registerForActivityResult" in s and "ActivityResultContracts.CreateDocument" in s and s.count("void onActivityResult(")==0),
("single resume callback", s.count("void onResume(")==1),
("single pause callback", s.count("void onPause(")==1),
("single low-memory callback", s.count("void onLowMemory(")==1),
]
for name,ok in checks:
    if not ok: raise SystemExit("FAIL: "+name)
# Synthetic GPX stress: validate that the intended output structure remains parseable
# for a long trace without actually allocating Android classes.
import xml.etree.ElementTree as ET
n=100000
body=["<?xml version='1.0' encoding='UTF-8'?><gpx version='1.1'><trk><trkseg>"]
for i in range(n):
    body.append(f'<trkpt lat="28.{i%900000:06d}" lon="-16.{(i*7)%900000:06d}"><ele>{i%2000:.2f}</ele><time>2026-01-01T00:00:{i%60:02d}Z</time></trkpt>')
body.append('</trkseg></trk></gpx>')
xml=''.join(body)
ET.fromstring(xml)
assert xml.count('<trkpt ')==n
print('B2_DATA_STRESS_POINTS=100000')
print('CHECKS=',len(checks),'FAILURES=0')
print('RESULT=PASS')
