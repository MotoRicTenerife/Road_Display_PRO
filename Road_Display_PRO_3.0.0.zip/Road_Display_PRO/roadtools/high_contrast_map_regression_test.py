from pathlib import Path
MAIN=Path('app/src/main/java/com/riccardo/roaddisplay/MainActivity.java')
BUILD=Path('app/build.gradle')
def main():
 s=MAIN.read_text(encoding='utf-8'); b=BUILD.read_text(encoding='utf-8')
 checks={
  'MapLibre style hook':'applyHighContrastMapStyle(style)' in s,
  'white background':'PropertyFactory.backgroundColor(Color.WHITE)' in s,
  'white land fills':'PropertyFactory.fillColor(Color.WHITE)' in s,
  'black fill outlines':'PropertyFactory.fillOutlineColor(Color.BLACK)' in s,
  'black road lines':'PropertyFactory.lineColor(road ? Color.BLACK' in s,
  'black text with white halo':'PropertyFactory.textColor(Color.BLACK)' in s and 'PropertyFactory.textHaloColor(Color.WHITE)' in s,
  'road layer detection':'id.contains("transportation")' in s and 'id.contains("motorway")' in s,
  'GPS/radar overlays preserved':'drawRadarMarkers(c, bounds, location, expanded)' in s and 'bike.moveTo(markerCx,markerCy-markerSize*.72f)' in s,
  'version 3.41.6':"versionCode 536; versionName '3.41.6'" in b,
 }
 for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
 print(f'CHECKS={len(checks)} FAILURES={sum(not x for x in checks.values())}')
 if not all(checks.values()): raise SystemExit(1)
if __name__=='__main__': main()
