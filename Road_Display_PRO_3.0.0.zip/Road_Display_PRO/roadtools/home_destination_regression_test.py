from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[0].parent
SRC = ROOT / 'app/src/main/java/com/riccardo/roaddisplay/MainActivity.java'
s = SRC.read_text(encoding='utf-8')

# 1) The CASA button must never write the literal private token CASA into the
# destination/departure field. It is a command, not a routable address.
assert 'field.setText("CASA")' not in s

# 2) Saved coordinates must be persisted by the full-screen map flag.
assert 'putString(PREF_HOME_LAT,Double.toString(lat))' in s
assert 'putString(PREF_HOME_LON,Double.toString(lon))' in s

# 3) If no reverse-geocoded address exists, CASA must display the exact saved
# coordinate pair in a parser-compatible decimal form.
assert 'String.format(Locale.US, "%.6f, %.6f", lat, lon)' in s
assert 'formatSavedHomeCoordinates' in s

# 4) The navigation engine must resolve the saved-home coordinates directly
# before trying Photon/Nominatim.
start = s.index('Location destinationLocation = parseCoordinateDestination(toQuery);')
end = s.index('if(destinationLocation==null) throw new Exception("Destinazione non trovata");', start)
block = s[start:end]
assert 'homeCoordsIfMatch(toQuery,savedHome,hp)' in block
assert 'new Location("saved-home")' in block
assert block.index('homeCoordsIfMatch') < block.index('geocodeAddressPhoton')

# 5) Reverse geocoding is asynchronous and only overwrites the address label
# if the stored coordinates still match the point that was saved.
assert 'reverseGeocodeHomeLocation(lat,lon);' in s
assert 'Math.abs(savedLat-lat)<1e-7 && Math.abs(savedLon-lon)<1e-7' in s

# 6) Coordinate parser accepts the format shown to the user.
assert 'parseCoordinateDestination' in s
assert 'latitude,longitude' in s
assert '.matches()' in s

print('HOME_DESTINATION_REGRESSION: PASS')
