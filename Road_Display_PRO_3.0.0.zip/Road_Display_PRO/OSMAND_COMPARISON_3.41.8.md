# ROAD DISPLAY PRO — confronto funzionale con OsmAnd

## Correzione inclusa in 3.41.8
- Inversione del segno della rotazione a due dita corretta sia sulla mappa principale sia sulla mappa del viaggio. Il verso della mappa ora segue il gesto invece di invertirlo.
- Modalità NEGATIVO, sensore di luminosità e pulsante ⚙ mantenuti.
- Versione aggiornata a 3.41.8 (versionCode 538).

## Cosa offre OsmAnd che resta da portare a Road Display PRO
1. **Mappe vettoriali regionali realmente offline.** L'attuale mappa MapLibre usa uno stile remoto e le geometrie stradali locali sono una cache parziale: non è un pacchetto offline completo di Tenerife.
2. **Routing offline.** La navigazione attuale dipende dal servizio di routing remoto per calcolare/ricalcolare il percorso. Serve un grafo stradale locale con restrizioni, sensi unici, rotatorie e limiti.
3. **Ricerca offline.** La ricerca locale deve essere indicizzata su indirizzi e POI del pacchetto regionale, con fallback online esplicito.
4. **Import/export GPX e tappe.** Mantenere l'esportazione già presente e verificare importazione, tappe intermedie e ripresa del percorso.
5. **Profili di routing e ricalcolo.** Aggiungere un profilo moto che privilegi strade percorribili, eviti accessi vietati e recuperi il percorso dopo deviazioni senza falsi ricalcoli su un singolo fix GPS.
6. **Affidabilità dei limiti.** Dare priorità ai tag maxspeed reali; se il dato manca o la posizione è incerta, mostrare dato non disponibile, non stimare un limite legale.
7. **Guida vocale configurabile.** Soglie di preavviso basate sulla velocità, una sola sequenza per manovra, annuncio dedicato all'uscita dalla rotonda e silenziamento dopo l'arrivo.

## Limiti della revisione
Questa revisione corregge il verso della rotazione e aggiorna i test statici. Non introduce ancora un pacchetto offline regionale né un motore di routing offline: sono interventi architetturali che richiedono dati OSM preprocessati, licenze/attribuzione adeguate, spazio di archiviazione, download/aggiornamento e test sul dispositivo. Non si dichiara la navigazione offline completa finché non viene realizzata e provata.


## Correzioni 3.41.9 (revisione richiesta)
- Soglie automatiche modalità NEGATIVO dimezzate: ingresso a 12.500 lux, uscita a 6.000 lux (isteresi conservata).
- Rimosso il ricollegamento del limite di velocità corrente al profilo ETA del percorso: evita di continuare ad annunciare, per esempio, 120 km/h dopo l'uscita dall'autostrada quando il nuovo limite non è noto. Il limite resta non disponibile finché non è rilevato un dato valido per la strada attuale.
- Annunci di manovra ridotti a due al massimo: preavviso adattato alla velocità (circa 4,5 s, 180–400 m) e richiamo finale entro 25 m; in autostrada il preavviso è più lungo.
- Mappa vettoriale impostata sullo stile chiaro Positron e rimossa la ricolorazione indiscriminata di tutte le strade in nero.
- Conservata la soppressione delle false svolte quando la strada successiva ha lo stesso nome, salvo rotonde, immissioni, bivi reali e inversioni. Da confermare su strada con dati di manovra reali.
- Queste modifiche richiedono compilazione Android e prova sul dispositivo; i test statici non possono dimostrare la qualità del GPS o della cartografia online.
