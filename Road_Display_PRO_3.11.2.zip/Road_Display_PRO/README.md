# ROAD DISPLAY PRO 3.4.0

## Aggiornamenti 3.4.0
- Corretto il refresh della cache stradale dopo il download online: la mappa viene ridisegnata con le geometrie appena scaricate.
- Scaricamento iniziale delle strade entro circa 10 km dalla posizione GPS tramite Overpass API, con endpoint alternativi e aggiornamento quando la moto si sposta di circa 8 km.
- Mappa monocromatica cliccabile a schermo intero; trascinamento per esplorare i dati già scaricati; raggio visualizzato di 500 m nella finestra RIDE.
- Pulsante meteo con aggiornamento automatico ogni 30 minuti o dopo 15 km, oltre all'aggiornamento manuale. L'avviso rosso si attiva per temporali, pioggia intensa o raffiche forti secondo soglie indicative.
- Etichette principali localizzate in base alla lingua di sistema per italiano, spagnolo e inglese.
- Simboli curve aggiornati: cerchio verde, quadrato giallo, triangolo doppio per la curva stretta e punto esclamativo per il tornante.

## Limiti da conoscere
- Il download iniziale richiede una posizione GPS valida e una connessione Internet. Gli endpoint pubblici Overpass possono essere lenti o temporaneamente non disponibili.
- La mappa è una visualizzazione vettoriale essenziale delle geometrie stradali OSM memorizzate localmente, non una cartografia professionale turn-by-turn e non garantisce copertura offline completa.
- Il meteo usa Open-Meteo; le soglie per il banner rosso sono avvisi indicativi, non certificazioni di sicurezza.
- Le velocità consigliate e la classificazione delle curve sono sperimentali e non devono essere usate come unico riferimento durante la guida.

## Build
Aprire il progetto in Android Studio oppure usare il workflow GitHub Actions `Build APK`.
# ROAD DISPLAY PRO 3.2.0

Aggiornamento: mappa vettoriale monocromatica centrale con raggio nominale di 500 m (copertura circa 1 km x 1 km), centratura sulla posizione GPS e rotazione per mantenere la direzione di marcia verso l'alto. La mappa usa le geometrie stradali OpenStreetMap già recuperate e memorizzate localmente; non è una cartografia offline completa e può risultare vuota se i dati stradali non sono disponibili. Pulsante DEMO ridotto e simboli curve ricolorati: verde leggera, giallo media, rosso con triangolo a doppio bordo stretta e tornante con punto esclamativo.

# ROAD DISPLAY PRO 3.0.0

Package: `com.riccardo.roaddisplay`

A native Android motorcycle display designed for a handlebar-mounted phone. The current 3.0.0 project contains a real native GPS layer, a vector ride display, DEMO controls, audio warnings, online OSM road geometry acquisition and a local SQLite road-geometry cache.

## Important status / honesty statement

This release does **not** claim to contain a complete offline map of the Canary Islands. No fabricated road data is bundled. Offline curve detection works for road geometry that has actually been acquired and stored in the local database. If no local road geometry is available, the app reports `DATI STRADALI NON DISPONIBILI` rather than inventing a curve.

The online provider currently uses an Overpass API endpoint to obtain OSM road ways around the current GPS position. The local cache stores their geometry in SQLite. This is deliberately separate from the UI so a future dedicated offline provider can replace it.

OpenStreetMap data is used under the ODbL. Do not bulk-download the standard OSM raster tile server for offline use; OSMF's tile policy explicitly prohibits prefetch/bulk offline use of `tile.openstreetmap.org`. For a full regional offline package, use an OSM-derived dataset/provider that permits offline distribution or self-host the required data.

## Current features

- RIDE is the default mode.
- DEMO can be opened from the RIDE screen.
- Portrait and landscape layouts.
- Native Android GPS using `LocationManager`.
- Speed, GPS accuracy/state and road-data state.
- Road geometry from OSM/Overpass when online.
- Local SQLite cache for previously acquired road geometry.
- Curve classification: LEGGERA / MEDIA / STRETTA / TORNANTE.
- Left/right mirrored vector graphics.
- Warning triangle for tight curves and hairpins.
- Professional arrow: black outline + yellow fill.
- Audio: 1 / 2 / 3 short beeps; hairpin = long + 2 short.
- 150 m crossing threshold with re-arm when the curve moves back beyond 150 m.
- Keep-screen-on and immersive fullscreen.
- No fake recommended speed when no usable radius is available.
- Demo sliders for speed, distance, grade and recommended speed.

## What is intentionally not claimed yet

- No validated safety-certified recommended-speed algorithm.
- No complete Canary Islands offline road database bundled in the APK.
- No turn-by-turn navigation UI.
- No elevation database bundled. OSM road geometry normally does not provide reliable elevation for this purpose, so RIDE does not fabricate grade data.
- No claim that an OSM way is always the exact continuation through an intersection; a future graph/stitching layer should improve this.

## Build without a PC

### Option A: AndroidIDE on the phone

AndroidIDE can open and build Gradle-based Android projects directly on Android devices. The original AndroidIDE project is archived, so use it only as a practical build tool and obtain it from a trusted source. The project is deliberately dependency-light and uses classic Android APIs to maximize compatibility.

1. Install AndroidIDE from a trusted source.
2. Install its JDK/SDK/build tools.
3. Copy/extract this project on the phone.
4. Open the project folder.
5. Let Gradle sync.
6. Run/build `assembleDebug`.
7. Install the generated APK.

### Option B: GitHub Actions (online build)

This project includes `.github/workflows/build-apk.yml`.

You can create a GitHub repository from your phone, upload the project files, and push them to `main`. GitHub Actions will build the debug APK in the cloud and publish it as a workflow artifact. This is the easiest PC-free route if AndroidIDE gives trouble.

The APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

The GitHub Actions artifact is named:

`road-display-pro-3.11.2-debug`

## Android permissions

The app requests location permission because curve anticipation depends on the current GPS position. Internet permission is required for online OSM road geometry retrieval.

## DEMO controls

Tap the DEMO area from RIDE. In DEMO:

- tap the upper area to cycle curve type;
- tap the direction area to switch left/right;
- use the four lower horizontal controls for speed, distance, grade and recommended speed.

All values are marked/sourced as simulated. DEMO must never be interpreted as a real safety recommendation.

## Online / offline behaviour

Online:

`GPS -> current position -> Overpass -> OSM road geometry -> curve engine -> local SQLite cache -> display/audio`

Offline:

`GPS -> current position -> local SQLite cache -> curve engine -> display/audio`

If the local database has no usable road geometry, the app displays `DATI STRADALI NON DISPONIBILI`.

## OSM / offline data strategy

Geofabrik publishes a current Canary Islands OSM extract in PBF format. A PBF is an excellent source for a future full offline database, but it is not copied blindly into the APK. A production offline package should preprocess the PBF into a compact road graph/SQLite format containing only the geometry and tags required by ROAD DISPLAY PRO.

For the first usable release, automatic online acquisition + local caching avoids shipping fabricated or stale road data. The architecture leaves the database/provider boundary ready for a prebuilt Canary Islands road package.

## Recommended next engineering phase

1. Replace individual OSM ways with a connected road graph.
2. Stitch ways at intersections and preserve directionality.
3. Add a proper offline PBF/SQLite preprocessing pipeline.
4. Add an elevation source/database for grade.
5. Improve curve segmentation and radius fitting with smoothing.
6. Add route-aware look-ahead and S-curve handling.
7. Validate the recommended-speed algorithm against real road geometry before presenting it as anything more than informational.
8. Add a dedicated offline package for Tenerife/Canary Islands generated from a dated OSM extract.

## Testing checklist

### DEMO
- 4 curve classes
- left/right
- speed 0–180
- distance 0–500 m
- grade negative/zero/positive
- recommended speed
- audio threshold
- portrait/landscape

### GPS
- permission
- GPS disabled
- weak accuracy
- recovery
- speed
- road data available/unavailable

### Online
- road retrieval
- cache creation
- connection loss without crash

### Offline
- disable Wi-Fi and mobile data
- previously cached road geometry remains usable
- uncached road shows `DATI STRADALI NON DISPONIBILI`

## Release signing

For a personal test APK, the debug build is sufficient. For a distributable release APK, create and protect your own keystore and configure Gradle signing. Never put a private production keystore or its passwords into a public repository.


## ROAD DISPLAY PRO 3.1.0 — leggibilità e demo adattiva

- Audio curve attivo all'avvio, senza schermata di attivazione.
- Schermata DEMO ridisegnata con controlli e cursori adattivi a orientamento verticale/orizzontale; pulsante RIDE sempre disponibile e tasto Indietro supportato.
- Velocità numerica più grande, contrasto elevato, ora, satelliti GPS/precisione stimata e stato dei dati stradali.
- Luminosità dello schermo impostata al massimo mentre l'app è in primo piano per migliorare la leggibilità all'aperto.
- Il download delle geometrie stradali OpenStreetMap tramite Overpass resta dipendente da GPS valido, connessione Internet e disponibilità del servizio; non è una banca dati offline completa.
- La velocità consigliata è sperimentale e non è un'indicazione di sicurezza certificata.


## 3.4.0 — map loading and layout reliability
- Map loading no longer depends on a high-accuracy GPS fix: GPS, network and passive providers are requested, and last-known/saved position is used immediately.
- If no system position is available, an approximate IP-based location is attempted via ipwho.is. This may be several kilometres off and is explicitly labelled approximate; it is used for map display only, never curve alerts. The request sends the device's public IP to the geolocation provider.
- Overpass requests use POST, an identifying User-Agent, multiple public endpoints sequentially and smaller fallback radii (10 km, 5 km, 2.5 km). Empty HTTP-200 responses are treated as failures. Public services can still be unavailable or rate-limited.
- The map status is placed at the lower edge so the centred motorcycle marker does not cover it; the marker is smaller. Weather banners use the space between METEO and DEMO instead of covering ride information.


## Version 3.5.0 update
- Added visible raster map tiles with two sequential tile providers (OpenStreetMap standard tiles, then CARTO dark tiles), viewport-only requests, local cache and visible attribution. Public endpoints are best-effort; they do not guarantee service availability.
- Reworked RIDE layout: speed is centered and enlarged, grows again above 90 km/h; map occupies the former speed area.
- Added ambient-light based activity brightness and restoration of the prior window brightness when leaving the app.
- Air temperature is shown next to curve information.


## ROAD DISPLAY PRO 3.11.2
- Demo mode removed and replaced by a Trips view with daily distance history and daily/monthly/yearly totals from the app's first-install date.
- Main map zoom increased; full-screen map supports pinch zoom and rotation-following travel heading, with the GPS marker staying at its map coordinate while panning.
- Weather temperature and a compact condition symbol sit below the weather button; portrait weather banner uses two bounded lines.
- Curve detection thresholds/look-ahead and OSM road-type coverage adjusted. Road geometry coverage and GPS quality still affect detection; validate carefully before relying on it while riding.
- Custom dark/yellow road-warning launcher icon.


## 3.9.0 – mappa, cache, velocità e radar
- Zoom +/− e pinch nella mappa principale e nella mappa full-screen.
- Ancora cartografica aggiornata solo dopo movimento significativo per ridurre lo sfarfallio.
- Cache persistente delle tessere visualizzate; uso di tessere antenate durante il caricamento per evitare quadratini neri.
- Fallback raster OSM/CARTO. I servizi pubblici non vengono usati per pre-scaricare intere aree: la cache riguarda le tessere effettivamente visualizzate e un piccolo margine.
- Display velocità a 7 segmenti, soglie colore configurabili toccando la velocità.
- Limite OSM visualizzato sopra la velocità e priorità al superamento del limite disponibile.
- Rilevamento dei nodi OSM `highway=speed_camera`; a 300 m: cinque lampeggi della velocità, due beep da 2 secondi e indicatore RADAR per 5 secondi.


## ROAD DISPLAY PRO 3.11.2 map/GPS hardening
- Weather requests are made only from a valid GPS fix on the device; no IP geolocation fallback is used for weather.
- Raster tiles use a persistent local cache, a stable last-displayed tile cache, a maximum of two concurrent tile downloads, and sequential provider fallback.
- Primary raster provider: OpenStreetMap Standard. Fallbacks: OSM France, HOT, and CyclOSM Lite, subject to each provider's usage policy.
- Tile loading remains viewport-driven with a small visual margin; the app does not bulk-prefetch or offer offline downloading from public OSM tile servers.
- Road-data download is retriggered when the first accurate GPS fix replaces a coarse location, in addition to distance/time refresh rules.
- Radar proximity is filtered by travel direction when heading/speed are reliable.
- UI position refresh is more fluid while road-data processing remains throttled.
